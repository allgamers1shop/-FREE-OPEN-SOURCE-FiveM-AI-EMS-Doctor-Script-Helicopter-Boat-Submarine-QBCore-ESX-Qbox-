
# ðŸ“˜ allgamers Development Docs

https://allgamers-development.gitbook.io/allgamers-development

---

## Version 2.1.0 Changelog

*Configuration system refactor*
  Settings are stored in the database and applied through a unified pipeline. Admins can change options without restarting the resource or the server; updates apply live and sync to clients.

*Admin settings UI (`/aidocsetup`)*
  New in-game settings panel (permission required). Edit categories with a friendly UI, save per section or all at once, reset to defaults, and test changes immediatelyâ€”no server restart needed.

*Multiple ambulance job names*
  Configure one or more medic job names so AI EMS is suppressed when enough real players on those jobs are online (respects your on-duty / off-duty counting rules).

*Custom EMS selection UI*
  New NUI for choosing EMS type (heli, car, boat, sub, walking, etc.). Opened via the default call keybind (**Y**) and your existing call command flow.

---

## Version 2.0.4 Changelog

*Vehicle Livery Support*
  Config.HeliModel, Config.CarModel, Config.BoatModel, Config.SubModel now use { model = "modelname", livery = 0 } format. Set livery index (0, 1, 2, etc) per vehicle for spawn variants. Livery indices are vehicle-specific; check GTA Wiki or Livery Shenanigans spreadsheet for values.

*Fix: Non-reviving for ESX and QBX*
  Fixed revive not working for ESX and QBX framework setups. Download the latest allgamers_bridge for the fix to work.

---

## Version 2.0.3 Changelog

*Walking NPC Only Mode*
  New Config.WalkingNPCMode and Config.WalkingNPCSpawnRadius. When enabled, only a walking doctor spawns nearby and revives on the spot (no vehicles). Command, keybind, and QuickAction call the doctor directly. Doctor walks away and is deleted after revive.

*MLO/Interior Detection*
  Config.CarExitDistanceOutdoor and Config.CarExitDistanceMLO. When player is inside MLO/interior, doctor exits vehicle earlier and walks to player. AI Doctor now rescues players inside MLO/interior.

*Fuel System*
  Removed Config.Fuel setting, integrated with allgamers Bridge.

*Auto Detection (Config.AutoSelectEMSType)*
  When enabled, EMS type is auto-selected from player location: mountain zones = heli, ground = car, surface water = boat, deep water = sub. Command without args, keybind, and QuickAction bypass menu/variables and call EMS directly with detected type. Note: Auto detection can occasionally misdetect location; use manual vehicle type if needed.

*Config renames (doctor / AI EMS availability)*
  Config.Doctor replaced by Config.DisableAIEMSAboveDoctorCount: AI EMS is disabled when more than this many doctors are online (0 = only when no doctors). Config.AllowAIEMSWithOffDuty replaced by Config.CountOnlyOnDutyDoctors: when true, only on-duty ambulance workers count toward the limit; off-duty are ignored.
