local WEBHOOK_URL = 'https://discord.com/api/webhooks/1310912647931105290/D0lWBQDG4KcfrOClFH1x4mu_65KsCZledcrQHuz1CnuKo7jkHUo-H6Iypzk56zhqx3v5'

local COLORS = {
    EMS_CALL = 16711680,
    REVIVE = 65280,
    INFO = 255
}

local function GetPlayerInfo(source)
    local firstname, lastname = ALLGAMERS.GetPlayerName(source)
    if not firstname or not lastname then
        return nil
    end
    return {
        name = firstname .. ' ' .. lastname,
        citizenid = ALLGAMERS.GetIdentifier(source),
        source = source
    }
end

local function FormatLocation(coords)
    if not coords then return "Unknown" end
    return string.format("X: %.2f, Y: %.2f, Z: %.2f", coords.x, coords.y, coords.z)
end

local function SendToDiscord(title, description, color)
    local embed = {
        {
            ["title"] = title,
            ["description"] = description,
            ["type"] = "rich",
            ["color"] = color,
            ["footer"] = {
                ["text"] = "allgamers AI Doctor V2.1.0 | " .. os.date("%Y-%m-%d %H:%M:%S")
            },
            ["thumbnail"] = {
                ["url"] = "https://r2.fivemanage.com/LDQTygtOvrin949qtfwJG/allgamers_store.png"
            }
        }
    }

    PerformHttpRequest(WEBHOOK_URL, function(err, text, headers)
        if err and err ~= 204 then
            print('^1[allgamers AI Doctor]^7 Discord log failed - check your webhook URL in server/logs.lua. Error: ' .. tostring(err))
        end
    end, 'POST', json.encode({
        username = "allgamers AI Doctor",
        embeds = embed
    }), { ['Content-Type'] = 'application/json' })
end

local function LogEMSCall(source, vehicleType, payment, paymentMethod)
    local playerInfo = GetPlayerInfo(source)
    if not playerInfo then return end

    local coords = GetEntityCoords(GetPlayerPed(source))
    local location = FormatLocation(coords)

    local description = string.format(
        "**Player Information**\n" ..
        "Name: %s\n" ..
        "Citizen ID: %s\n" ..
        "Server ID: %s\n\n" ..
        "**Call Details**\n" ..
        "Vehicle Type: %s\n" ..
        "Location: %s\n\n" ..
        "**Payment Details**\n" ..
        "Amount: $%s\n" ..
        "Method: %s",
        playerInfo.name,
        playerInfo.citizenid,
        playerInfo.source,
        vehicleType,
        location,
        payment,
        paymentMethod
    )

    SendToDiscord("AI EMS Call", description, COLORS.EMS_CALL)
end

local function LogRevive(source, payment, paymentMethod)
    local playerInfo = GetPlayerInfo(source)
    if not playerInfo then return end

    local coords = GetEntityCoords(GetPlayerPed(source))
    local location = FormatLocation(coords)

    local description = string.format(
        "**Player Information**\n" ..
        "Name: %s\n" ..
        "Citizen ID: %s\n" ..
        "Server ID: %s\n\n" ..
        "**Location**\n" ..
        "%s\n\n" ..
        "**Payment Details**\n" ..
        "Amount: $%s\n" ..
        "Method: %s",
        playerInfo.name,
        playerInfo.citizenid,
        playerInfo.source,
        location,
        payment,
        paymentMethod
    )

    SendToDiscord("AI EMS Revive", description, COLORS.REVIVE)
end

exports('LogEMSCall', LogEMSCall)
exports('LogRevive', LogRevive) 
