function DebugPrint(message)
    if Config and Config.Debug then
        print('[allgamers_aidoc][debug][server] ' .. tostring(message))
    end
end

function GetVersionFromCheckerText(body, resourceName)
    local foundSection = false
    local version = '0.0.0'

    for line in body:gmatch('[^\r\n]+') do
        if line:match('%[' .. resourceName .. '%]') then
            foundSection = true
        elseif foundSection then
            version = line
            break
        end
    end

    return version
end

function StartVersionCheck()
    if not IsDuplicityVersion() then
        return
    end

    CreateThread(function()
        Wait(4000)

        local resourceName = GetCurrentResourceName()
        local localVersion = GetResourceMetadata(resourceName, 'version') or '0.0.0'

        PerformHttpRequest('https://raw.githubusercontent.com/svgAPOLLO/version-checker/main/version.txt', function(_, body)
            if not body then
                print(('^1[VersionCheck]^7 Unable to check version for ^3%s^7 (local %s)'):format(resourceName, localVersion))
                return
            end

            local remoteVersion = GetVersionFromCheckerText(body, resourceName)
            if remoteVersion == '0.0.0' then
                print(('^3[VersionCheck]^7 No version info found for ^3%s^7 (local %s)'):format(resourceName, localVersion))
                return
            end

            if localVersion == remoteVersion then
                print(('^2[VersionCheck]^7 %s is up to date (^3%s^7)'):format(resourceName, localVersion))
            else
                print(('^1[VersionCheck]^7 %s is outdated! (^3%s -> %s^7)'):format(resourceName, localVersion, remoteVersion))
                print('^1[VersionCheck]^7 Check your Keymaster and download the latest file!')
            end
        end)
    end)
end

function GetMedicJobNames()
    return ParseMedicJobNamesList(Config.AmbulanceJobName or 'ambulance')
end

function IsMedicJob(jobName)
    if not jobName or type(jobName) ~= 'string' then
        return false
    end

    local normalizedJob = string.lower(jobName)
    for _, medicJob in ipairs(GetMedicJobNames()) do
        if normalizedJob == medicJob then
            return true
        end
    end

    return false
end

StartVersionCheck()

lib.callback.register('allgamers_aidoc:server:checkDocOnline', function(source, callPayment, vehicleType)
    local player = ALLGAMERS.GetPlayer(source)
    local players = ALLGAMERS.GetAllPlayers()
    local totalMedics = 0
    local onDutyMedics = 0
    local canAfford = false

    DebugPrint('checkDocOnline: medic jobs = ' .. (Config.AmbulanceJobName or 'ambulance'))

    local cash = ALLGAMERS.GetMoney(source)
    local bank = ALLGAMERS.GetBankMoney(source)
    if callPayment <= cash or callPayment <= bank then
        canAfford = true
    end

    for _, targetSource in ipairs(players) do
        local jobInfo = ALLGAMERS.GetPlayerJobInfo(targetSource)
        if jobInfo and IsMedicJob(jobInfo.jobName) then
            totalMedics = totalMedics + 1
            if jobInfo.onDuty then
                onDutyMedics = onDutyMedics + 1
            end
        end
    end

    local doctorCount = Config.CountOnlyOnDutyDoctors and onDutyMedics or totalMedics
    DebugPrint('checkDocOnline: doctorCount=' .. doctorCount .. ' canAfford=' .. tostring(canAfford))

    return doctorCount, canAfford, vehicleType
end)

lib.callback.register('allgamers_aidoc:server:checkDocOnlineForDoctor', function(source, targetPlayerId, _, vehicleType)
    local player = ALLGAMERS.GetPlayer(source)
    local jobInfo = ALLGAMERS.GetPlayerJobInfo(source)

    if not jobInfo or not IsMedicJob(jobInfo.jobName) then
        DebugPrint('checkDocOnlineForDoctor: player ' .. tostring(source) .. ' has no medic job from list')
        return false, false, 'not_ambulance'
    end

    local targetPlayer = ALLGAMERS.GetPlayer(targetPlayerId)
    if not targetPlayer then
        print('^1[AllGamers AI Doctor]^7 Target player not found - they may have left the server.')
        return false, false, 'player_not_found'
    end

    return true, true, vehicleType
end)

lib.callback.register('allgamers_aidoc:server:processPayment', function(source, amount, vehicleType, payerSource)
    local chargedSource = payerSource or source
    local isDoctorCall = payerSource ~= nil

    DebugPrint('processPayment: isDoctorCall=' .. tostring(isDoctorCall) .. ' amount=' .. tostring(amount))

    if not isDoctorCall then
        local paymentMethod = 'Bank'
        local cash = ALLGAMERS.GetMoney(chargedSource)

        if amount <= cash then
            ALLGAMERS.RemoveMoney(chargedSource, amount)
            paymentMethod = 'Cash'
        else
            ALLGAMERS.RemoveBankMoney(chargedSource, amount)
        end

        exports.allgamers_aidoc:LogEMSCall(chargedSource, vehicleType, amount, paymentMethod, source)
    else
        exports.allgamers_aidoc:LogEMSCall(chargedSource, vehicleType, 0, 'Doctor-Call', source)
    end

    return true
end)

RegisterServerEvent('allgamers:payForRevive')
AddEventHandler('allgamers:payForRevive', function(amount)
    local src = source
    local paymentMethod = 'Bank'
    local cash = ALLGAMERS.GetMoney(src)
    local bank = ALLGAMERS.GetBankMoney(src)

    if amount <= cash then
        ALLGAMERS.RemoveMoney(src, amount)
        paymentMethod = 'Cash'
    else
        ALLGAMERS.RemoveBankMoney(src, amount)
    end

    local fundJob = ResolveFundJobName(Config.FundJobName, Config.AmbulanceJobName)
    local framework = ALLGAMERS.GetFrameworkName()

    if framework == 'qb-core' then
        TriggerEvent('qb-bossmenu:server:addAccountMoney', fundJob, amount)
    elseif framework == 'esx' then
        TriggerEvent('esx_addonaccount:getSharedAccount', 'society_' .. fundJob, function(account)
            if account then
                account.addMoney(amount)
            end
        end)
    end

    DebugPrint('payForRevive: charged ' .. amount .. ' via ' .. paymentMethod .. ' to society ' .. fundJob)
    exports.allgamers_aidoc:LogRevive(src, amount, paymentMethod)
end)

RegisterServerEvent('allgamers:server:reviveWasabi')
AddEventHandler('allgamers:server:reviveWasabi', function()
    local src = source
    exports.wasabi_ambulance:RevivePlayer(src)
end)

RegisterServerEvent('allgamers:server:reviveTkAmbulance')
AddEventHandler('allgamers:server:reviveTkAmbulance', function(playerId)
    exports.tk_ambulancejob:revive(playerId, true)
end)

RegisterServerEvent('allgamers:server:reviveQuasarAmbulance')
AddEventHandler('allgamers:server:reviveQuasarAmbulance', function(playerId)
    local src = source
    TriggerClientEvent('ambulance:revivePlayer', playerId or src)
end)

RegisterServerEvent('allgamers_aidoc:server:revivePlayer')
AddEventHandler('allgamers_aidoc:server:revivePlayer', function(playerId)
    -- Always revive the event source (ignore spoofed target ids from the client)
    local src = source
    local revived = ALLGAMERS.RevivePlayer(src)
    if not revived then
        print(('^1[AllGamers AI Doctor]^7 Revive failed for %s - framework revive did not work. On ESX Legacy ensure esx_death is started and allgamers_bridge uses its Revive export.'):format(src))
    end
end)

RegisterServerEvent('allgamers_aidoc:server:triggerEMSForPlayer')
AddEventHandler('allgamers_aidoc:server:triggerEMSForPlayer', function(targetPlayerId, vehicleType)
    TriggerClientEvent('allgamers_aidoc:client:startEMSProcess', targetPlayerId, vehicleType, true)
end)

RegisterServerEvent('allgamers_aidoc:lockSpawnedNpcs')
AddEventHandler('allgamers_aidoc:lockSpawnedNpcs', function(npcIds)
    if not npcIds or type(npcIds) ~= 'table' then
        return
    end

    local worldResource = nil
    if GetResourceState('allgamers_ai_world') == 'started' then
        worldResource = 'allgamers_ai_world'
    elseif GetResourceState('allgamers_ai_world') == 'started' then
        worldResource = 'allgamers_ai_world'
    else
        return
    end

    for _, npcId in ipairs(npcIds) do
        if npcId and npcId ~= '' then
            exports[worldResource]:LockNpc(tostring(npcId), 0)
        end
    end
end)

RegisterServerEvent('allgamers:clearInventory')
AddEventHandler('allgamers:clearInventory', function()
    local src = source
    local player = ALLGAMERS.GetPlayer(src)
    if not player then
        return
    end

    local keepItems = Config.KeepItemsOnRevive or {}
    local inventory = ALLGAMERS.GetPlayerInventory(src)

    if not inventory then
        print('^1[AllGamers AI Doctor]^7 Could not clear inventory on revive - framework could not get player inventory.')
        return
    end

    for _, item in pairs(inventory) do
        if item and item.name then
            local amount = item.amount or item.count or 0
            if amount > 0 then
                local shouldKeep = false
                for _, keepName in ipairs(keepItems) do
                    if item.name == keepName then
                        shouldKeep = true
                        break
                    end
                end

                if not shouldKeep then
                    ALLGAMERS.RemoveItem(src, item.name, amount)
                end
            end
        end
    end
end)

