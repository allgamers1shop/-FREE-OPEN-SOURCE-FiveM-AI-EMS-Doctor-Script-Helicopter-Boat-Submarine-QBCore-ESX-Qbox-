local runtimeSettings = {}
local isSettingsLoaded = false

local function logDebug(msg)
    if Config and Config.Debug then
        print("[allgamers_aidoc][debug][settings] " .. tostring(msg))
    end
end

local function ensureDatabaseTables()
    logDebug("Ensuring database tables exist")
    MySQL.query.await([[
        CREATE TABLE IF NOT EXISTS `allgamers_aidoc_settings` (
            `id` INT NOT NULL AUTO_INCREMENT,
            `settings_key` VARCHAR(100) NOT NULL,
            `settings_json` LONGTEXT NOT NULL,
            `updated_by` VARCHAR(100) NULL DEFAULT NULL,
            `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            UNIQUE KEY `uk_settings_key` (`settings_key`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ]])
    logDebug("Database tables verified")
end

local function validateCategoryData(category, data)
    if data and type(data) ~= "table" then
        logDebug("Validation failed for " .. category .. ": data is not a table")
        return false, "Data must be a table"
    end
    
    local schema = SettingsSchema[category]
    if not schema then
        logDebug("No schema found for category: " .. category)
        return true
    end
    
    local errors = {}
    for key, spec in pairs(schema) do
        local val = data[key]
        if val ~= nil then
            if spec.type == "number" then
                if type(val) == "number" then
                    if spec.min and val < spec.min then
                        errors[#errors + 1] = key .. " must be >= " .. spec.min
                    end
                    if spec.max and val > spec.max then
                        errors[#errors + 1] = key .. " must be <= " .. spec.max
                    end
                end
            elseif spec.type == "string" then
                if type(val) ~= "string" then
                    errors[#errors + 1] = key .. " must be a string"
                end
            elseif spec.type == "boolean" then
                if type(val) ~= "boolean" then
                    errors[#errors + 1] = key .. " must be a boolean"
                end
            end
        end
    end
    
    if #errors > 0 then
        logDebug("Validation errors for " .. category .. ": " .. table.concat(errors, ", "))
        return false, table.concat(errors, "; ")
    end
    
    if category == "restricted_zones" and data.zones then
        for i, zone in ipairs(data.zones) do
            local validCoords = false
            if zone.coords then
                if type(zone.coords) == "string" and ParseVector3String(zone.coords) then
                    validCoords = true
                end
            elseif zone.x ~= nil and zone.y ~= nil and zone.z ~= nil then
                validCoords = true
            end
            if not validCoords then
                return false, "restricted_zones zone " .. i .. ": invalid coords (use x,y,z or three numbers separated by commas)"
            end
        end
    end
    
    if category == "hospital_revive" and data.Hospitals then
        for i, hospital in ipairs(data.Hospitals) do
            local validCenter = false
            if hospital.center then
                if type(hospital.center) == "string" and ParseVector3String(hospital.center) then
                    validCenter = true
                end
            elseif hospital.center_x ~= nil and hospital.center_y ~= nil and hospital.center_z ~= nil then
                validCenter = true
            end
            
            if not validCenter then
                return false, "hospital " .. i .. ": invalid center"
            end
            
            if hospital.beds then
                for j, bed in ipairs(hospital.beds) do
                    local validBed = false
                    if bed.line then
                        if type(bed.line) == "string" and ParseVector4String(bed.line) then
                            validBed = true
                        end
                    elseif bed.x ~= nil and bed.y ~= nil and bed.z ~= nil and bed.w ~= nil then
                        validBed = true
                    end
                    if not validBed then
                        return false, "hospital " .. i .. " bed " .. j .. ": invalid (use four comma-separated numbers)"
                    end
                end
            end
        end
    end
    
    if category == "ambulance_job" and data.FundJobName then
        if type(data.FundJobName) == "string" then
            local validJobs = ParseMedicJobNamesList(data.AmbulanceJobName or "")
            local fundJob = string.lower(string.gsub(string.gsub(data.FundJobName, "^%s+", ""), "%s+$", ""))
            
            local found = false
            for _, job in ipairs(validJobs) do
                if job == fundJob then
                    found = true
                    break
                end
            end
            if not found then
                return false, "FundJobName must match one of the jobs in AmbulanceJobName"
            end
        end
    end
    
    return true
end

local function loadSettingsFromDatabase()
    logDebug("Loading settings from database")
    ensureDatabaseTables()
    
    local results = MySQL.query.await("SELECT settings_key, settings_json FROM allgamers_aidoc_settings")
    local dbSettings = {}
    local count = 0
    
    if results then
        for _, row in ipairs(results) do
            local success, parsed = pcall(json.decode, row.settings_json)
            if success and parsed then
                dbSettings[row.settings_key] = parsed
                count = count + 1
                logDebug("Loaded category from DB: " .. row.settings_key)
            else
                logDebug("Failed to parse JSON for category: " .. row.settings_key)
            end
        end
    end
    
    logDebug("Loaded " .. count .. " categories from database")
    
    local defaultCopy = DeepCopy(DefaultSettings)
    local seeded = false
    
    for _, cat in ipairs(SETTINGS_CATEGORIES) do
        if dbSettings[cat] then
            runtimeSettings[cat] = DeepMerge(defaultCopy[cat] or {}, dbSettings[cat])
        else
            runtimeSettings[cat] = defaultCopy[cat] or {}
            MySQL.insert("INSERT INTO allgamers_aidoc_settings (settings_key, settings_json, updated_by) VALUES (?, ?, ?)", {cat, json.encode(runtimeSettings[cat]), "system_init"})
            seeded = true
            logDebug("Seeded missing category to DB: " .. cat)
        end
    end
    
    if seeded then
        logDebug("Repaired missing categories in database")
    end
    
    ApplySettingsToConfig(runtimeSettings)
    isSettingsLoaded = true
    logDebug("Settings loaded and applied to Config")
end

local function getSettings()
    if not isSettingsLoaded then
        loadSettingsFromDatabase()
    end
    return runtimeSettings
end

local function getCategory(category)
    return getSettings()[category]
end

function broadcast_settings(target)
    local settings = getSettings()
    if target == -1 then
        TriggerClientEvent("allgamers_aidoc:client:syncSettings", -1, settings)
        logDebug("Settings broadcast to all clients")
    else
        TriggerClientEvent("allgamers_aidoc:client:syncSettings", target, settings)
        logDebug("Settings sent to client: " .. tostring(target))
    end
end

local function saveCategory(category, data, src)
    logDebug("Save request for category: " .. category)
    local valid, err = validateCategoryData(category, data)
    
    if not valid then
        logDebug("Save rejected for " .. category .. ": " .. tostring(err))
        return false, err
    end
    
    runtimeSettings[category] = data
    
    local updatedBy = "system"
    if src and src > 0 then
        local identifier = ALLGAMERS.GetIdentifier(src)
        if identifier then updatedBy = identifier end
    end
    
    MySQL.query("INSERT INTO allgamers_aidoc_settings (settings_key, settings_json, updated_by) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE settings_json = VALUES(settings_json), updated_by = VALUES(updated_by)", {category, json.encode(data), updatedBy})
    
    ApplySettingsToConfig(runtimeSettings)
    broadcast_settings(-1)
    logDebug("Category saved successfully: " .. category)
    return true
end

local function saveAllSettings(data, src)
    logDebug("Save all settings request")
    
    local errors = {}
    for cat, catData in pairs(data) do
        local valid, err = validateCategoryData(cat, catData)
        if not valid then
            errors[#errors + 1] = cat .. ": " .. tostring(err)
        end
    end
    
    if #errors > 0 then
        logDebug("Save all rejected: " .. table.concat(errors, "; "))
        return false, table.concat(errors, "; ")
    end
    
    for cat, catData in pairs(data) do
        runtimeSettings[cat] = catData
        local updatedBy = "system"
        if src and src > 0 then
            local identifier = ALLGAMERS.GetIdentifier(src)
            if identifier then updatedBy = identifier end
        end
        MySQL.query("INSERT INTO allgamers_aidoc_settings (settings_key, settings_json, updated_by) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE settings_json = VALUES(settings_json), updated_by = VALUES(updated_by)", {cat, json.encode(catData), updatedBy})
    end
    
    ApplySettingsToConfig(runtimeSettings)
    broadcast_settings(-1)
    logDebug("All settings saved successfully")
    return true
end

local function resetCategory(category, src)
    logDebug("Reset category request: " .. category)
    local defaults = DeepCopy(DefaultSettings)[category]
    if not defaults then
        return false, "Unknown category"
    end
    return saveCategory(category, defaults, src)
end

local function restoreDefaults(src)
    logDebug("Restore all defaults request")
    return saveAllSettings(DeepCopy(DefaultSettings), src)
end

lib.callback.register("allgamers_aidoc:server:requestRuntimeSettings", function(source)
    return getSettings()
end)

AddEventHandler("onResourceStart", function(resourceName)
    if GetCurrentResourceName() ~= resourceName then return end
    CreateThread(function()
        Wait(500)
        loadSettingsFromDatabase()
        logDebug("Resource started, settings loaded from database")
        broadcast_settings(-1)
    end)
end)

AddEventHandler("playerJoining", function()
    local src = source
    CreateThread(function()
        Wait(2000)
        if isSettingsLoaded then
            broadcast_settings(src)
            logDebug("Settings sent to joining player: " .. tostring(src))
        end
    end)
end)

exports("GetSettings", getSettings)
exports("GetCategory", getCategory)
exports("SaveCategory", saveCategory)
exports("SaveAll", saveAllSettings)
exports("ResetCategory", resetCategory)
exports("RestoreDefaults", restoreDefaults)
exports("BroadcastSettings", broadcast_settings)
exports("LoadSettingsFromDatabase", loadSettingsFromDatabase)

local function logAdminDebug(msg)
    if Config and Config.Debug then
        print("[allgamers_aidoc][debug][admin] " .. tostring(msg))
    end
end

local function isAdmin(src)
    if not src or src < 1 then return false end
    if ALLGAMERS.HasPermission(src) then return true end
    if Config.adminjob and Config.adminjobname then
        if ALLGAMERS.GetPlayerJob(src) == Config.adminjobname then
            return true
        end
    end
    return false
end

local function isValidVehicleType(vType)
    if vType and type(vType) == "string" then
        if Config.WalkingNPCMode then
            return vType == "walking"
        end
        if Config.VehicleArgs then
            return vType == Config.VehicleArgs.Heli
        end
    end
    return false
end

lib.addCommand(Config.AdminSetupCommand or "aidocsetup", {
    help = "Open AI Doc Setup Panel (Admin Only)",
    restricted = false
}, function(source)
    logAdminDebug("Admin command triggered by player: " .. tostring(source))
    local hasPerm = isAdmin(source)
    logAdminDebug("Permission check result: " .. tostring(hasPerm))
    
    if not hasPerm then
        logAdminDebug("Permission denied for player: " .. tostring(source))
        TriggerClientEvent("ox_lib:notify", source, {
            type = "error",
            description = "You do not have permission to access AI Doc settings.",
            duration = 3000
        })
        return
    end
    
    local settings = exports.allgamers_aidoc:GetSettings()
    logAdminDebug("Sending admin UI data to player: " .. tostring(source))
    TriggerClientEvent("allgamers_aidoc:client:openAdminUI", source, settings, Config.AmbulanceScriptOptions)
end)

lib.callback.register("allgamers_aidoc:server:saveCategory", function(source, category, data)
    logAdminDebug("Save category callback from player: " .. tostring(source) .. " for: " .. tostring(category))
    if not isAdmin(source) then
        logAdminDebug("Save rejected: no permission for player " .. tostring(source))
        return false, "Permission denied"
    end
    
    local success, err = exports.allgamers_aidoc:SaveCategory(category, data, source)
    logAdminDebug("Save result for " .. tostring(category) .. ": " .. tostring(success) .. " err: " .. tostring(err))
    return success, err
end)

lib.callback.register("allgamers_aidoc:server:saveAllSettings", function(source, data)
    logAdminDebug("Save all settings callback from player: " .. tostring(source))
    if not isAdmin(source) then
        logAdminDebug("Save all rejected: no permission for player " .. tostring(source))
        return false, "Permission denied"
    end
    
    local success, err = exports.allgamers_aidoc:SaveAll(data, source)
    logAdminDebug("Save all result: " .. tostring(success) .. " err: " .. tostring(err))
    return success, err
end)

lib.callback.register("allgamers_aidoc:server:resetCategory", function(source, category)
    logAdminDebug("Reset category callback from player: " .. tostring(source) .. " for: " .. tostring(category))
    if not isAdmin(source) then
        return false, "Permission denied"
    end
    
    local success, err = exports.allgamers_aidoc:ResetCategory(category, source)
    logAdminDebug("Reset result for " .. tostring(category) .. ": " .. tostring(success) .. " err: " .. tostring(err))
    return success, err
end)

lib.callback.register("allgamers_aidoc:server:restoreDefaults", function(source)
    logAdminDebug("Restore defaults callback from player: " .. tostring(source))
    if not isAdmin(source) then
        return false, "Permission denied"
    end
    
    local success, err = exports.allgamers_aidoc:RestoreDefaults(source)
    logAdminDebug("Restore defaults result: " .. tostring(success))
    return success, err
end)

lib.callback.register("allgamers_aidoc:server:getSettings", function(source)
    logAdminDebug("Get settings callback from player: " .. tostring(source))
    if not isAdmin(source) then
        return nil, "Permission denied"
    end
    return exports.allgamers_aidoc:GetSettings()
end)

lib.callback.register("allgamers_aidoc:server:adminDispatchEMS", function(source, targetId, vType)
    if not isAdmin(source) then
        return false, "You do not have permission to do this."
    end
    
    local tId = tonumber(targetId)
    if not tId or tId < 1 then
        return false, "Enter a valid server ID."
    end
    
    if not isValidVehicleType(vType) then
        return false, "That vehicle type does not match your server settings."
    end
    
    if not GetPlayerName(tId) then
        return false, "That player is not online."
    end
    
    TriggerClientEvent("allgamers_aidoc:client:startEMSProcess", tId, vType, true)
    exports.allgamers_aidoc:LogEMSCall(tId, vType, 0, "Admin-Dispatch")
    
    return true
end)
