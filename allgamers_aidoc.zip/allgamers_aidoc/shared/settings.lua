RuntimeSettings = {}

function RuntimeSettings(config_table)
    if type(config_table) ~= "table" then
        return config_table
    end
    local res = {}
    for k, v in pairs(config_table) do
        res[k] = RuntimeSettings(v)
    end
    return res
end

function DeepMerge(t1, t2)
    if type(t1) == "table" and type(t2) == "table" then
        local res = RuntimeSettings(t1)
        for k, v in pairs(t2) do
            if type(v) == "table" then
                if type(res[k]) == "table" then
                    res[k] = DeepMerge(res[k], v)
                end
            else
                res[k] = v
            end
        end
        return res
    end
    return t2
end

function GetFirstNonNil(a, b, c)
    if a ~= nil then return a end
    if b ~= nil then return b end
    return c
end

function RuntimeDebug(tag, msg)
    if Config and Config.Debug then
        print(string.format("[allgamers_aidoc][debug][%s] %s", tag, tostring(msg)))
    end
end

function Trim(str)
    if type(str) ~= "string" then return "" end
    return str:gsub("^%s+", ""):gsub("%s+$", "")
end

function ParseMedicJobNamesList(jobStr)
    local res = {}
    if type(jobStr) ~= "string" then
        jobStr = "ambulance"
    end
    for job in string.gmatch(jobStr, "([^,]+)") do
        local trimmed = Trim(job)
        if trimmed ~= "" then
            res[#res + 1] = string.lower(trimmed)
        end
    end
    if #res == 0 then
        res[1] = "ambulance"
    end
    return res
end

function ResolveFundJobName(jobName, fallbackListStr)
    local list = ParseMedicJobNamesList(fallbackListStr)
    if type(jobName) ~= "string" then
        return list[1]
    end
    local lowerJob = string.lower(Trim(jobName))
    for _, v in ipairs(list) do
        if v == lowerJob then
            return v
        end
    end
    return list[1]
end

function ParseVector3String(str)
    if type(str) ~= "string" then return nil end
    local parts = {}
    for part in string.gmatch(str, "[^,]+") do
        parts[#parts + 1] = Trim(part)
    end
    if #parts < 3 then return nil end
    local x, y, z = tonumber(parts[1]), tonumber(parts[2]), tonumber(parts[3])
    if not (x and y and z) then return nil end
    return x, y, z
end

function ParseVector4String(str)
    if type(str) ~= "string" then return nil end
    local parts = {}
    for part in string.gmatch(str, "[^,]+") do
        parts[#parts + 1] = Trim(part)
    end
    if #parts < 4 then return nil end
    local x, y, z, w = tonumber(parts[1]), tonumber(parts[2]), tonumber(parts[3]), tonumber(parts[4])
    if not (x and y and z and w) then return nil end
    return x, y, z, w
end

function FormatVector3String(x, y, z)
    return string.format("%.2f, %.2f, %.2f", x, y, z)
end

function FormatVector4String(x, y, z, w)
    return string.format("%.2f, %.2f, %.2f, %.2f", x, y, z, w)
end

function ParseCoordsVector3(data)
    if data.coords then
        if type(data.coords) == "string" then
            local x, y, z = ParseVector3String(data.coords)
            if x then return vector3(x, y, z) end
        end
    end
    if data.x ~= nil and data.y ~= nil and data.z ~= nil then
        return vector3(data.x, data.y, data.z)
    end
    return nil
end

function ParseCenterVector3(data)
    if data.center then
        if type(data.center) == "string" then
            local x, y, z = ParseVector3String(data.center)
            if x then return vector3(x, y, z) end
        end
    end
    if data.center_x ~= nil and data.center_y ~= nil and data.center_z ~= nil then
        return vector3(data.center_x, data.center_y, data.center_z)
    end
    return nil
end

function ParseLineVector4(data)
    if data.line then
        if type(data.line) == "string" then
            local x, y, z, w = ParseVector4String(data.line)
            if x then return vector4(x, y, z, w) end
        end
    end
    if data.x ~= nil and data.y ~= nil and data.z ~= nil and data.w ~= nil then
        return vector4(data.x, data.y, data.z, data.w)
    end
    return nil
end

function ApplySettingsToConfig(settings)
    if not settings then return end
    RuntimeDebug("runtime", "Applying settings to Config table")
    
    if settings.ambulance_job then
        Config.AmbulanceJob = GetFirstNonNil(settings.ambulance_job.AmbulanceJob, Config.AmbulanceJob, "default")
        Config.AmbulanceJobName = GetFirstNonNil(settings.ambulance_job.AmbulanceJobName, Config.AmbulanceJobName, "ambulance")
        Config.CountOnlyOnDutyDoctors = GetFirstNonNil(settings.ambulance_job.CountOnlyOnDutyDoctors, Config.CountOnlyOnDutyDoctors, true)
        Config.FundJobName = ResolveFundJobName(GetFirstNonNil(settings.ambulance_job.FundJobName, Config.FundJobName, nil), Config.AmbulanceJobName)
        RuntimeDebug("runtime", "Applied ambulance_job settings")
    end

    if settings.vehicle_models then
        Config.HeliModel = GetFirstNonNil(settings.vehicle_models.HeliModel, Config.HeliModel, {model = "polmav", livery = 1})
        Config.CarModel = GetFirstNonNil(settings.vehicle_models.CarModel, Config.CarModel, {model = "ambulance", livery = 2})
        Config.BoatModel = GetFirstNonNil(settings.vehicle_models.BoatModel, Config.BoatModel, {model = "seashark2", livery = 0})
        Config.SubModel = GetFirstNonNil(settings.vehicle_models.SubModel, Config.SubModel, {model = "Submersible", livery = 0})
        RuntimeDebug("runtime", "Applied vehicle_models settings")
    end

    if settings.doctor_revive then
        Config.DisableAIEMSAboveDoctorCount = GetFirstNonNil(settings.doctor_revive.DisableAIEMSAboveDoctorCount, Config.DisableAIEMSAboveDoctorCount, 0)
        Config.CallPayment = GetFirstNonNil(settings.doctor_revive.CallPayment, Config.CallPayment, 500)
        Config.RevivePayment = GetFirstNonNil(settings.doctor_revive.RevivePayment, Config.RevivePayment, 1500)
        Config.ReviveTime = GetFirstNonNil(settings.doctor_revive.ReviveTime, Config.ReviveTime, 5000)
        Config.EMSArrivalTime = GetFirstNonNil(settings.doctor_revive.EMSArrivalTime, Config.EMSArrivalTime, 60)
        Config.UseProgressBar = GetFirstNonNil(settings.doctor_revive.UseProgressBar, Config.UseProgressBar, true)
        Config.SetHealthAmount = GetFirstNonNil(settings.doctor_revive.SetHealthAmount, Config.SetHealthAmount, false)
        Config.ReviveHealthAmount = GetFirstNonNil(settings.doctor_revive.ReviveHealthAmount, Config.ReviveHealthAmount, 80)
        RuntimeDebug("runtime", "Applied doctor_revive settings")
    end

    if settings.commands_keybinds then
        Config.AlivePlayerCanCall = GetFirstNonNil(settings.commands_keybinds.AlivePlayerCanCall, Config.AlivePlayerCanCall, false)
        Config.RegisterKeybind = GetFirstNonNil(settings.commands_keybinds.RegisterKeybind, Config.RegisterKeybind, true)
        Config.Keybind = GetFirstNonNil(settings.commands_keybinds.Keybind, Config.Keybind, "y")
        Config.QuickAction = GetFirstNonNil(settings.commands_keybinds.QuickAction, Config.QuickAction, true)
        Config.QuickActionKey = GetFirstNonNil(settings.commands_keybinds.QuickActionKey, Config.QuickActionKey, "K")
        Config.QuickActionCommand = GetFirstNonNil(settings.commands_keybinds.QuickActionCommand, Config.QuickActionCommand, "car")
        Config.WalkingNPCMode = GetFirstNonNil(settings.commands_keybinds.WalkingNPCMode, Config.WalkingNPCMode, false)
        Config.WalkingNPCSpawnRadius = GetFirstNonNil(settings.commands_keybinds.WalkingNPCSpawnRadius, Config.WalkingNPCSpawnRadius, 50)
        Config.AutoSelectEMSType = GetFirstNonNil(settings.commands_keybinds.AutoSelectEMSType, Config.AutoSelectEMSType, false)
        Config.CallCommand = GetFirstNonNil(settings.commands_keybinds.CallCommand, Config.CallCommand, "aiems")
        Config.VehicleArgs = GetFirstNonNil(settings.commands_keybinds.VehicleArgs, Config.VehicleArgs, {Heli = "heli", Car = "car", Boat = "boat", Sub = "merin"})
        Config.CancelCommand = GetFirstNonNil(settings.commands_keybinds.CancelCommand, Config.CancelCommand, "cancelaiems")
        Config.SendEMSCommand = GetFirstNonNil(settings.commands_keybinds.SendEMSCommand, Config.SendEMSCommand, "sendems")
        RuntimeDebug("runtime", "Applied commands_keybinds settings")
    end

    if settings.inventory then
        Config.ClearInventoryOnRevive = GetFirstNonNil(settings.inventory.ClearInventoryOnRevive, Config.ClearInventoryOnRevive, true)
        Config.KeepItemsOnRevive = GetFirstNonNil(settings.inventory.KeepItemsOnRevive, Config.KeepItemsOnRevive, {"phone", "radio"})
        RuntimeDebug("runtime", "Applied inventory settings")
    end

    if settings.restricted_zones then
        Config.RestrictedZones = {}
        if settings.restricted_zones.zones then
            for _, zone in ipairs(settings.restricted_zones.zones) do
                local coords = ParseCoordsVector3(zone)
                if coords then
                    table.insert(Config.RestrictedZones, {
                        name = zone.name or "Zone",
                        coords = coords,
                        radius = zone.radius or 50.0
                    })
                end
            end
        end
        RuntimeDebug("runtime", "Applied restricted_zones: " .. #Config.RestrictedZones .. " zones")
    end

    if settings.hospital_revive then
        Config.HospitalRevive = GetFirstNonNil(settings.hospital_revive.HospitalRevive, Config.HospitalRevive, false)
        Config.HospitalSendDelayMs = GetFirstNonNil(settings.hospital_revive.HospitalSendDelayMs, Config.HospitalSendDelayMs, 2500)
        Config.HospitalGetUpKey = GetFirstNonNil(settings.hospital_revive.HospitalGetUpKey, Config.HospitalGetUpKey, 38)
        Config.Hospitals = {}
        if settings.hospital_revive.Hospitals then
            for _, hosp in ipairs(settings.hospital_revive.Hospitals) do
                local center = ParseCenterVector3(hosp)
                local beds = {}
                if hosp.beds then
                    for _, bed in ipairs(hosp.beds) do
                        local line = ParseLineVector4(bed)
                        if line then
                            table.insert(beds, line)
                        end
                    end
                end
                if center then
                    table.insert(Config.Hospitals, {
                        name = hosp.name,
                        center = center,
                        radius = hosp.radius,
                        beds = beds
                    })
                end
            end
        end
        RuntimeDebug("runtime", "Applied hospital_revive: " .. #Config.Hospitals .. " hospitals")
    end

    if settings.blips then
        Config.BlipSettings = settings.blips
        RuntimeDebug("runtime", "Applied blip settings")
    end

    if settings.custom_ped then
        Config.UseCustomPED = GetFirstNonNil(settings.custom_ped.UseCustomPED, Config.UseCustomPED, false)
        Config.DefaultPedModel = GetFirstNonNil(settings.custom_ped.DefaultPedModel, Config.DefaultPedModel, "s_m_m_paramedic_01")
        if settings.custom_ped.CustomPED then
            Config.CustomPED = settings.custom_ped.CustomPED
        end
        RuntimeDebug("runtime", "Applied custom_ped settings")
    end

    if settings.vehicle_spawn then
        Config.HeliSpawnHeight = GetFirstNonNil(settings.vehicle_spawn.HeliSpawnHeight, Config.HeliSpawnHeight, 100)
        Config.HeliDescendDistance = GetFirstNonNil(settings.vehicle_spawn.HeliDescendDistance, Config.HeliDescendDistance, 15)
        Config.CarSpawnRange = GetFirstNonNil(settings.vehicle_spawn.CarSpawnRange, Config.CarSpawnRange, 100)
        Config.CarExitDistanceOutdoor = GetFirstNonNil(settings.vehicle_spawn.CarExitDistanceOutdoor, Config.CarExitDistanceOutdoor, 10)
        Config.CarExitDistanceMLO = GetFirstNonNil(settings.vehicle_spawn.CarExitDistanceMLO, Config.CarExitDistanceMLO, 70)
        Config.BoatSpawnRange = GetFirstNonNil(settings.vehicle_spawn.BoatSpawnRange, Config.BoatSpawnRange, 200)
        Config.SubSpawnRange = GetFirstNonNil(settings.vehicle_spawn.SubSpawnRange, Config.SubSpawnRange, 50)
        RuntimeDebug("runtime", "Applied vehicle_spawn settings")
    end

    RuntimeDebug("runtime", "All settings applied to Config successfully")
end

function BuildSettingsFromConfig()
    RuntimeDebug("runtime", "Building settings table from Config")
    local zones = {}
    if Config.RestrictedZones then
        for _, zone in ipairs(Config.RestrictedZones) do
            table.insert(zones, {
                name = zone.name or "Zone",
                coords = FormatVector3String(zone.coords.x, zone.coords.y, zone.coords.z),
                radius = zone.radius
            })
        end
    end

    local hospitals = {}
    if Config.Hospitals then
        for _, hosp in ipairs(Config.Hospitals) do
            local beds = {}
            if hosp.beds then
                for _, bed in ipairs(hosp.beds) do
                    table.insert(beds, {
                        line = FormatVector4String(bed.line.x, bed.line.y, bed.line.z, bed.line.w)
                    })
                end
            end
            table.insert(hospitals, {
                name = hosp.name,
                center = FormatVector3String(hosp.center.x, hosp.center.y, hosp.center.z),
                radius = hosp.radius,
                beds = beds
            })
        end
    end

    local settings = {
        ambulance_job = {
            AmbulanceJob = Config.AmbulanceJob,
            AmbulanceJobName = Config.AmbulanceJobName or "ambulance",
            CountOnlyOnDutyDoctors = Config.CountOnlyOnDutyDoctors,
            FundJobName = Config.FundJobName or ResolveFundJobName(nil, Config.AmbulanceJobName or "ambulance")
        },
        vehicle_models = {
            HeliModel = Config.HeliModel,
            CarModel = Config.CarModel,
            BoatModel = Config.BoatModel,
            SubModel = Config.SubModel
        },
        doctor_revive = {
            DisableAIEMSAboveDoctorCount = Config.DisableAIEMSAboveDoctorCount,
            CallPayment = Config.CallPayment,
            RevivePayment = Config.RevivePayment,
            ReviveTime = Config.ReviveTime,
            EMSArrivalTime = Config.EMSArrivalTime,
            UseProgressBar = Config.UseProgressBar,
            SetHealthAmount = Config.SetHealthAmount,
            ReviveHealthAmount = Config.ReviveHealthAmount
        },
        commands_keybinds = {
            AlivePlayerCanCall = Config.AlivePlayerCanCall,
            RegisterKeybind = Config.RegisterKeybind,
            Keybind = Config.Keybind,
            QuickAction = Config.QuickAction,
            QuickActionKey = Config.QuickActionKey,
            QuickActionCommand = Config.QuickActionCommand,
            WalkingNPCMode = Config.WalkingNPCMode,
            WalkingNPCSpawnRadius = Config.WalkingNPCSpawnRadius,
            AutoSelectEMSType = Config.AutoSelectEMSType,
            CallCommand = Config.CallCommand,
            VehicleArgs = Config.VehicleArgs,
            CancelCommand = Config.CancelCommand,
            SendEMSCommand = Config.SendEMSCommand
        },
        inventory = {
            ClearInventoryOnRevive = Config.ClearInventoryOnRevive,
            KeepItemsOnRevive = Config.KeepItemsOnRevive
        },
        restricted_zones = {
            zones = zones
        },
        hospital_revive = {
            HospitalRevive = Config.HospitalRevive,
            HospitalSendDelayMs = Config.HospitalSendDelayMs,
            HospitalGetUpKey = Config.HospitalGetUpKey,
            Hospitals = hospitals
        },
        blips = Config.BlipSettings,
        custom_ped = {
            UseCustomPED = Config.UseCustomPED,
            DefaultPedModel = Config.DefaultPedModel,
            CustomPED = Config.CustomPED
        },
        vehicle_spawn = {
            HeliSpawnHeight = Config.HeliSpawnHeight,
            HeliDescendDistance = Config.HeliDescendDistance,
            CarSpawnRange = Config.CarSpawnRange,
            CarExitDistanceOutdoor = Config.CarExitDistanceOutdoor,
            CarExitDistanceMLO = Config.CarExitDistanceMLO,
            BoatSpawnRange = Config.BoatSpawnRange,
            SubSpawnRange = Config.SubSpawnRange
        }
    }
    return settings
end

DeepCopy = RuntimeSettings
DeepMerge = DeepMerge
RuntimeDebug = RuntimeDebug

SETTINGS_CATEGORIES = {
    "ambulance_job",
    "vehicle_models",
    "doctor_revive",
    "commands_keybinds",
    "inventory",
    "restricted_zones",
    "hospital_revive",
    "blips",
    "custom_ped",
    "vehicle_spawn"
}

DefaultSettings = {
    ambulance_job = {
        AmbulanceJob = "default",
        AmbulanceJobName = "ambulance",
        CountOnlyOnDutyDoctors = true,
        FundJobName = "ambulance"
    },
    vehicle_models = {
        HeliModel = { model = "polmav", livery = 1 },
        CarModel = { model = "ambulance", livery = 2 },
        BoatModel = { model = "seashark2", livery = 0 },
        SubModel = { model = "Submersible", livery = 0 }
    },
    doctor_revive = {
        DisableAIEMSAboveDoctorCount = 0,
        CallPayment = 500,
        RevivePayment = 1500,
        ReviveTime = 5000,
        EMSArrivalTime = 60,
        UseProgressBar = true,
        SetHealthAmount = false,
        ReviveHealthAmount = 80
    },
    commands_keybinds = {
        AlivePlayerCanCall = false,
        RegisterKeybind = true,
        Keybind = "y",
        QuickAction = true,
        QuickActionKey = "K",
        QuickActionCommand = "car",
        WalkingNPCMode = false,
        WalkingNPCSpawnRadius = 50,
        AutoSelectEMSType = false,
        CallCommand = "aiems",
        VehicleArgs = { Heli = "heli", Car = "car", Boat = "boat", Sub = "merin" },
        CancelCommand = "cancelaiems",
        SendEMSCommand = "sendems"
    },
    inventory = {
        ClearInventoryOnRevive = true,
        KeepItemsOnRevive = { "phone", "radio" }
    },
    restricted_zones = {
        zones = {
            { name = "Pillbox Hospital", coords = "342.34, -584.84, 74.16", radius = 50.0 }
        }
    },
    hospital_revive = {
        HospitalRevive = false,
        HospitalSendDelayMs = 2500,
        HospitalGetUpKey = 38,
        Hospitals = {
            {
                name = "Pillbox Hospital",
                center = "315.27, -591.35, 43.28",
                radius = 100.0,
                beds = {
                    { line = "314.55, -584.38, 44.20, 345.99" },
                    { line = "317.84, -585.29, 44.20, 348.97" }
                }
            },
            {
                name = "Sandy Shores Hospital",
                center = "1839.6, 3672.93, 34.28",
                radius = 75.0,
                beds = {
                    { line = "1848.53, 3702.34, 34.76, 120.90" },
                    { line = "1841.97, 3698.68, 34.72, 122.00" }
                }
            }
        }
    },
    blips = {
        car = { sprite = 61, color = 5, flash = true },
        boat = { sprite = 410, color = 5, flash = true },
        heli = { sprite = 43, color = 5, flash = true },
        sub = { sprite = 308, color = 5, flash = true },
        walking = { sprite = 61, color = 5, flash = true }
    },
    custom_ped = {
        UseCustomPED = false,
        DefaultPedModel = "s_m_m_paramedic_01",
        CustomPED = {
            model = "mp_f_freemode_01",
            face = {
                shapeFirst = 21,
                shapeSecond = 25,
                skinFirst = 10,
                skinSecond = 12,
                shapeMix = 0.2,
                skinMix = 0.1
            },
            hair = { hair = 1 },
            makeup = {
                makeupType = 4,
                makeupOpacity = 0.4,
                makeupColor = 24,
                makeupSecondaryColor = 0,
                blushOpacity = 0.4,
                blushColor = 22,
                lipstickOpacity = 1,
                lipstickColor = 0
            },
            clothes = {
                { componentId = 11, drawableId = 565, textureId = 0 },
                { componentId = 8, drawableId = 15, textureId = 0 },
                { componentId = 3, drawableId = 15, textureId = 0 },
                { componentId = 4, drawableId = 6, textureId = 0 },
                { componentId = 6, drawableId = 0, textureId = 0 }
            }
        }
    },
    vehicle_spawn = {
        HeliSpawnHeight = 100,
        HeliDescendDistance = 15,
        CarSpawnRange = 100,
        CarExitDistanceOutdoor = 10,
        CarExitDistanceMLO = 70,
        BoatSpawnRange = 200,
        SubSpawnRange = 50
    }
}

ApplySettingsToConfig(DefaultSettings)
RuntimeDebug("defaults", "Default settings applied to Config on load")

SettingsSchema = {
    ambulance_job = {
        AmbulanceJob = { type = "string" },
        AmbulanceJobName = { type = "string" },
        CountOnlyOnDutyDoctors = { type = "boolean" },
        FundJobName = { type = "string" }
    },
    vehicle_models = {
        HeliModel = {
            type = "table",
            fields = {
                model = { type = "string" },
                livery = { type = "number", min = 0 }
            }
        },
        CarModel = {
            type = "table",
            fields = {
                model = { type = "string" },
                livery = { type = "number", min = 0 }
            }
        },
        BoatModel = {
            type = "table",
            fields = {
                model = { type = "string" },
                livery = { type = "number", min = 0 }
            }
        },
        SubModel = {
            type = "table",
            fields = {
                model = { type = "string" },
                livery = { type = "number", min = 0 }
            }
        }
    },
    doctor_revive = {
        DisableAIEMSAboveDoctorCount = { type = "number", min = 0 },
        CallPayment = { type = "number", min = 0 },
        RevivePayment = { type = "number", min = 0 },
        ReviveTime = { type = "number", min = 1000 },
        EMSArrivalTime = { type = "number", min = 5 },
        UseProgressBar = { type = "boolean" },
        SetHealthAmount = { type = "boolean" },
        ReviveHealthAmount = { type = "number", min = 1, max = 100 }
    },
    commands_keybinds = {
        AlivePlayerCanCall = { type = "boolean" },
        RegisterKeybind = { type = "boolean" },
        Keybind = { type = "string" },
        QuickAction = { type = "boolean" },
        QuickActionKey = { type = "string" },
        QuickActionCommand = { type = "string" },
        WalkingNPCMode = { type = "boolean" },
        WalkingNPCSpawnRadius = { type = "number", min = 10 },
        AutoSelectEMSType = { type = "boolean" },
        CallCommand = { type = "string" },
        VehicleArgs = { type = "table" },
        CancelCommand = { type = "string" },
        SendEMSCommand = { type = "string" }
    },
    inventory = {
        ClearInventoryOnRevive = { type = "boolean" },
        KeepItemsOnRevive = { type = "array" }
    },
    restricted_zones = {
        zones = { type = "array" }
    },
    hospital_revive = {
        HospitalRevive = { type = "boolean" },
        HospitalSendDelayMs = { type = "number", min = 0 },
        HospitalGetUpKey = { type = "number", min = 0 },
        Hospitals = { type = "array" }
    },
    blips = {
        car = { type = "table", fields = { sprite = "number", color = "number", flash = "boolean" } },
        boat = { type = "table", fields = { sprite = "number", color = "number", flash = "boolean" } },
        heli = { type = "table", fields = { sprite = "number", color = "number", flash = "boolean" } },
        sub = { type = "table", fields = { sprite = "number", color = "number", flash = "boolean" } },
        walking = { type = "table", fields = { sprite = "number", color = "number", flash = "boolean" } }
    },
    custom_ped = {
        UseCustomPED = { type = "boolean" },
        DefaultPedModel = { type = "string" },
        CustomPED = { type = "table" }
    },
    vehicle_spawn = {
        HeliSpawnHeight = { type = "number", min = 10 },
        HeliDescendDistance = { type = "number", min = 5 },
        CarSpawnRange = { type = "number", min = 20 },
        CarExitDistanceOutdoor = { type = "number", min = 1 },
        CarExitDistanceMLO = { type = "number", min = 10 },
        BoatSpawnRange = { type = "number", min = 20 },
        SubSpawnRange = { type = "number", min = 10 }
    }
}
