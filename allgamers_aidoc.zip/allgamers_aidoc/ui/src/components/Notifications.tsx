import { useEffect } from 'react';
import { useI18n } from '../i18n';

export interface NotificationItem {
  id: number;
  message: string;
  type: string;
}

const NOTIFICATION_DURATION_MS = 3500;

function NotificationEntry({ item, onRemove }: { item: NotificationItem; onRemove: (id: number) => void }) {
  const { t } = useI18n();
  const variant = item.type === 'success' ? 'success' : item.type === 'error' ? 'error' : 'info';

  useEffect(() => {
    const timer = window.setTimeout(() => onRemove(item.id), NOTIFICATION_DURATION_MS);
    return () => window.clearTimeout(timer);
  }, [item.id, onRemove]);

  return (
    <div className={`notif-item notif-${variant}`}>
      <div className="notif-badge">{variant === 'success' ? '✓' : variant === 'error' ? '✕' : 'i'}</div>
      <div className="notif-body">
        <div className="notif-title">{t(`notif.${variant}`)}</div>
        <div className="notif-msg">{item.message}</div>
      </div>
      <span className="notif-ems-badge">EMS</span>
      <span className="notif-timer" />
    </div>
  );
}

export function Notifications({ items, onRemove }: { items: NotificationItem[]; onRemove: (id: number) => void }) {
  return (
    <div className="notif-stack">
      {items.map((item) => (
        <NotificationEntry key={item.id} item={item} onRemove={onRemove} />
      ))}
    </div>
  );
}
