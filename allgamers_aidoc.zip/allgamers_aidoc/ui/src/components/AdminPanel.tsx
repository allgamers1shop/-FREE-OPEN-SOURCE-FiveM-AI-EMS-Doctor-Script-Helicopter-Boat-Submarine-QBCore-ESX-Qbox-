import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { fetchNui, useEscapeKey } from '../lib/nui';
import { hasTranslation, useI18n } from '../i18n';
import {
  ADMIN_STATE_KEY,
  clearStoredAdminState,
  normalizeSettings,
  parseJobNames,
  readStoredAdminState,
} from '../lib/settings';
import type {
  BlipConfig,
  CategoryKey,
  ClothingItem,
  Hospital,
  HospitalBed,
  NuiResponse,
  RestrictedZone,
  SelectOption,
  Settings,
  TabKey,
  VehicleModel,
} from '../lib/types';
import { CoordsField, NumberField, SectionCard, SelectField, TagsField, TextField, ToggleField } from './Fields';
import { BrandMark, CloseIcon, HeartbeatLine, PlusIcon, TabIcon, TrashIcon } from './Icons';
import { LanguageSwitcher } from './LanguageSwitcher';

export type SyncState = { status: 'idle' | 'ok' | 'error'; at: number };

interface AdminPanelProps {
  settings: Settings;
  ambulanceScriptOptions: SelectOption[];
  onSettingsChange: (settings: Settings) => void;
  onClose: () => void;
  syncState: SyncState;
}

const NAV_GROUPS: { labelKey: string; items: TabKey[] }[] = [
  { labelKey: 'nav.main', items: ['ambulance_job', 'vehicle_models', 'doctor_revive', 'commands_keybinds'] },
  { labelKey: 'nav.features', items: ['inventory', 'restricted_zones', 'hospital_revive', 'blips', 'custom_ped', 'vehicle_spawn'] },
  { labelKey: 'nav.staff', items: ['admin_dispatch'] },
];

const TOAST_DURATION_MS = 3000;

export function AdminPanel({ settings, ambulanceScriptOptions, onSettingsChange, onClose, syncState }: AdminPanelProps) {
  const { t } = useI18n();
  const [activeTab, setActiveTab] = useState<TabKey>('ambulance_job');
  const [hydrated, setHydrated] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [busy, setBusy] = useState(false);
  const [toast, setToast] = useState<{ msg: string; type: 'success' | 'error'; id: number } | null>(null);
  const [dispatchPlayerId, setDispatchPlayerId] = useState('');
  const [dispatchVehicle, setDispatchVehicle] = useState(() =>
    settings.commands_keybinds.WalkingNPCMode ? 'walking' : settings.commands_keybinds.VehicleArgs.Car,
  );
  const contentRef = useRef<HTMLDivElement>(null);
  const toastTimer = useRef<number>(0);

  useLayoutEffect(() => {
    if (contentRef.current) contentRef.current.scrollTop = 0;
  }, [activeTab]);

  useEffect(() => {
    if (hydrated) return;
    const stored = readStoredAdminState();
    if (stored?.pendingSettings) {
      setActiveTab((stored.activeTab as TabKey) || 'ambulance_job');
      onSettingsChange(stored.pendingSettings);
      setDirty(true);
    }
    setHydrated(true);
  }, [hydrated, onSettingsChange]);

  useEffect(() => {
    if (!hydrated) return;
    localStorage.setItem(
      ADMIN_STATE_KEY,
      JSON.stringify({ activeTab, pendingSettings: settings, dirty, timestamp: Date.now() }),
    );
  }, [activeTab, settings, dirty, hydrated]);

  useEffect(() => () => window.clearTimeout(toastTimer.current), []);

  const dispatchOptions = useMemo<SelectOption[]>(() => {
    const commands = settings.commands_keybinds;
    if (commands.WalkingNPCMode) return [{ value: 'walking', label: t('opt.walking') }];
    const args = commands.VehicleArgs;
    return [
      { value: args.Heli, label: t('opt.heli', { arg: args.Heli }) },
      { value: args.Car, label: t('opt.car', { arg: args.Car }) },
      { value: args.Boat, label: t('opt.boat', { arg: args.Boat }) },
      { value: args.Sub, label: t('opt.sub', { arg: args.Sub }) },
    ];
  }, [settings.commands_keybinds, t]);

  useEffect(() => {
    if (activeTab !== 'admin_dispatch') return;
    const commands = settings.commands_keybinds;
    setDispatchVehicle(commands.WalkingNPCMode ? 'walking' : commands.VehicleArgs.Car);
  }, [activeTab, settings.commands_keybinds]);

  const closePanel = useCallback(() => {
    fetchNui('closeUi', { view: 'admin' });
    onClose();
  }, [onClose]);

  useEscapeKey(closePanel);

  const showToast = (msg: string, type: 'success' | 'error') => {
    window.clearTimeout(toastTimer.current);
    setToast({ msg, type, id: Date.now() });
    toastTimer.current = window.setTimeout(() => setToast(null), TOAST_DURATION_MS);
  };

  const updateCategory = <K extends CategoryKey>(category: K, patch: Partial<Settings[K]>) => {
    onSettingsChange({ ...settings, [category]: { ...settings[category], ...patch } });
    setDirty(true);
  };

  const dispatchEms = async () => {
    const targetPlayerId = parseInt(dispatchPlayerId.trim(), 10);
    if (Number.isNaN(targetPlayerId) || targetPlayerId < 1) {
      showToast(t('toast.invalid_id'), 'error');
      return;
    }
    setBusy(true);
    try {
      const response = await fetchNui('adminDispatchEMS', { targetPlayerId, vehicleType: dispatchVehicle });
      if (response.success) showToast(t('toast.dispatch_ok', { id: targetPlayerId }), 'success');
      else showToast(response.error || t('toast.request_failed'), 'error');
    } catch {
      showToast(t('toast.network_error'), 'error');
    }
    setBusy(false);
  };

  const saveCategory = async (category: CategoryKey) => {
    setBusy(true);
    try {
      const response = await fetchNui('saveSettingsCategory', { categoryName: category, categoryData: settings[category] });
      if (response.success) {
        showToast(t('toast.saved', { label: t(`tab.${category}`) }), 'success');
        setDirty(false);
        clearStoredAdminState();
      } else {
        showToast(response.error || t('toast.save_failed'), 'error');
      }
    } catch {
      showToast(t('toast.network_error'), 'error');
    }
    setBusy(false);
  };

  const saveAll = async () => {
    setBusy(true);
    try {
      const response = await fetchNui('saveAllSettings', { settings });
      if (response.success) {
        showToast(t('toast.all_saved'), 'success');
        setDirty(false);
        clearStoredAdminState();
      } else {
        showToast(response.error || t('toast.save_failed'), 'error');
      }
    } catch {
      showToast(t('toast.network_error'), 'error');
    }
    setBusy(false);
  };

  const resetCategory = async (category: CategoryKey) => {
    try {
      const response = await fetchNui('resetSettingsCategory', { categoryName: category });
      if (response.success) {
        const current = await fetchNui<NuiResponse>('requestCurrentSettings');
        if (current.settings) onSettingsChange(normalizeSettings(current.settings));
        showToast(t('toast.reset_done'), 'success');
      } else {
        showToast(response.error || t('toast.reset_failed'), 'error');
      }
    } catch {
      showToast(t('toast.network_error'), 'error');
    }
  };

  const restoreDefaults = async () => {
    try {
      const response = await fetchNui('restoreDefaultSettings');
      if (response.success) {
        const current = await fetchNui<NuiResponse>('requestCurrentSettings');
        if (current.settings) onSettingsChange(normalizeSettings(current.settings));
        showToast(t('toast.restored'), 'success');
        setDirty(false);
        clearStoredAdminState();
      } else {
        showToast(response.error || t('toast.reset_failed'), 'error');
      }
    } catch {
      showToast(t('toast.network_error'), 'error');
    }
  };

  const renderVehicleModel = (titleKey: string, model: VehicleModel, onChange: (model: VehicleModel) => void) => (
    <div className="vehicle-model-cell">
      <div className="vehicle-model-cell-title">{t(titleKey)}</div>
      <TextField label={t('f.model')} hint={t('hint.vm_model')} value={model.model} onChange={(value) => onChange({ ...model, model: value })} narrow />
      <NumberField label={t('f.livery')} hint={t('hint.vm_livery')} value={model.livery} onChange={(value) => onChange({ ...model, livery: value })} min={0} />
    </div>
  );

  const renderBlip = (titleKey: string, blip: BlipConfig, onChange: (blip: BlipConfig) => void) => (
    <SectionCard title={t(titleKey)} className="section-card--blips form-grid--controls-right">
      <NumberField label={t('f.sprite')} hint={t('hint.blip_sprite')} value={blip.sprite} onChange={(value) => onChange({ ...blip, sprite: value })} min={0} />
      <NumberField label={t('f.color')} hint={t('hint.blip_color')} value={blip.color} onChange={(value) => onChange({ ...blip, color: value })} min={0} />
      <ToggleField label={t('f.flash')} hint={t('hint.blip_flash')} value={blip.flash} onChange={(value) => onChange({ ...blip, flash: value })} />
    </SectionCard>
  );

  const renderZones = () => {
    const zones = settings.restricted_zones.zones || [];
    const setZones = (next: RestrictedZone[]) => updateCategory('restricted_zones', { zones: next });
    const patchZone = (index: number, patch: Partial<RestrictedZone>) => {
      const next = [...zones];
      next[index] = { ...next[index], ...patch };
      setZones(next);
    };

    return (
      <div className="list-stack">
        {zones.map((zone, index) => (
          <SectionCard key={index} title={zone.name || t('zone.numbered', { n: index + 1 })} collapsible defaultOpen={false}>
            <TextField label={t('f.name')} hint={t('hint.zone_name')} value={zone.name} onChange={(value) => patchZone(index, { name: value })} />
            <CoordsField
              label={t('f.coords')}
              hint={t('hint.zone_coords')}
              value={zone.coords}
              onChange={(value) => patchZone(index, { coords: value })}
              format="vector3"
              placeholder="-153.76, -977.43, 269.23"
            />
            <NumberField label={t('f.radius')} hint={t('hint.zone_radius')} value={zone.radius} onChange={(value) => patchZone(index, { radius: value })} min={1} suffix="m" />
            <button type="button" className="btn btn-danger btn-sm" onClick={() => setZones(zones.filter((_, i) => i !== index))}>
              <TrashIcon />
              <span>{t('action.remove_zone')}</span>
            </button>
          </SectionCard>
        ))}
        <button
          type="button"
          className="btn btn-primary btn-sm"
          onClick={() => setZones([...zones, { name: t('zone.new'), coords: '0, 0, 0', radius: 50 }])}
        >
          <PlusIcon />
          <span>{t('action.add_zone')}</span>
        </button>
      </div>
    );
  };

  const renderHospitals = () => {
    const hospitals = settings.hospital_revive.Hospitals || [];
    const setHospitals = (next: Hospital[]) => updateCategory('hospital_revive', { Hospitals: next });
    const patchHospital = (index: number, patch: Partial<Hospital>) => {
      const next = [...hospitals];
      next[index] = { ...next[index], ...patch };
      setHospitals(next);
    };
    const setBeds = (index: number, beds: HospitalBed[]) => patchHospital(index, { beds });

    return (
      <div className="list-stack">
        {hospitals.map((hospital, index) => (
          <SectionCard key={index} title={hospital.name || t('hosp.numbered', { n: index + 1 })} collapsible defaultOpen={false}>
            <TextField label={t('f.name')} hint={t('hint.hosp_name')} value={hospital.name} onChange={(value) => patchHospital(index, { name: value })} />
            <CoordsField
              label={t('f.center')}
              hint={t('hint.hosp_center')}
              value={hospital.center}
              onChange={(value) => patchHospital(index, { center: value })}
              format="vector3"
              placeholder="315.27, -591.35, 43.28"
            />
            <NumberField label={t('f.radius')} hint={t('hint.hosp_radius')} value={hospital.radius} onChange={(value) => patchHospital(index, { radius: value })} min={1} suffix="m" />
            <div className="beds-section">
              <h4 className="beds-title">
                {t('hosp.beds')}
                <span className="beds-count">{hospital.beds.length}</span>
              </h4>
              {hospital.beds.map((bed, bedIndex) => (
                <div className="bed-row bed-row-line" key={bedIndex}>
                  <CoordsField
                    label={t('hosp.bed_n', { n: bedIndex + 1 })}
                    value={bed.line}
                    onChange={(value) => {
                      const beds = [...hospital.beds];
                      beds[bedIndex] = { line: value };
                      setBeds(index, beds);
                    }}
                    format="vector4"
                    placeholder="x, y, z, heading"
                  />
                  <button
                    type="button"
                    className="btn btn-danger btn-icon"
                    aria-label={t('action.remove')}
                    onClick={() => setBeds(index, hospital.beds.filter((_, i) => i !== bedIndex))}
                  >
                    <TrashIcon />
                  </button>
                </div>
              ))}
              <p className="field-hint-inline">{t('hint.hosp_bed')}</p>
              <button type="button" className="btn btn-primary btn-xs" onClick={() => setBeds(index, [...hospital.beds, { line: '0, 0, 0, 0' }])}>
                <PlusIcon />
                <span>{t('action.add_bed')}</span>
              </button>
            </div>
            <button type="button" className="btn btn-danger btn-sm" onClick={() => setHospitals(hospitals.filter((_, i) => i !== index))}>
              <TrashIcon />
              <span>{t('action.remove_hospital')}</span>
            </button>
          </SectionCard>
        ))}
        <button
          type="button"
          className="btn btn-primary btn-sm"
          onClick={() => setHospitals([...hospitals, { name: t('hosp.new'), center: '0, 0, 0', radius: 75, beds: [] }])}
        >
          <PlusIcon />
          <span>{t('action.add_hospital')}</span>
        </button>
      </div>
    );
  };

  const renderClothes = () => {
    const clothes = settings.custom_ped.CustomPED?.clothes || [];
    const setClothes = (next: ClothingItem[]) =>
      updateCategory('custom_ped', { CustomPED: { ...settings.custom_ped.CustomPED, clothes: next } });
    const patchItem = (index: number, patch: Partial<ClothingItem>) => {
      const next = [...clothes];
      next[index] = { ...next[index], ...patch };
      setClothes(next);
    };

    return (
      <div>
        {clothes.map((item, index) => (
          <div className="clothes-row" key={index}>
            <span className="clothes-index">{String(index + 1).padStart(2, '0')}</span>
            <NumberField label={t('f.component')} value={item.componentId} onChange={(value) => patchItem(index, { componentId: value })} min={0} />
            <NumberField label={t('f.drawable')} value={item.drawableId} onChange={(value) => patchItem(index, { drawableId: value })} min={0} />
            <NumberField label={t('f.texture')} value={item.textureId} onChange={(value) => patchItem(index, { textureId: value })} min={0} />
            <button
              type="button"
              className="btn btn-danger btn-icon"
              aria-label={t('action.remove')}
              onClick={() => setClothes(clothes.filter((_, i) => i !== index))}
            >
              <TrashIcon />
            </button>
          </div>
        ))}
        <button type="button" className="btn btn-primary btn-xs" onClick={() => setClothes([...clothes, { componentId: 0, drawableId: 0, textureId: 0 }])}>
          <PlusIcon />
          <span>{t('action.add_clothing')}</span>
        </button>
      </div>
    );
  };

  const pedLabel = (key: string) => (hasTranslation(`ped.${key}`) ? t(`ped.${key}`) : key);

  const renderTab = () => {
    switch (activeTab) {
      case 'ambulance_job': {
        const job = settings.ambulance_job;
        const jobNames = parseJobNames(job.AmbulanceJobName);
        const fundJob = jobNames.includes(job.FundJobName) ? job.FundJobName : jobNames[0];
        return (
          <SectionCard title={t('sec.ambulance_job')}>
            <SelectField
              label={t('f.amb_script')}
              hint={t('hint.amb_script')}
              value={job.AmbulanceJob}
              options={ambulanceScriptOptions}
              onChange={(value) => updateCategory('ambulance_job', { AmbulanceJob: value })}
            />
            <TextField
              label={t('f.amb_jobs')}
              hint={t('hint.amb_jobs')}
              value={job.AmbulanceJobName}
              onChange={(value) => {
                const names = parseJobNames(value);
                const currentFund = job.FundJobName;
                const keepFund = currentFund && names.includes(currentFund);
                updateCategory('ambulance_job', { AmbulanceJobName: value, FundJobName: keepFund ? currentFund : names[0] });
              }}
              placeholder="ambulance, paramedic"
              multiline
              inlineMultiline
              narrow
            />
            <SelectField
              label={t('f.amb_fund')}
              hint={t('hint.amb_fund')}
              value={fundJob}
              options={jobNames.map((name) => ({ value: name, label: name }))}
              onChange={(value) => updateCategory('ambulance_job', { FundJobName: value })}
              narrow
            />
            <ToggleField
              label={t('f.amb_duty')}
              hint={t('hint.amb_duty')}
              value={job.CountOnlyOnDutyDoctors}
              onChange={(value) => updateCategory('ambulance_job', { CountOnlyOnDutyDoctors: value })}
            />
          </SectionCard>
        );
      }

      case 'vehicle_models': {
        const models = settings.vehicle_models;
        return (
          <SectionCard title={t('sec.vehicle_models')}>
            <div className="vehicle-models-grid">
              {renderVehicleModel('veh.heli', models.HeliModel, (value) => updateCategory('vehicle_models', { HeliModel: value }))}
              {renderVehicleModel('veh.car', models.CarModel, (value) => updateCategory('vehicle_models', { CarModel: value }))}
              {renderVehicleModel('veh.boat', models.BoatModel, (value) => updateCategory('vehicle_models', { BoatModel: value }))}
              {renderVehicleModel('veh.sub', models.SubModel, (value) => updateCategory('vehicle_models', { SubModel: value }))}
            </div>
          </SectionCard>
        );
      }

      case 'doctor_revive': {
        const revive = settings.doctor_revive;
        return (
          <SectionCard title={t('sec.doctor_revive')}>
            <NumberField label={t('f.dr_disable_above')} hint={t('hint.dr_disable_above')} value={revive.DisableAIEMSAboveDoctorCount} onChange={(value) => updateCategory('doctor_revive', { DisableAIEMSAboveDoctorCount: value })} min={0} />
            <NumberField label={t('f.dr_call_pay')} hint={t('hint.dr_call_pay')} value={revive.CallPayment} onChange={(value) => updateCategory('doctor_revive', { CallPayment: value })} min={0} suffix="$" />
            <NumberField label={t('f.dr_revive_pay')} hint={t('hint.dr_revive_pay')} value={revive.RevivePayment} onChange={(value) => updateCategory('doctor_revive', { RevivePayment: value })} min={0} suffix="$" />
            <NumberField label={t('f.dr_revive_time')} hint={t('hint.dr_revive_time')} value={revive.ReviveTime} onChange={(value) => updateCategory('doctor_revive', { ReviveTime: value })} min={1000} step={500} suffix="ms" />
            <NumberField label={t('f.dr_arrival')} hint={t('hint.dr_arrival')} value={revive.EMSArrivalTime} onChange={(value) => updateCategory('doctor_revive', { EMSArrivalTime: value })} min={5} suffix={t('unit.sec')} />
            <ToggleField label={t('f.dr_progress')} hint={t('hint.dr_progress')} value={revive.UseProgressBar} onChange={(value) => updateCategory('doctor_revive', { UseProgressBar: value })} />
            <ToggleField label={t('f.dr_set_health')} hint={t('hint.dr_set_health')} value={revive.SetHealthAmount} onChange={(value) => updateCategory('doctor_revive', { SetHealthAmount: value })} />
            {revive.SetHealthAmount && (
              <NumberField label={t('f.dr_health_pct')} hint={t('hint.dr_health_pct')} value={revive.ReviveHealthAmount} onChange={(value) => updateCategory('doctor_revive', { ReviveHealthAmount: value })} min={1} max={100} suffix="%" />
            )}
          </SectionCard>
        );
      }

      case 'commands_keybinds': {
        const commands = settings.commands_keybinds;
        const setArg = (key: keyof typeof commands.VehicleArgs, value: string) =>
          updateCategory('commands_keybinds', { VehicleArgs: { ...commands.VehicleArgs, [key]: value } });
        return (
          <>
            <SectionCard title={t('sec.general')}>
              <ToggleField label={t('f.cmd_alive')} hint={t('hint.cmd_alive')} value={commands.AlivePlayerCanCall} onChange={(value) => updateCategory('commands_keybinds', { AlivePlayerCanCall: value })} />
              <ToggleField label={t('f.cmd_walk_mode')} hint={t('hint.cmd_walk_mode')} value={commands.WalkingNPCMode} onChange={(value) => updateCategory('commands_keybinds', { WalkingNPCMode: value })} />
              {commands.WalkingNPCMode && (
                <NumberField label={t('f.cmd_walk_radius')} hint={t('hint.cmd_walk_radius')} value={commands.WalkingNPCSpawnRadius} onChange={(value) => updateCategory('commands_keybinds', { WalkingNPCSpawnRadius: value })} min={10} suffix="m" />
              )}
              <ToggleField label={t('f.cmd_auto_type')} hint={t('hint.cmd_auto_type')} value={commands.AutoSelectEMSType} onChange={(value) => updateCategory('commands_keybinds', { AutoSelectEMSType: value })} />
            </SectionCard>
            <SectionCard title={t('sec.keybinds')}>
              <ToggleField label={t('f.cmd_reg_keybind')} hint={t('hint.cmd_reg_keybind')} value={commands.RegisterKeybind} onChange={(value) => updateCategory('commands_keybinds', { RegisterKeybind: value })} />
              {commands.RegisterKeybind && (
                <TextField label={t('f.cmd_keybind')} hint={t('hint.cmd_keybind')} value={commands.Keybind} onChange={(value) => updateCategory('commands_keybinds', { Keybind: value })} narrow />
              )}
              <ToggleField label={t('f.cmd_quick')} hint={t('hint.cmd_quick')} value={commands.QuickAction} onChange={(value) => updateCategory('commands_keybinds', { QuickAction: value })} />
              {commands.QuickAction && (
                <>
                  <TextField label={t('f.cmd_quick_key')} hint={t('hint.cmd_quick_key')} value={commands.QuickActionKey} onChange={(value) => updateCategory('commands_keybinds', { QuickActionKey: value })} narrow />
                  <TextField label={t('f.cmd_quick_type')} hint={t('hint.cmd_quick_type')} value={commands.QuickActionCommand} onChange={(value) => updateCategory('commands_keybinds', { QuickActionCommand: value })} narrow />
                </>
              )}
              <p className="form-hint">{t('note.keybind_restart')}</p>
            </SectionCard>
            <SectionCard title={t('sec.commands')}>
              <TextField label={t('f.cmd_call')} hint={t('hint.cmd_call')} value={commands.CallCommand} onChange={(value) => updateCategory('commands_keybinds', { CallCommand: value })} narrow />
              <TextField label={t('f.cmd_cancel')} hint={t('hint.cmd_cancel')} value={commands.CancelCommand} onChange={(value) => updateCategory('commands_keybinds', { CancelCommand: value })} narrow />
              <TextField label={t('f.cmd_send')} hint={t('hint.cmd_send')} value={commands.SendEMSCommand} onChange={(value) => updateCategory('commands_keybinds', { SendEMSCommand: value })} narrow />
              <p className="form-hint">{t('note.command_restart')}</p>
            </SectionCard>
            <SectionCard title={t('sec.vehicle_args')}>
              <TextField label={t('f.varg_heli')} hint={t('hint.cmd_varg')} value={commands.VehicleArgs.Heli} onChange={(value) => setArg('Heli', value)} narrow />
              <TextField label={t('f.varg_car')} hint={t('hint.cmd_varg')} value={commands.VehicleArgs.Car} onChange={(value) => setArg('Car', value)} narrow />
              <TextField label={t('f.varg_boat')} hint={t('hint.cmd_varg')} value={commands.VehicleArgs.Boat} onChange={(value) => setArg('Boat', value)} narrow />
              <TextField label={t('f.varg_sub')} hint={t('hint.cmd_varg')} value={commands.VehicleArgs.Sub} onChange={(value) => setArg('Sub', value)} narrow />
            </SectionCard>
          </>
        );
      }

      case 'inventory': {
        const inventory = settings.inventory;
        return (
          <SectionCard title={t('sec.inventory')}>
            <ToggleField label={t('f.inv_clear')} hint={t('hint.inv_clear')} value={inventory.ClearInventoryOnRevive} onChange={(value) => updateCategory('inventory', { ClearInventoryOnRevive: value })} />
            {inventory.ClearInventoryOnRevive && (
              <TagsField
                label={t('f.inv_keep')}
                hint={t('hint.inv_keep')}
                values={inventory.KeepItemsOnRevive}
                onChange={(values) => updateCategory('inventory', { KeepItemsOnRevive: values })}
                placeholder={t('ph.inv_keep')}
              />
            )}
          </SectionCard>
        );
      }

      case 'restricted_zones':
        return <SectionCard title={t('sec.restricted_zones')}>{renderZones()}</SectionCard>;

      case 'hospital_revive': {
        const hospital = settings.hospital_revive;
        return (
          <>
            <SectionCard title={t('sec.hospital_settings')}>
              <ToggleField label={t('f.hosp_enable')} hint={t('hint.hosp_enable')} value={hospital.HospitalRevive} onChange={(value) => updateCategory('hospital_revive', { HospitalRevive: value })} />
              {hospital.HospitalRevive && (
                <>
                  <NumberField label={t('f.hosp_delay')} hint={t('hint.hosp_delay')} value={hospital.HospitalSendDelayMs} onChange={(value) => updateCategory('hospital_revive', { HospitalSendDelayMs: value })} min={0} suffix="ms" />
                  <NumberField label={t('f.hosp_key')} hint={t('hint.hosp_key')} value={hospital.HospitalGetUpKey} onChange={(value) => updateCategory('hospital_revive', { HospitalGetUpKey: value })} min={0} />
                </>
              )}
            </SectionCard>
            {hospital.HospitalRevive && <SectionCard title={t('sec.hospitals')}>{renderHospitals()}</SectionCard>}
          </>
        );
      }

      case 'blips': {
        const blips = settings.blips;
        return (
          <div className="blips-grid">
            {renderBlip('blip.car', blips.car, (value) => updateCategory('blips', { ...blips, car: value }))}
            {renderBlip('blip.boat', blips.boat, (value) => updateCategory('blips', { ...blips, boat: value }))}
            {renderBlip('blip.heli', blips.heli, (value) => updateCategory('blips', { ...blips, heli: value }))}
            {renderBlip('blip.sub', blips.sub, (value) => updateCategory('blips', { ...blips, sub: value }))}
            {renderBlip('blip.walking', blips.walking, (value) => updateCategory('blips', { ...blips, walking: value }))}
          </div>
        );
      }

      case 'custom_ped': {
        const ped = settings.custom_ped;
        const custom = ped.CustomPED;
        return (
          <>
            <SectionCard title={t('sec.ped_config')} className="form-grid--controls-right">
              <ToggleField label={t('f.ped_use')} hint={t('hint.ped_use')} value={ped.UseCustomPED} onChange={(value) => updateCategory('custom_ped', { UseCustomPED: value })} />
              {!ped.UseCustomPED && (
                <TextField label={t('f.ped_default')} hint={t('hint.ped_default')} value={ped.DefaultPedModel} onChange={(value) => updateCategory('custom_ped', { DefaultPedModel: value })} />
              )}
            </SectionCard>
            {ped.UseCustomPED && custom && (
              <>
                <SectionCard title={t('sec.freemode')} className="form-grid--controls-right">
                  <TextField label={t('f.model')} value={custom.model} onChange={(value) => updateCategory('custom_ped', { CustomPED: { ...custom, model: value } })} />
                </SectionCard>
                <SectionCard title={t('sec.face')} collapsible defaultOpen={false} className="form-grid--controls-right">
                  {Object.entries(custom.face || {}).map(([key, value]) => (
                    <NumberField key={key} label={pedLabel(key)} value={value} onChange={(next) => updateCategory('custom_ped', { CustomPED: { ...custom, face: { ...custom.face, [key]: next } } })} step={0.1} />
                  ))}
                </SectionCard>
                <SectionCard title={t('sec.hair')} collapsible defaultOpen={false} className="form-grid--controls-right">
                  {Object.entries(custom.hair || {}).map(([key, value]) => (
                    <NumberField key={key} label={pedLabel(key)} value={value} onChange={(next) => updateCategory('custom_ped', { CustomPED: { ...custom, hair: { ...custom.hair, [key]: next } } })} />
                  ))}
                </SectionCard>
                <SectionCard title={t('sec.makeup')} collapsible defaultOpen={false} className="form-grid--controls-right">
                  {Object.entries(custom.makeup || {}).map(([key, value]) => (
                    <NumberField key={key} label={pedLabel(key)} value={value} onChange={(next) => updateCategory('custom_ped', { CustomPED: { ...custom, makeup: { ...custom.makeup, [key]: next } } })} step={0.1} />
                  ))}
                </SectionCard>
                <SectionCard title={t('sec.clothing')} collapsible defaultOpen={false} className="form-grid--controls-right">
                  {renderClothes()}
                </SectionCard>
              </>
            )}
          </>
        );
      }

      case 'vehicle_spawn': {
        const spawn = settings.vehicle_spawn;
        return (
          <SectionCard title={t('sec.vehicle_spawn')}>
            <NumberField label={t('f.vs_heli_h')} hint={t('hint.vs_heli_h')} value={spawn.HeliSpawnHeight} onChange={(value) => updateCategory('vehicle_spawn', { HeliSpawnHeight: value })} min={10} suffix={t('unit.units')} />
            <NumberField label={t('f.vs_heli_d')} hint={t('hint.vs_heli_d')} value={spawn.HeliDescendDistance} onChange={(value) => updateCategory('vehicle_spawn', { HeliDescendDistance: value })} min={5} suffix={t('unit.units')} />
            <NumberField label={t('f.vs_car_r')} hint={t('hint.vs_car_r')} value={spawn.CarSpawnRange} onChange={(value) => updateCategory('vehicle_spawn', { CarSpawnRange: value })} min={20} suffix="m" />
            <NumberField label={t('f.vs_car_out')} hint={t('hint.vs_car_out')} value={spawn.CarExitDistanceOutdoor} onChange={(value) => updateCategory('vehicle_spawn', { CarExitDistanceOutdoor: value })} min={1} suffix="m" />
            <NumberField label={t('f.vs_car_mlo')} hint={t('hint.vs_car_mlo')} value={spawn.CarExitDistanceMLO} onChange={(value) => updateCategory('vehicle_spawn', { CarExitDistanceMLO: value })} min={10} suffix="m" />
            <NumberField label={t('f.vs_boat')} hint={t('hint.vs_boat')} value={spawn.BoatSpawnRange} onChange={(value) => updateCategory('vehicle_spawn', { BoatSpawnRange: value })} min={20} suffix="m" />
            <NumberField label={t('f.vs_sub')} hint={t('hint.vs_sub')} value={spawn.SubSpawnRange} onChange={(value) => updateCategory('vehicle_spawn', { SubSpawnRange: value })} min={10} suffix="m" />
          </SectionCard>
        );
      }

      case 'admin_dispatch':
        return (
          <SectionCard title={t('sec.dispatch')} className="section-card--dispatch">
            <div className="dispatch-radar" aria-hidden>
              <span className="dispatch-radar-sweep" />
              <span className="dispatch-radar-dot" />
            </div>
            <p className="admin-dispatch-intro">{t('dispatch.intro')}</p>
            <TextField
              label={t('f.player_id')}
              hint={t('hint.player_id')}
              value={dispatchPlayerId}
              onChange={(value) => setDispatchPlayerId(value.replace(/[^\d]/g, ''))}
              placeholder="12"
              narrow
            />
            <SelectField
              label={t('f.vehicle_type')}
              hint={t('hint.vehicle_type')}
              value={dispatchVehicle}
              options={dispatchOptions}
              onChange={setDispatchVehicle}
              narrow
            />
            <button type="button" className="btn btn-accent btn-glow admin-dispatch-btn" onClick={dispatchEms} disabled={busy}>
              {busy ? t('action.sending') : t('action.send_doctor')}
            </button>
          </SectionCard>
        );

      default:
        return null;
    }
  };

  const syncLabel =
    syncState.status === 'ok'
      ? `${t('status.synced')} · ${new Date(syncState.at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`
      : syncState.status === 'error'
        ? t('status.sync_error')
        : t('status.online');

  return (
    <div className="admin-overlay">
      <div className="ai-backdrop" aria-hidden>
        <div className="ai-backdrop-grid" />
        <div className="ai-backdrop-glow ai-backdrop-glow--a" />
        <div className="ai-backdrop-glow ai-backdrop-glow--b" />
        <div className="ai-backdrop-scan" />
      </div>

      <div className="admin-frame">
        <div className="admin-panel">
          <aside className="admin-sidebar">
            <div className="sidebar-brand">
              <div className="sidebar-brand-mark">
                <BrandMark />
              </div>
              <div className="sidebar-brand-text">
                <span className="sidebar-title">
                  <span className="sidebar-title-ai">AI</span> EMS
                </span>
                <span className="sidebar-sub">{t('brand.sub')}</span>
              </div>
              <span className="sidebar-version">v2.1.0</span>
            </div>

            <nav className="sidebar-nav" tabIndex={0} onMouseEnter={(event) => event.currentTarget.focus({ preventScroll: true })}>
              {NAV_GROUPS.map((group) => (
                <div className="sidebar-nav-group" key={group.labelKey}>
                  <div className="sidebar-nav-label">{t(group.labelKey)}</div>
                  {group.items.map((tab) => (
                    <button
                      type="button"
                      key={tab}
                      className={`sidebar-tab ${activeTab === tab ? 'active' : ''}`}
                      onClick={() => setActiveTab(tab)}
                    >
                      <span className="sidebar-tab-icon">
                        <TabIcon tab={tab} />
                      </span>
                      <span className="sidebar-tab-label">{t(`tab.${tab}`)}</span>
                    </button>
                  ))}
                </div>
              ))}
            </nav>

            <div className="sidebar-footer">
              <LanguageSwitcher />
              <button type="button" className="btn btn-ghost btn-ghost-full" onClick={restoreDefaults}>
                {t('action.restore_all')}
              </button>
            </div>
          </aside>

          <div className="admin-content">
            <header className="content-topbar">
              <HeartbeatLine className="topbar-ecg" />
              <div className="content-topbar-main">
                <div className="content-heading">
                  <p className="content-eyebrow">
                    <span className={`status-dot status-dot--${syncState.status}`} />
                    {t('content.eyebrow')} · {syncLabel}
                  </p>
                  <h2 className="content-title" key={activeTab}>
                    {t(`tab.${activeTab}`)}
                  </h2>
                </div>
                <div className="topbar-actions">
                  {activeTab !== 'admin_dispatch' && (
                    <>
                      {dirty && <span className="unsaved-badge">{t('content.unsaved')}</span>}
                      <button type="button" className="btn btn-secondary" onClick={() => resetCategory(activeTab)} disabled={busy}>
                        {t('action.reset_section')}
                      </button>
                      <button type="button" className="btn btn-primary btn-shine" onClick={() => saveCategory(activeTab)} disabled={busy}>
                        {busy ? t('action.saving') : t('action.save_section')}
                      </button>
                      <button type="button" className="btn btn-accent" onClick={saveAll} disabled={busy}>
                        {t('action.save_all')}
                      </button>
                    </>
                  )}
                </div>
              </div>
              <button type="button" className="content-close" onClick={closePanel} aria-label={t('action.close')}>
                <CloseIcon />
              </button>
            </header>

            <div
              ref={contentRef}
              className="content-body"
              tabIndex={0}
              onMouseEnter={(event) => event.currentTarget.focus({ preventScroll: true })}
            >
              <div className="content-tab-pane" key={activeTab}>
                {renderTab()}
              </div>
            </div>
          </div>
        </div>
      </div>

      {toast && (
        <div key={toast.id} className={`toast toast-${toast.type}`}>
          <span className="toast-icon">{toast.type === 'success' ? '✓' : '!'}</span>
          <span className="toast-msg">{toast.msg}</span>
          <span className="toast-timer" />
        </div>
      )}
    </div>
  );
}
