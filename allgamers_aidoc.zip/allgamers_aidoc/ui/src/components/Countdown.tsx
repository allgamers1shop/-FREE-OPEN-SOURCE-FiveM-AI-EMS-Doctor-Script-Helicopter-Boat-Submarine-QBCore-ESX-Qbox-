import { useEffect, useRef, useState } from 'react';
import { useI18n } from '../i18n';

interface CountdownProps {
  totalTime: number;
  onDone: () => void;
}

export function Countdown({ totalTime, onDone }: CountdownProps) {
  const { t } = useI18n();
  const [remaining, setRemaining] = useState(totalTime);
  const onDoneRef = useRef(onDone);
  onDoneRef.current = onDone;

  useEffect(() => {
    setRemaining(totalTime);
    const interval = window.setInterval(() => {
      setRemaining((current) => {
        if (current <= 1) {
          window.clearInterval(interval);
          onDoneRef.current();
          return 0;
        }
        return current - 1;
      });
    }, 1000);
    return () => window.clearInterval(interval);
  }, [totalTime]);

  const minutes = Math.floor(remaining / 60);
  const seconds = remaining % 60;
  const progress = totalTime > 0 ? Math.max(0, Math.min(1, remaining / totalTime)) : 0;

  return (
    <div className="countdown-bar">
      <span className="countdown-pulse" aria-hidden>
        <span />
      </span>
      <div className="countdown-text">
        <span className="countdown-eyebrow">{t('countdown.eyebrow')}</span>
        <span className="countdown-label">
          {t('countdown.label')}
          <span className="countdown-time">
            {minutes}:{seconds.toString().padStart(2, '0')}
          </span>
        </span>
      </div>
      <span className="countdown-progress" aria-hidden>
        <span style={{ transform: `scaleX(${progress})` }} />
      </span>
    </div>
  );
}
