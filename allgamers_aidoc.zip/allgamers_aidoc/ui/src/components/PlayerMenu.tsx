import { useCallback, useState } from 'react';
import { fetchNui, imageUrl, useEscapeKey } from '../lib/nui';
import { useI18n } from '../i18n';
import type { PlayerMenuOption } from '../lib/types';
import { BrandMark, CloseIcon, HeartbeatLine, VehicleIcon } from './Icons';
import { LanguageSwitcher } from './LanguageSwitcher';

interface PlayerMenuProps {
  options: PlayerMenuOption[];
  callPayment: number;
  onClose: () => void;
}

function iconKind(option: PlayerMenuOption): string {
  const image = (option.image || '').replace(/\.[a-z]+$/i, '').toLowerCase();
  if (['heli', 'car', 'boat', 'sub', 'walking', 'auto'].includes(image)) return image;
  return option.id === 'walking' || option.id === 'auto' ? option.id : 'default';
}

function OptionVisual({ option }: { option: PlayerMenuOption }) {
  const [imageFailed, setImageFailed] = useState(!option.image);

  return (
    <div className="ems-card-image">
      <div className="ems-card-image-grid" aria-hidden />
      {imageFailed ? (
        <span className="ems-card-icon">
          <VehicleIcon kind={iconKind(option)} />
        </span>
      ) : (
        <img src={imageUrl(option.image as string)} alt={option.title} onError={() => setImageFailed(true)} />
      )}
      <span className="ems-card-scan" aria-hidden />
    </div>
  );
}

export function PlayerMenu({ options, callPayment, onClose }: PlayerMenuProps) {
  const { t } = useI18n();

  const closeMenu = useCallback(() => {
    fetchNui('closeUi', { view: 'player' });
    onClose();
  }, [onClose]);

  useEscapeKey(closeMenu);

  const choose = (vehicleType: string) => {
    fetchNui('submitPlayerVehicleChoice', { vehicleType });
  };

  return (
    <div className="player-overlay">
      <div className="ai-backdrop" aria-hidden>
        <div className="ai-backdrop-grid" />
        <div className="ai-backdrop-glow ai-backdrop-glow--a" />
        <div className="ai-backdrop-scan" />
      </div>

      <div className="player-frame">
        <div className="player-panel" tabIndex={0} onMouseEnter={(event) => event.currentTarget.focus({ preventScroll: true })}>
          <div className="player-toolbar">
            <LanguageSwitcher compact />
            <button type="button" className="player-close" onClick={closeMenu} aria-label={t('action.close')}>
              <CloseIcon />
            </button>
          </div>

          <div className="player-header">
            <div className="player-brand">
              <span className="player-brand-mark">
                <BrandMark />
              </span>
              <span className="player-eyebrow">{t('player.eyebrow')}</span>
            </div>
            <h2 className="player-title">{t('player.title')}</h2>
            <p className="player-subtitle">{t('player.subtitle')}</p>
            {callPayment > 0 && <span className="player-cost">{t('player.fee', { fee: callPayment })}</span>}
            <HeartbeatLine className="player-ecg" />
          </div>

          <div className="player-grid">
            {options.map((option, index) => (
              <button
                type="button"
                key={option.id}
                className="ems-card"
                style={{ animationDelay: `${Math.min(index, 12) * 60}ms` }}
                onClick={() => choose(option.id)}
              >
                <OptionVisual option={option} />
                <div className="ems-card-info">
                  <h3 className="ems-card-title">{option.title}</h3>
                  <p className="ems-card-desc">{option.description}</p>
                </div>
              </button>
            ))}
          </div>

          <p className="player-hint">{t('player.hint')}</p>
        </div>
      </div>
    </div>
  );
}
