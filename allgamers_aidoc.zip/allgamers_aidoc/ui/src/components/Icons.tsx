import type { ReactNode } from 'react';

const STROKE_PROPS = {
  width: 18,
  height: 18,
  viewBox: '0 0 24 24',
  fill: 'none',
  stroke: 'currentColor',
  strokeWidth: 1.75,
  strokeLinecap: 'round' as const,
  strokeLinejoin: 'round' as const,
};

function Svg({ children, size }: { children: ReactNode; size?: number }) {
  return (
    <svg aria-hidden {...STROKE_PROPS} width={size ?? 18} height={size ?? 18}>
      {children}
    </svg>
  );
}

export function TabIcon({ tab }: { tab: string }) {
  switch (tab) {
    case 'ambulance_job':
      return (
        <Svg>
          <rect x="4" y="3" width="16" height="18" rx="2" />
          <path d="M12 8v8M8 12h8" />
        </Svg>
      );
    case 'vehicle_models':
      return (
        <Svg>
          <path d="M4 17h2l1-4h10l1 4h2" />
          <circle cx="7.5" cy="17" r="1.5" />
          <circle cx="16.5" cy="17" r="1.5" />
          <path d="M6 13l2-5h8l2 5" />
        </Svg>
      );
    case 'doctor_revive':
      return (
        <Svg>
          <path d="M3 12h4l2-5 3 10 2-5h7" />
        </Svg>
      );
    case 'commands_keybinds':
      return (
        <Svg>
          <rect x="3" y="5" width="18" height="14" rx="2" />
          <path d="M7 9h2M11 9h2M15 9h2M7 13h6" />
        </Svg>
      );
    case 'inventory':
      return (
        <Svg>
          <path d="M8 4h8l2 4v12a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V8l2-4z" />
          <path d="M8 8h8" />
        </Svg>
      );
    case 'restricted_zones':
      return (
        <Svg>
          <circle cx="12" cy="12" r="8" />
          <path d="M6.5 6.5l11 11" />
        </Svg>
      );
    case 'hospital_revive':
      return (
        <Svg>
          <path d="M4 20V8l8-4 8 4v12" />
          <path d="M9 20v-6h6v6" />
          <path d="M12 7v4M10 9h4" />
        </Svg>
      );
    case 'blips':
      return (
        <Svg>
          <path d="M12 21s7-5.2 7-11a7 7 0 1 0-14 0c0 5.8 7 11 7 11z" />
          <circle cx="12" cy="10" r="2.5" />
        </Svg>
      );
    case 'custom_ped':
      return (
        <Svg>
          <circle cx="12" cy="8" r="3.5" />
          <path d="M6 20v-1a6 6 0 0 1 12 0v1" />
        </Svg>
      );
    case 'vehicle_spawn':
      return (
        <Svg>
          <path d="M12 3v4M12 17v4M4 12h4M16 12h4" />
          <circle cx="12" cy="12" r="3" />
        </Svg>
      );
    case 'admin_dispatch':
      return (
        <Svg>
          <path d="M22 12h-4l-3 9L9 3 6 12H2" />
        </Svg>
      );
    default:
      return (
        <Svg>
          <circle cx="12" cy="12" r="9" />
        </Svg>
      );
  }
}

export function VehicleIcon({ kind, size = 56 }: { kind: string; size?: number }) {
  switch (kind) {
    case 'heli':
      return (
        <Svg size={size}>
          <path d="M3 5h18M12 5v3" />
          <path d="M6 12a5 4 0 0 1 5-4h3a4 4 0 0 1 4 4v1a3 3 0 0 1-3 3H9a3 3 0 0 1-3-3z" />
          <path d="M18 12h3l1-2M9 16l-1 3M15 16l1 3M6 19h12" />
        </Svg>
      );
    case 'car':
      return (
        <Svg size={size}>
          <path d="M3 16V9a2 2 0 0 1 2-2h9l4 4h1a2 2 0 0 1 2 2v3h-2" />
          <path d="M3 16h2M9 16h6" />
          <circle cx="7" cy="16.5" r="1.8" />
          <circle cx="17" cy="16.5" r="1.8" />
          <path d="M8 9.5v3M6.5 11h3" />
        </Svg>
      );
    case 'boat':
      return (
        <Svg size={size}>
          <path d="M3 15l2 4h14l2-4H3z" />
          <path d="M6 15V9h8l3 6" />
          <path d="M10 6v3" />
          <path d="M2 21c2 0 2-1 4-1s2 1 4 1 2-1 4-1 2 1 4 1 2-1 4-1" />
        </Svg>
      );
    case 'sub':
      return (
        <Svg size={size}>
          <path d="M4 14a6 4 0 0 1 6-4h6a4 4 0 0 1 0 8h-6a6 4 0 0 1-6-4z" />
          <path d="M11 10V7h3v3M20 12l2-2v8l-2-2" />
          <circle cx="9" cy="14" r="1" />
          <circle cx="13" cy="14" r="1" />
        </Svg>
      );
    case 'walking':
      return (
        <Svg size={size}>
          <circle cx="13" cy="4.5" r="2" />
          <path d="M10 21l2-6 3 3v3M12 15l-1-5 4 2 3 1M11 10l-3 2-1 3" />
        </Svg>
      );
    case 'auto':
      return (
        <Svg size={size}>
          <circle cx="12" cy="12" r="8" />
          <circle cx="12" cy="12" r="3" />
          <path d="M12 2v3M12 19v3M2 12h3M19 12h3" />
        </Svg>
      );
    default:
      return (
        <Svg size={size}>
          <path d="M12 6v12M6 12h12" />
        </Svg>
      );
  }
}

export function CloseIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden>
      <path d="M18 6L6 18M6 6l12 12" />
    </svg>
  );
}

export function GlobeIcon() {
  return (
    <Svg size={16}>
      <circle cx="12" cy="12" r="9" />
      <path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18" />
    </Svg>
  );
}

export function CrosshairIcon() {
  return (
    <Svg size={14}>
      <circle cx="12" cy="12" r="7" />
      <path d="M12 2v4M12 18v4M2 12h4M18 12h4" />
    </Svg>
  );
}

export function PlusIcon() {
  return (
    <Svg size={14}>
      <path d="M12 5v14M5 12h14" />
    </Svg>
  );
}

export function TrashIcon() {
  return (
    <Svg size={14}>
      <path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3" />
    </Svg>
  );
}

export function BrandMark() {
  return (
    <svg width="34" height="34" viewBox="0 0 40 40" fill="none" aria-hidden>
      <rect className="brand-mark-ring" x="2" y="2" width="36" height="36" rx="11" stroke="currentColor" strokeWidth="1.5" />
      <path d="M20 11v18M11 20h18" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" />
      <path className="brand-mark-pulse" pathLength={100} d="M5 27h7l2-4 3 7 3-10 2 7h13" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

const HEARTBEAT_PATH = 'M0 20h120l10-12 12 26 14-30 12 24 8-8h104l10-12 12 26 14-30 12 24 8-8h252';

export function HeartbeatLine({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 600 40" preserveAspectRatio="none" aria-hidden>
      <path className="ecg-base" d={HEARTBEAT_PATH} fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinejoin="round" />
      <path
        className="ecg-pulse"
        d={HEARTBEAT_PATH}
        pathLength={1000}
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
