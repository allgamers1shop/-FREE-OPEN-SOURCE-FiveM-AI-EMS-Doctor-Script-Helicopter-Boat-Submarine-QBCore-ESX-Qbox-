import { LANGUAGES, useI18n, type LanguageCode } from '../i18n';
import { GlobeIcon } from './Icons';

export function LanguageSwitcher({ compact = false }: { compact?: boolean }) {
  const { language, setLanguage, t } = useI18n();

  return (
    <label className={`lang-switch${compact ? ' lang-switch--compact' : ''}`} title={t('language')}>
      <span className="lang-switch-icon">
        <GlobeIcon />
      </span>
      {!compact && <span className="lang-switch-label">{t('language')}</span>}
      <select
        className="lang-switch-select"
        value={language}
        onChange={(event) => setLanguage(event.target.value as LanguageCode)}
      >
        {LANGUAGES.map((lang) => (
          <option key={lang.code} value={lang.code}>
            {lang.label}
          </option>
        ))}
      </select>
    </label>
  );
}
