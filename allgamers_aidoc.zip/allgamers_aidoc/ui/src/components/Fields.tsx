import { useState, type ReactNode } from 'react';
import { fetchNui } from '../lib/nui';
import { useI18n } from '../i18n';
import type { SelectOption } from '../lib/types';
import { CrosshairIcon } from './Icons';

function LabelGroup({ label, hint }: { label: string; hint?: string }) {
  return (
    <div className="form-label-group">
      <span className="form-label">{label}</span>
      {hint && <span className="field-hint">{hint}</span>}
    </div>
  );
}

interface ToggleFieldProps {
  label: string;
  hint?: string;
  value: boolean;
  onChange: (value: boolean) => void;
}

export function ToggleField({ label, hint, value, onChange }: ToggleFieldProps) {
  return (
    <div className="form-row">
      <LabelGroup label={label} hint={hint} />
      <button
        type="button"
        className={`toggle-btn ${value ? 'toggle-on' : 'toggle-off'}`}
        onClick={() => onChange(!value)}
        aria-pressed={value}
      >
        <span className="toggle-knob" />
      </button>
    </div>
  );
}

interface NumberFieldProps {
  label: string;
  hint?: string;
  value: number;
  onChange: (value: number) => void;
  min?: number;
  max?: number;
  step?: number;
  suffix?: string;
}

export function NumberField({ label, hint, value, onChange, min, max, step = 1, suffix }: NumberFieldProps) {
  return (
    <div className="form-row form-row--numeric">
      <LabelGroup label={label} hint={hint} />
      <div className="form-control-slot">
        <input
          type="number"
          className="form-input number-input"
          value={value}
          onChange={(event) => onChange(Number(event.target.value))}
          min={min}
          max={max}
          step={step}
        />
        {suffix ? <span className="input-suffix">{suffix}</span> : <span className="input-suffix input-suffix--spacer" aria-hidden />}
      </div>
    </div>
  );
}

interface TextFieldProps {
  label: string;
  hint?: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  multiline?: boolean;
  inlineMultiline?: boolean;
  narrow?: boolean;
}

export function TextField({ label, hint, value, onChange, placeholder, multiline, inlineMultiline, narrow }: TextFieldProps) {
  const rowClass = multiline
    ? inlineMultiline
      ? `form-row form-row--textarea-inline${narrow ? ' form-row--text-narrow' : ''}`
      : `form-row form-row-col${narrow ? ' form-row--med-text' : ''}`
    : `form-row form-row--text${narrow ? ' form-row--text-narrow' : ''}`;

  return (
    <div className={rowClass}>
      <LabelGroup label={label} hint={hint} />
      {multiline ? (
        <textarea
          className="form-input form-textarea"
          value={value}
          onChange={(event) => onChange(event.target.value)}
          placeholder={placeholder}
          rows={narrow ? 2 : 3}
        />
      ) : (
        <input
          type="text"
          className={`form-input${narrow ? ' form-input--narrow' : ''}`}
          value={value}
          onChange={(event) => onChange(event.target.value)}
          placeholder={placeholder}
        />
      )}
    </div>
  );
}

interface CoordsFieldProps {
  label: string;
  hint?: string;
  value: string;
  onChange: (value: string) => void;
  format: 'vector3' | 'vector4';
  placeholder?: string;
}

export function CoordsField({ label, hint, value, onChange, format, placeholder }: CoordsFieldProps) {
  const { t } = useI18n();
  const [loading, setLoading] = useState(false);

  const grabCoords = async () => {
    setLoading(true);
    try {
      const response = await fetchNui<{ coords?: string }>('getPlayerCoords', { format });
      if (response.coords) onChange(response.coords);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="form-row form-row--text">
      <LabelGroup label={label} hint={hint} />
      <div className="form-control-slot coord-input-slot">
        <input
          type="text"
          className="form-input form-input--mono"
          value={value}
          onChange={(event) => onChange(event.target.value)}
          placeholder={placeholder}
        />
        <button type="button" className="btn btn-secondary btn-coord" onClick={grabCoords} disabled={loading}>
          <CrosshairIcon />
          <span>{loading ? '...' : t('action.get_coords')}</span>
        </button>
      </div>
    </div>
  );
}

interface SelectFieldProps {
  label: string;
  hint?: string;
  value: string;
  options: SelectOption[];
  onChange: (value: string) => void;
  narrow?: boolean;
}

export function SelectField({ label, hint, value, options, onChange, narrow }: SelectFieldProps) {
  return (
    <div className={`form-row form-row--select${narrow ? ' form-row--select-narrow' : ''}`}>
      <LabelGroup label={label} hint={hint} />
      <select
        className={`form-select${narrow ? ' form-select--narrow' : ''}`}
        value={value}
        onChange={(event) => onChange(event.target.value)}
      >
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
    </div>
  );
}

interface TagsFieldProps {
  label: string;
  hint?: string;
  values: string[];
  onChange: (values: string[]) => void;
  placeholder?: string;
}

export function TagsField({ label, hint, values, onChange, placeholder }: TagsFieldProps) {
  const { t } = useI18n();

  const addTag = (raw: string) => {
    const tag = raw.trim();
    if (tag && !values.includes(tag)) onChange([...values, tag]);
  };

  const removeTag = (index: number) => {
    onChange(values.filter((_, i) => i !== index));
  };

  return (
    <div className="form-row form-row-col">
      <LabelGroup label={label} hint={hint} />
      <div className="tag-input-wrap">
        <div className="tag-list">
          {values.map((tag, index) => (
            <span className="tag" key={index}>
              {tag}
              <button type="button" className="tag-remove" onClick={() => removeTag(index)}>
                ×
              </button>
            </span>
          ))}
        </div>
        <input
          type="text"
          className="form-input"
          placeholder={placeholder || t('tags.placeholder')}
          onKeyDown={(event) => {
            if (event.key === 'Enter') {
              event.preventDefault();
              const input = event.target as HTMLInputElement;
              addTag(input.value);
              input.value = '';
            }
          }}
        />
      </div>
    </div>
  );
}

interface SectionCardProps {
  title: string;
  children: ReactNode;
  collapsible?: boolean;
  defaultOpen?: boolean;
  className?: string;
}

export function SectionCard({ title, children, collapsible = false, defaultOpen = true, className }: SectionCardProps) {
  const [open, setOpen] = useState(defaultOpen);

  return (
    <div className={`section-card${className ? ` ${className}` : ''}${collapsible && !open ? ' is-collapsed' : ''}`}>
      <div
        className={`section-header ${collapsible ? 'clickable' : ''}`}
        onClick={collapsible ? () => setOpen(!open) : undefined}
      >
        <span className="section-header-dot" aria-hidden />
        <h3 className="section-title">{title}</h3>
        {collapsible && <span className={`chevron ${open ? 'open' : ''}`}>▾</span>}
      </div>
      {(!collapsible || open) && <div className="section-body">{children}</div>}
    </div>
  );
}
