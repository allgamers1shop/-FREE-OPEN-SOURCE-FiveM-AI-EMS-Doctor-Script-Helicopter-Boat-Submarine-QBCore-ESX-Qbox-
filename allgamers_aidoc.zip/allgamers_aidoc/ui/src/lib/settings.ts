import type { Settings } from './types';

export const ADMIN_STATE_KEY = 'aidoc_admin_state';
export const ADMIN_STATE_TTL_MS = 1800 * 1000;

export interface StoredAdminState {
  activeTab?: string;
  pendingSettings?: Settings;
  dirty?: boolean;
  timestamp?: number;
}

export function readStoredAdminState(): StoredAdminState | null {
  const raw = localStorage.getItem(ADMIN_STATE_KEY);
  if (!raw) return null;
  try {
    const parsed = JSON.parse(raw) as StoredAdminState;
    if (Date.now() - (parsed.timestamp || 0) < ADMIN_STATE_TTL_MS && parsed.pendingSettings && parsed.dirty) {
      return parsed;
    }
  } catch {
    return null;
  }
  return null;
}

export function clearStoredAdminState() {
  localStorage.removeItem(ADMIN_STATE_KEY);
}

export function parseJobNames(value: unknown): string[] {
  const names: string[] = [];
  if (!value || typeof value !== 'string') return ['ambulance'];
  for (const part of value.split(',')) {
    const name = part.trim().toLowerCase();
    if (name) names.push(name);
  }
  return names.length > 0 ? names : ['ambulance'];
}

export function normalizeSettings(raw: any): Settings {
  const restrictedZones = { ...raw.restricted_zones };
  if (restrictedZones.zones && Array.isArray(restrictedZones.zones)) {
    restrictedZones.zones = restrictedZones.zones.map((zone: any) => {
      if (zone.coords && typeof zone.coords === 'string') {
        return { name: zone.name || 'Zone', coords: zone.coords, radius: zone.radius ?? 50 };
      }
      if (typeof zone.x === 'number' && typeof zone.y === 'number' && typeof zone.z === 'number') {
        return { name: zone.name || 'Zone', coords: `${zone.x}, ${zone.y}, ${zone.z}`, radius: zone.radius ?? 50 };
      }
      return { name: zone.name || 'Zone', coords: '0, 0, 0', radius: zone.radius ?? 50 };
    });
  }

  const hospitalRevive = { ...raw.hospital_revive };
  if (hospitalRevive.Hospitals && Array.isArray(hospitalRevive.Hospitals)) {
    hospitalRevive.Hospitals = hospitalRevive.Hospitals.map((hospital: any) => {
      let center = typeof hospital.center === 'string' ? hospital.center : '';
      if (!center && hospital.center_x != null && hospital.center_y != null && hospital.center_z != null) {
        center = `${hospital.center_x}, ${hospital.center_y}, ${hospital.center_z}`;
      }
      if (!center) center = '0, 0, 0';
      const beds = (hospital.beds || []).map((bed: any) => {
        if (bed.line && typeof bed.line === 'string') return { line: bed.line };
        if (typeof bed.x === 'number') return { line: `${bed.x}, ${bed.y}, ${bed.z}, ${bed.w}` };
        return { line: '0, 0, 0, 0' };
      });
      return { name: hospital.name || 'Hospital', center, radius: hospital.radius ?? 100, beds };
    });
  }

  const ambulanceJob = { ...raw.ambulance_job };
  const jobNames = parseJobNames(ambulanceJob.AmbulanceJobName || '');
  const fundJob = typeof ambulanceJob.FundJobName === 'string' ? ambulanceJob.FundJobName.trim().toLowerCase() : '';
  ambulanceJob.FundJobName = !fundJob || !jobNames.includes(fundJob) ? jobNames[0] : fundJob;

  return {
    ...raw,
    restricted_zones: restrictedZones,
    hospital_revive: hospitalRevive,
    ambulance_job: ambulanceJob,
  } as Settings;
}
