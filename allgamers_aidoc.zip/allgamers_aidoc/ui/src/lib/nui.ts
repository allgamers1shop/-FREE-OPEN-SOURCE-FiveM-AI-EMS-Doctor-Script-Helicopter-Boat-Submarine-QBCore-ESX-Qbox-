import { useEffect, useRef } from 'react';
import type { NuiResponse } from './types';

declare global {
  interface Window {
    GetParentResourceName?: () => string;
  }
}

export function getResourceName(): string {
  return typeof window.GetParentResourceName === 'function'
    ? window.GetParentResourceName()
    : 'allgamers_aidoc';
}

export function fetchNui<T = NuiResponse>(callbackName: string, payload?: unknown): Promise<T> {
  return fetch(`https://${getResourceName()}/${callbackName}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload ?? {}),
  }).then((response) => response.json() as Promise<T>);
}

export function useNuiEvent<T = any>(type: string, handler: (data: T) => void) {
  const handlerRef = useRef(handler);
  handlerRef.current = handler;

  useEffect(() => {
    const listener = (event: MessageEvent) => {
      if (event.data?.type === type) handlerRef.current(event.data as T);
    };
    window.addEventListener('message', listener);
    return () => window.removeEventListener('message', listener);
  }, [type]);
}

export function useEscapeKey(onEscape: () => void) {
  const handlerRef = useRef(onEscape);
  handlerRef.current = onEscape;

  useEffect(() => {
    const listener = (event: KeyboardEvent) => {
      if (event.key === 'Escape') handlerRef.current();
    };
    window.addEventListener('keydown', listener);
    return () => window.removeEventListener('keydown', listener);
  }, []);
}

export function imageUrl(fileName: string): string {
  return `nui://${getResourceName()}/ui/build/img/${fileName}`;
}
