export interface VehicleModel {
  model: string;
  livery: number;
}

export interface BlipConfig {
  sprite: number;
  color: number;
  flash: boolean;
}

export interface RestrictedZone {
  name: string;
  coords: string;
  radius: number;
}

export interface HospitalBed {
  line: string;
}

export interface Hospital {
  name: string;
  center: string;
  radius: number;
  beds: HospitalBed[];
}

export interface ClothingItem {
  componentId: number;
  drawableId: number;
  textureId: number;
}

export interface CustomPed {
  model: string;
  face?: Record<string, number>;
  hair?: Record<string, number>;
  makeup?: Record<string, number>;
  clothes?: ClothingItem[];
}

export interface VehicleArgs {
  Heli: string;
  Car: string;
  Boat: string;
  Sub: string;
}

export interface Settings {
  ambulance_job: {
    AmbulanceJob: string;
    AmbulanceJobName: string;
    CountOnlyOnDutyDoctors: boolean;
    FundJobName: string;
  };
  vehicle_models: {
    HeliModel: VehicleModel;
    CarModel: VehicleModel;
    BoatModel: VehicleModel;
    SubModel: VehicleModel;
  };
  doctor_revive: {
    DisableAIEMSAboveDoctorCount: number;
    CallPayment: number;
    RevivePayment: number;
    ReviveTime: number;
    EMSArrivalTime: number;
    UseProgressBar: boolean;
    SetHealthAmount: boolean;
    ReviveHealthAmount: number;
  };
  commands_keybinds: {
    AlivePlayerCanCall: boolean;
    RegisterKeybind: boolean;
    Keybind: string;
    QuickAction: boolean;
    QuickActionKey: string;
    QuickActionCommand: string;
    WalkingNPCMode: boolean;
    WalkingNPCSpawnRadius: number;
    AutoSelectEMSType: boolean;
    CallCommand: string;
    VehicleArgs: VehicleArgs;
    CancelCommand: string;
    SendEMSCommand: string;
  };
  inventory: {
    ClearInventoryOnRevive: boolean;
    KeepItemsOnRevive: string[];
  };
  restricted_zones: {
    zones: RestrictedZone[];
  };
  hospital_revive: {
    HospitalRevive: boolean;
    HospitalSendDelayMs: number;
    HospitalGetUpKey: number;
    Hospitals: Hospital[];
  };
  blips: {
    car: BlipConfig;
    boat: BlipConfig;
    heli: BlipConfig;
    sub: BlipConfig;
    walking: BlipConfig;
  };
  custom_ped: {
    UseCustomPED: boolean;
    DefaultPedModel: string;
    CustomPED: CustomPed;
  };
  vehicle_spawn: {
    HeliSpawnHeight: number;
    HeliDescendDistance: number;
    CarSpawnRange: number;
    CarExitDistanceOutdoor: number;
    CarExitDistanceMLO: number;
    BoatSpawnRange: number;
    SubSpawnRange: number;
  };
}

export type CategoryKey = keyof Settings;
export type TabKey = CategoryKey | 'admin_dispatch';

export interface SelectOption {
  value: string;
  label: string;
}

export interface PlayerMenuOption {
  id: string;
  title: string;
  description: string;
  image?: string;
}

export interface NuiResponse {
  success?: boolean;
  error?: string;
  settings?: Settings;
  coords?: string;
  options?: SelectOption[];
}
