import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import en from './en.json';
import es from './es.json';
import fr from './fr.json';
import de from './de.json';
import pt from './pt.json';
import tr from './tr.json';
import ru from './ru.json';
import bn from './bn.json';
import zhCn from './zh-cn.json';

type Dictionary = Record<string, string>;

export const LANGUAGES = [
  { code: 'en', label: 'English' },
  { code: 'es', label: 'Español' },
  { code: 'fr', label: 'Français' },
  { code: 'de', label: 'Deutsch' },
  { code: 'pt', label: 'Português' },
  { code: 'tr', label: 'Türkçe' },
  { code: 'ru', label: 'Русский' },
  { code: 'bn', label: 'বাংলা' },
  { code: 'zh-cn', label: '简体中文' },
] as const;

export type LanguageCode = (typeof LANGUAGES)[number]['code'];

const DICTIONARIES: Record<LanguageCode, Dictionary> = {
  en,
  es,
  fr,
  de,
  pt,
  tr,
  ru,
  bn,
  'zh-cn': zhCn,
};

const STORAGE_KEY = 'aidoc_ui_lang';
const DEFAULT_LANGUAGE: LanguageCode = 'en';

export type Translate = (key: string, vars?: Record<string, string | number>) => string;

interface I18nContextValue {
  language: LanguageCode;
  setLanguage: (code: LanguageCode) => void;
  t: Translate;
}

const I18nContext = createContext<I18nContextValue | null>(null);

function isLanguageCode(value: unknown): value is LanguageCode {
  return typeof value === 'string' && value in DICTIONARIES;
}

function readStoredLanguage(): LanguageCode {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (isLanguageCode(stored)) return stored;
  } catch {
    return DEFAULT_LANGUAGE;
  }
  return DEFAULT_LANGUAGE;
}

export function I18nProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<LanguageCode>(readStoredLanguage);

  const setLanguage = useCallback((code: LanguageCode) => {
    setLanguageState(code);
    try {
      localStorage.setItem(STORAGE_KEY, code);
    } catch {
      /* storage unavailable */
    }
  }, []);

  useEffect(() => {
    document.documentElement.lang = language === 'zh-cn' ? 'zh-CN' : language;
  }, [language]);

  const t = useCallback<Translate>(
    (key, vars) => {
      let text = DICTIONARIES[language][key] ?? DICTIONARIES.en[key] ?? key;
      if (vars) {
        for (const [name, value] of Object.entries(vars)) {
          text = text.split(`{${name}}`).join(String(value));
        }
      }
      return text;
    },
    [language],
  );

  const value = useMemo(() => ({ language, setLanguage, t }), [language, setLanguage, t]);

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n(): I18nContextValue {
  const context = useContext(I18nContext);
  if (!context) throw new Error('useI18n must be used inside I18nProvider');
  return context;
}

export function hasTranslation(key: string): boolean {
  return key in DICTIONARIES.en;
}
