import { useCallback, useState } from 'react';
import { useNuiEvent } from './lib/nui';
import { normalizeSettings, readStoredAdminState } from './lib/settings';
import type { PlayerMenuOption, SelectOption, Settings } from './lib/types';
import { AdminPanel, type SyncState } from './components/AdminPanel';
import { PlayerMenu } from './components/PlayerMenu';
import { Countdown } from './components/Countdown';
import { Notifications, type NotificationItem } from './components/Notifications';

type View = 'hidden' | 'admin' | 'player';

let notificationCounter = 0;

export default function App() {
  const [view, setView] = useState<View>('hidden');
  const [settings, setSettings] = useState<Settings | null>(null);
  const [scriptOptions, setScriptOptions] = useState<SelectOption[]>([]);
  const [playerOptions, setPlayerOptions] = useState<PlayerMenuOption[]>([]);
  const [callPayment, setCallPayment] = useState(0);
  const [countdown, setCountdown] = useState<{ totalTime: number; nonce: number } | null>(null);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [syncState, setSyncState] = useState<SyncState>({ status: 'idle', at: 0 });

  useNuiEvent<{ settings: Settings; ambulanceScriptOptions?: SelectOption[] }>('aidoc:ui:openAdmin', (data) => {
    const stored = readStoredAdminState();
    try {
      setSettings(normalizeSettings(stored?.pendingSettings ?? data.settings));
    } catch {
      setSettings(normalizeSettings(data.settings));
    }
    setScriptOptions(data.ambulanceScriptOptions || []);
    setSyncState({ status: 'idle', at: 0 });
    setView('admin');
  });

  useNuiEvent('aidoc:ui:closeAdmin', () => setView('hidden'));

  useNuiEvent<{ category: string }>('aidoc:ui:saveSuccess', () => setSyncState({ status: 'ok', at: Date.now() }));

  useNuiEvent<{ category: string; error?: string }>('aidoc:ui:saveError', () =>
    setSyncState({ status: 'error', at: Date.now() }),
  );

  useNuiEvent<{ settings?: Settings }>('aidoc:ui:settingsUpdated', (data) => {
    if (data.settings) setSettings(normalizeSettings(data.settings));
  });

  useNuiEvent<{ options?: PlayerMenuOption[]; callPayment?: number }>('aidoc:ui:openPlayerMenu', (data) => {
    setPlayerOptions(data.options || []);
    setCallPayment(data.callPayment || 0);
    setView('player');
  });

  useNuiEvent('aidoc:ui:closePlayerMenu', () => setView('hidden'));

  useNuiEvent<{ totalTime: number }>('showCountdown', (data) => {
    setCountdown({ totalTime: Number(data.totalTime) || 0, nonce: Date.now() });
  });

  useNuiEvent('hideCountdown', () => setCountdown(null));

  useNuiEvent<{ message: string; notificationType: string }>('notification', (data) => {
    const item: NotificationItem = { id: ++notificationCounter, message: data.message, type: data.notificationType };
    setNotifications((current) => [...current, item]);
  });

  const removeNotification = useCallback((id: number) => {
    setNotifications((current) => current.filter((item) => item.id !== id));
  }, []);

  const hideCountdown = useCallback(() => setCountdown(null), []);
  const hideView = useCallback(() => setView('hidden'), []);

  return (
    <>
      {countdown && <Countdown key={countdown.nonce} totalTime={countdown.totalTime} onDone={hideCountdown} />}
      {notifications.length > 0 && <Notifications items={notifications} onRemove={removeNotification} />}
      {view === 'admin' && settings && (
        <AdminPanel
          settings={settings}
          ambulanceScriptOptions={scriptOptions}
          onSettingsChange={setSettings}
          onClose={hideView}
          syncState={syncState}
        />
      )}
      {view === 'player' && <PlayerMenu options={playerOptions} callPayment={callPayment} onClose={hideView} />}
    </>
  );
}
