function Notify(message, type)
    if Config.Notify == 'ox' then
        if lib and lib.notify then
            lib.notify({
                title = type == 'success' and 'Success' or (type == 'error' and 'Error' or 'Info'),
                description = message,
                type = type or 'inform',
                duration = 3500
            })
        else
            print('^1[allgamers AI Doctor]^7 Notifications not working - ox_lib or lib.notify is missing. Install ox_lib or change Config.Notify in config.lua.')
        end
    elseif Config.Notify == 'qb' or Config.Notify == 'esx' or Config.Notify == 'qbx' then
        ALLGAMERS.ShowNotification(message)
    elseif Config.Notify == 'bridge' then
        ALLGAMERS.ShowNotification(message)
    else
        SendNUIMessage({
            type = 'notification',
            message = message,
            notificationType = type
        })
    end
end

function IsPlayerDead()
    if Config.AmbulanceJob == "VisnAre" then
        local healthBuffer = exports.visn_are:GetHealthBuffer()
        return healthBuffer.unconscious
    elseif Config.AmbulanceJob == "wasabi_ambulance" then
        return exports.wasabi_ambulance:isPlayerDead()
    elseif Config.AmbulanceJob == "brutal_ambulancejob" then
        return exports.brutal_ambulancejob:IsDead()
    elseif Config.AmbulanceJob == "ars_ambulancejob" then
        return exports.ars_ambulancejob:isDead()
    elseif Config.AmbulanceJob == "osp_ambulance" then
        return exports["osp_ambulance"]:isDead()
    elseif Config.AmbulanceJob == "tk_ambulancejob" then
        return exports.tk_ambulancejob:isDead()
    elseif Config.AmbulanceJob == "quasar_ambulance" then
        local deathState = LocalPlayer.state.dead
        return deathState == "dead" or deathState == "lastStand"
    elseif Config.AmbulanceJob == "default" then
        return ALLGAMERS.GetIsPlayerDead()
    else
        return ALLGAMERS.GetIsPlayerDead()
    end
end

function ShowReviveProgressBar()
    if not Config.UseProgressBar then
        Citizen.Wait(Config.ReviveTime)
        return true
    end

    local success = lib.progressBar({
        duration = Config.ReviveTime,
        label = locale('progress_bar_label'),
        useWhileDead = true,
        canCancel = false,
        disable = {
            car = true,
            move = true,
            combat = true,
            mouse = false,
            sprint = true
        }
    })

    if success then
        return true
    else
        return false
    end
end

function DrawText3D(x, y, z, text)
    local onScreen, _x, _y = World3dToScreen2d(x, y, z)
    local px, py, pz = table.unpack(GetGameplayCamCoords())

    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(text)
    DrawText(_x, _y)
    local factor = (string.len(text)) / 370
    DrawRect(_x, _y + 0.0125, 0.015 + factor, 0.03, 41, 11, 41, 68)
end

function RevivePlayer()
    if Config.AmbulanceJob == "VisnAre" then
        TriggerEvent('visn_are:resetHealthBuffer')
        StopScreenEffect('DeathFailOut')
        TriggerEvent('allgamers_ai_doctor:client:ResetEMSCall')
    elseif Config.AmbulanceJob == "wasabi_ambulance" then
        TriggerServerEvent('allgamers:server:reviveWasabi')
        StopScreenEffect('DeathFailOut')
        TriggerEvent('allgamers_ai_doctor:client:ResetEMSCall')
    elseif Config.AmbulanceJob == "brutal_ambulancejob" then
        TriggerEvent('brutal_ambulancejob:revive')
        StopScreenEffect('DeathFailOut')
        TriggerEvent('allgamers_ai_doctor:client:ResetEMSCall')
    elseif Config.AmbulanceJob == "ars_ambulancejob" then
        TriggerEvent('ars_ambulancejob:healPlayer', {revive = true})
        StopScreenEffect('DeathFailOut')
        TriggerEvent('allgamers_ai_doctor:client:ResetEMSCall')
    elseif Config.AmbulanceJob == "osp_ambulance" then
        local playerId = GetPlayerServerId(PlayerId())
        TriggerServerEvent('osp_ambulance:revive', playerId)
        StopScreenEffect('DeathFailOut')
        TriggerEvent('allgamers_ai_doctor:client:ResetEMSCall')
    elseif Config.AmbulanceJob == "tk_ambulancejob" then
        local playerId = GetPlayerServerId(PlayerId())
        TriggerServerEvent('allgamers:server:reviveTkAmbulance', playerId)
        StopScreenEffect('DeathFailOut')
        TriggerEvent('allgamers_ai_doctor:client:ResetEMSCall')
    elseif Config.AmbulanceJob == "quasar_ambulance" then
        local playerId = GetPlayerServerId(PlayerId())
        TriggerServerEvent('allgamers:server:reviveQuasarAmbulance', playerId)
        StopScreenEffect('DeathFailOut')
        TriggerEvent('allgamers_ai_doctor:client:ResetEMSCall')
    elseif Config.AmbulanceJob == "default" then
        local playerId = GetPlayerServerId(PlayerId())
        TriggerServerEvent('allgamers_aidoc:server:revivePlayer', playerId)
        StopScreenEffect('DeathFailOut')
        TriggerEvent('allgamers_ai_doctor:client:ResetEMSCall')
    else
        StopScreenEffect('DeathFailOut')
        TriggerEvent('allgamers_ai_doctor:client:ResetEMSCall')
    end

    if Config.SetHealthAmount then
        Citizen.Wait(1000)
        local playerPed = PlayerPedId()
        local healthAmount = math.floor((Config.ReviveHealthAmount / 100) * 200)
        SetEntityHealth(playerPed, healthAmount)
    end

    if Config.ClearInventoryOnRevive then
        Citizen.Wait(1000)
        TriggerServerEvent('allgamers:clearInventory')
        Notify(locale('inventory_cleared'), "primary")
    end
end

function setVehicleFuel(vehicle, fuelLevel)
    if not DoesEntityExist(vehicle) then
        return
    end

    if ALLGAMERS and ALLGAMERS.SetFuel then
        ALLGAMERS.SetFuel(vehicle, fuelLevel)
    else
        SetVehicleFuelLevel(vehicle, fuelLevel)
    end
end

