local isAdminUIOpen = false

local function debugPrint(msg)
    if Config and Config.Debug then
        print('[allgamers_aidoc][debug][admin_ui] ' .. tostring(msg))
    end
end

local function open_admin_ui(settings, ambulanceScriptOptions)
    if isAdminUIOpen then
        debugPrint('Admin UI already open, ignoring')
        return
    end
    debugPrint('Opening admin UI')
    isAdminUIOpen = true
    SetNuiFocus(true, true)
    SendNUIMessage({
        type = 'aidoc:ui:openAdmin',
        settings = settings,
        ambulanceScriptOptions = ambulanceScriptOptions,
        categories = SETTINGS_CATEGORIES,
    })
end

local function close_admin_ui()
    if not isAdminUIOpen then return end
    debugPrint('Closing admin UI')
    isAdminUIOpen = false
    SetNuiFocus(false, false)
    SendNUIMessage({ type = 'aidoc:ui:closeAdmin' })
end

RegisterNetEvent('allgamers_aidoc:client:openAdminUI', function(settings, ambulanceScriptOptions)
    debugPrint('Received admin UI open event from server')
    open_admin_ui(settings, ambulanceScriptOptions)
end)

RegisterNUICallback('saveSettingsCategory', function(data, cb)
    debugPrint('NUI callback: saveSettingsCategory for ' .. tostring(data.categoryName))
    local success, err = lib.callback.await('allgamers_aidoc:server:saveCategory', false, data.categoryName, data.categoryData)
    if success then
        debugPrint('Category saved successfully: ' .. tostring(data.categoryName))
        SendNUIMessage({ type = 'aidoc:ui:saveSuccess', category = data.categoryName })
    else
        debugPrint('Category save failed: ' .. tostring(err))
        SendNUIMessage({ type = 'aidoc:ui:saveError', category = data.categoryName, error = err })
    end
    cb({ success = success, error = err })
end)

RegisterNUICallback('saveAllSettings', function(data, cb)
    debugPrint('NUI callback: saveAllSettings')
    local success, err = lib.callback.await('allgamers_aidoc:server:saveAllSettings', false, data.settings)
    if success then
        debugPrint('All settings saved successfully')
        SendNUIMessage({ type = 'aidoc:ui:saveSuccess', category = 'all' })
    else
        debugPrint('Save all failed: ' .. tostring(err))
        SendNUIMessage({ type = 'aidoc:ui:saveError', category = 'all', error = err })
    end
    cb({ success = success, error = err })
end)

RegisterNUICallback('resetSettingsCategory', function(data, cb)
    debugPrint('NUI callback: resetSettingsCategory for ' .. tostring(data.categoryName))
    local success, err = lib.callback.await('allgamers_aidoc:server:resetCategory', false, data.categoryName)
    cb({ success = success, error = err })
end)

RegisterNUICallback('restoreDefaultSettings', function(_, cb)
    debugPrint('NUI callback: restoreDefaultSettings')
    local success, err = lib.callback.await('allgamers_aidoc:server:restoreDefaults', false)
    cb({ success = success, error = err })
end)

RegisterNUICallback('requestCurrentSettings', function(_, cb)
    debugPrint('NUI callback: requestCurrentSettings')
    local settings = lib.callback.await('allgamers_aidoc:server:getSettings', false)
    cb({ settings = settings })
end)

RegisterNUICallback('adminDispatchEMS', function(data, cb)
    debugPrint('NUI callback: adminDispatchEMS')
    local ok, err = lib.callback.await('allgamers_aidoc:server:adminDispatchEMS', false, data.targetPlayerId, data.vehicleType)
    cb({ success = ok, error = err })
end)

RegisterNUICallback('closeUi', function(data, cb)
    debugPrint('NUI callback: closeUi, view=' .. tostring(data.view))
    if data.view == 'admin' then
        close_admin_ui()
    elseif data.view == 'player' then
        TriggerEvent('allgamers_aidoc:client:closePlayerUI')
    end
    cb({})
end)

RegisterNUICallback('getPlayerCoords', function(data, cb)
    debugPrint('NUI callback: getPlayerCoords, format=' .. tostring(data.format))
    local playerPed = PlayerPedId()
    local coords = GetEntityCoords(playerPed)
    local heading = GetEntityHeading(playerPed)

    if data.format == 'vector3' then
        cb({ coords = string.format("%.2f, %.2f, %.2f", coords.x, coords.y, coords.z) })
    elseif data.format == 'vector4' then
        cb({ coords = string.format("%.2f, %.2f, %.2f, %.2f", coords.x, coords.y, coords.z, heading) })
    else
        cb({ coords = string.format("%.2f, %.2f, %.2f", coords.x, coords.y, coords.z) })
    end
end)

