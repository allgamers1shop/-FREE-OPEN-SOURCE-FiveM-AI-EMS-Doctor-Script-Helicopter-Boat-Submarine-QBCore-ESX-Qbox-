lib.locale(Config.Language)

local isPlayerUIOpen = false
local playerUICallback = nil

local emsActive = false
local activeEMSType = nil

local heliVehicle, heliPilot, heliMedic, heliBlip = nil, nil, nil, nil
local carVehicle, carMedic, carBlip = nil, nil, nil
local boatVehicle, boatMedic, boatBlip = nil, nil, nil
local subVehicle, subMedic, subBlip = nil, nil, nil
local walkingMedic, walkingBlip = nil, nil

local boatHandoffActive = false
local subHandoffActive = false
local reviveHandled = true
local emsCallInProgress = false
local paymentPending = false
local emsSpawned = false
local subRescueStarted = false
local quickActionCooldown = false
local emsTimer = nil

local CPR_DICT = "mini@cpr@char_a@cpr_str"
local CPR_ANIM = "cpr_pumpchest"
local HOSPITAL_BED_DICT = "anim@gangops@morgue@table@"
local HOSPITAL_BED_ANIM = "body_search"
local HOSPITAL_GETUP_DICT = "switch@franklin@bed"
local HOSPITAL_GETUP_ANIM = "sleep_getup_rubeyes"
local CARRY_DICT = "anim@heists@box_carry@"
local CARRIED_DICT = "amb@code_human_in_car_idles@generic@ps@base"

-- Player EMS selection UI

function DebugPrintUI(message)
    if Config and Config.Debug then
        print("[allgamers_aidoc][debug][player_ui] " .. tostring(message))
    end
end

function GetEMSMenuOptions()
    local options = {}

    if not Config.WalkingNPCMode then
        if Config.AutoSelectEMSType then
            options[#options + 1] = {
                id = "auto",
                title = locale("auto_title"),
                description = locale("auto_description"),
                image = "auto.png"
            }
        end
        options[#options + 1] = {
            id = Config.VehicleArgs.Heli,
            title = locale("heli_title"),
            description = locale("heli_description"),
            image = "heli.png"
        }
        options[#options + 1] = {
            id = Config.VehicleArgs.Car,
            title = locale("car_title"),
            description = locale("car_description"),
            image = "car.png"
        }
        options[#options + 1] = {
            id = Config.VehicleArgs.Boat,
            title = locale("boat_title"),
            description = locale("boat_description"),
            image = "boat.png"
        }
        options[#options + 1] = {
            id = Config.VehicleArgs.Sub,
            title = locale("sub_title"),
            description = locale("sub_description"),
            image = "sub.png"
        }
    else
        options[#options + 1] = {
            id = "walking",
            title = locale("walking_title") or "Walking Doctor",
            description = locale("walking_description") or "A doctor will walk to your location",
            image = "walking.png"
        }
    end

    return options
end

function OpenPlayerEMSMenu(onSelect)
    if isPlayerUIOpen then
        DebugPrintUI("Player UI already open")
        return
    end

    local options = GetEMSMenuOptions()

    if Config.WalkingNPCMode and #options == 1 then
        DebugPrintUI("Walking mode only, calling directly")
        if onSelect then
            onSelect("walking")
        end
        return
    end

    DebugPrintUI("Opening player EMS selection UI with " .. #options .. " options")
    isPlayerUIOpen = true
    playerUICallback = onSelect
    SetNuiFocus(true, true)
    SendNUIMessage({
        type = "aidoc:ui:openPlayerMenu",
        options = options,
        callPayment = Config.CallPayment
    })
end

function ClosePlayerEMSMenu()
    if not isPlayerUIOpen then
        return
    end

    DebugPrintUI("Closing player EMS selection UI")
    isPlayerUIOpen = false
    playerUICallback = nil
    SetNuiFocus(false, false)
    SendNUIMessage({ type = "aidoc:ui:closePlayerMenu" })
end

RegisterNetEvent("allgamers_aidoc:client:closePlayerUI", function()
    ClosePlayerEMSMenu()
end)

RegisterNUICallback("submitPlayerVehicleChoice", function(data, cb)
    DebugPrintUI("Player chose EMS type: " .. tostring(data.vehicleType))
    local vehicleType = data.vehicleType
    local callback = playerUICallback
    ClosePlayerEMSMenu()
    if callback and vehicleType then
        callback(vehicleType)
    end
    cb({})
end)

RegisterNetEvent("allgamers_aidoc:client:syncSettings", function(settings)
    DebugPrintUI("Received settings sync from server")
    if settings then
        ApplySettingsToConfig(settings)
        DebugPrintUI("Client Config updated from server sync")
    end
end)

CreateThread(function()
    Wait(750)
    local settings = lib.callback.await("allgamers_aidoc:server:requestRuntimeSettings", false)
    if settings then
        ApplySettingsToConfig(settings)
        DebugPrintUI("Client Config updated from server runtime pull")
    end
end)

RegisterNUICallback("requestAmbulanceScriptOptions", function(data, cb)
    cb({ options = Config.AmbulanceScriptOptions })
end)

exports("OpenPlayerEMSMenu", OpenPlayerEMSMenu)
exports("ClosePlayerEMSMenu", ClosePlayerEMSMenu)

-- Shared helpers

function DebugPrint(message)
    if Config.Debug then
        print("[AllGamers AI Doctor] " .. tostring(message))
    end
end

function GetPedModelHash()
    return GetHashKey((Config.UseCustomPED and Config.CustomPED.model) or Config.DefaultPedModel)
end

function SetPedAttributes(ped, options)
    options = options or {}

    SetPedFleeAttributes(ped, 0, false)
    SetPedCombatAttributes(ped, 17, true)
    SetEntityInvincible(ped, true)
    SetPedCanRagdoll(ped, false)
    SetPedCanRagdollFromPlayerImpact(ped, false)
    SetPedConfigFlag(ped, 32, false)
    SetPedConfigFlag(ped, 33, false)
    SetPedConfigFlag(ped, 429, true)
    SetBlockingOfNonTemporaryEvents(ped, true)

    if options.is_driver then
        SetPedConfigFlag(ped, 104, true)
        SetPedConfigFlag(ped, 118, false)
        SetPedCombatAttributes(ped, 46, true)
    end

    if options.is_underwater then
        SetPedDiesInWater(ped, false)
        SetPedDiesInSinkingVehicle(ped, false)
        SetPedMaxTimeUnderwater(ped, 999999.0)
    end

    SetPedDiesWhenInjured(ped, false)
    SetPedAsNoLongerNeeded(ped)
    SetEntityMaxHealth(ped, 200)
    SetEntityHealth(ped, 200)

    if options.extra_max_health then
        SetPedMaxHealth(ped, 200)
    end
end

function CreateEntityBlip(entity, settings)
    local blip = AddBlipForEntity(entity)
    SetBlipSprite(blip, settings.sprite)
    SetBlipFlashes(blip, settings.flash)
    SetBlipColour(blip, settings.color)
    return blip
end

function RemoveEntityBlip(blip)
    if DoesBlipExist(blip) then
        RemoveBlip(blip)
    end
end

function DeleteIfExists(entity)
    if DoesEntityExist(entity) then
        DeleteEntity(entity)
    end
end

function ReleaseConfigModel(modelConfig)
    if modelConfig and modelConfig.model then
        SetModelAsNoLongerNeeded(GetHashKey(modelConfig.model))
    end
end

function ReleasePedModels()
    if Config.DefaultPedModel then
        SetModelAsNoLongerNeeded(GetHashKey(Config.DefaultPedModel))
    end
    if Config.UseCustomPED then
        ReleaseConfigModel(Config.CustomPED)
    end
end

function LockSpawnedNpcs(...)
    local netIds = {}

    for index = 1, select("#", ...) do
        local entity = select(index, ...)
        if entity and DoesEntityExist(entity) then
            local netId = NetworkGetNetworkIdFromEntity(entity)
            if netId and netId ~= 0 then
                netIds[#netIds + 1] = tostring(netId)
            end
        end
    end

    if #netIds > 0 then
        TriggerServerEvent("allgamers_aidoc:lockSpawnedNpcs", netIds)
    end
end

function MonitorEntity(entity, label)
    Citizen.CreateThread(function()
        while DoesEntityExist(entity) do
            Citizen.Wait(1000)
        end

        Citizen.Wait(200)
        if not emsActive and not emsCallInProgress and not paymentPending then
            return
        end

        print("^3[AllGamers AI Doctor]^7 EMS " .. label .. " was deleted by another script - something may be conflicting.")
    end)
end

function FindRoadPosition(coords, radius)
    for _ = 1, 10 do
        local angle = math.random() * 2 * math.pi
        local candidate = vector3(coords.x + math.cos(angle) * radius, coords.y + math.sin(angle) * radius, coords.z)
        local found, nodePosition = GetClosestVehicleNode(candidate.x, candidate.y, candidate.z, 1, 3.0, 0)
        if found then
            return true, nodePosition
        end
        Citizen.Wait(100)
    end
    return false, nil
end

function FindWaterPosition(coords, radius, underwater)
    local attempts = 0
    while attempts < 10 do
        local angle = math.random() * 2 * math.pi
        local candidate = vector3(coords.x + math.cos(angle) * radius, coords.y + math.sin(angle) * radius, coords.z)
        local hasWater, waterHeight = GetWaterHeight(candidate.x, candidate.y, candidate.z)

        if underwater then
            if hasWater and waterHeight > candidate.z then
                return true, vector3(candidate.x, candidate.y, coords.z - 5.0)
            end
        elseif hasWater then
            if TestVerticalProbeAgainstAllWater(candidate.x, candidate.y, candidate.z, 1) then
                return true, vector3(candidate.x, candidate.y, waterHeight + 1.0)
            end
        end

        attempts = attempts + 1
        Citizen.Wait(100)
    end
    return false, nil
end

function AutoDetectEMSType()
    local playerPed = PlayerPedId()
    local coords = GetEntityCoords(playerPed)

    if IsEntityInWater(playerPed) then
        local hasWater, waterHeight = GetWaterHeight(coords.x, coords.y, coords.z)
        if hasWater and coords.z < waterHeight - 3.0 then
            return Config.VehicleArgs.Sub
        end
        return Config.VehicleArgs.Boat
    end

    local zone = GetNameOfZone(coords.x, coords.y, coords.z)
    if zone == "MTCHIL" or zone == "MTGORDO" or zone == "MTJOSE" or zone == "TATAMO" then
        return Config.VehicleArgs.Heli
    end

    return Config.VehicleArgs.Car
end

function PositionPedNearPlayer(ped, coords, facePlayer)
    local forwardOffset = IsPlayerDead() and 0.5 or 1.0
    local position = GetOffsetFromEntityInWorldCoords(PlayerPedId(), 0.0, forwardOffset, 0.0)
    SetEntityCoords(ped, position.x, position.y, coords.z)
    SetEntityHeading(ped, GetEntityHeading(PlayerPedId()) - 180)

    if facePlayer then
        ClearPedTasksImmediately(ped)
        TaskTurnPedToFaceEntity(ped, PlayerPedId(), -1)
    end
end

function ResetEMSFlags()
    emsActive = false
    emsCallInProgress = false
    paymentPending = false
    emsSpawned = false
    reviveHandled = true
end

function ExtractPedFromVehicle(ped, vehicle)
    if IsPedInVehicle(ped, vehicle, false) then
        TaskLeaveVehicle(ped, vehicle, 0)
        Citizen.Wait(1000)
    elseif IsEntityAttached(ped) then
        DetachEntity(ped, true, true)
    end
end

function ClearActiveEMS(emsType)
    if emsType == "heli" or emsType == nil then
        DeleteIfExists(heliVehicle)
        DeleteIfExists(heliPilot)
        DeleteIfExists(heliMedic)
        RemoveEntityBlip(heliBlip)
        ReleaseConfigModel(Config.HeliModel)
        heliVehicle, heliPilot, heliMedic, heliBlip = nil, nil, nil, nil
    end

    if emsType == "car" or emsType == nil then
        DeleteIfExists(carVehicle)
        DeleteIfExists(carMedic)
        RemoveEntityBlip(carBlip)
        ReleaseConfigModel(Config.CarModel)
        carVehicle, carMedic, carBlip = nil, nil, nil
    end

    if emsType == "boat" or emsType == nil then
        DeleteIfExists(boatVehicle)
        DeleteIfExists(boatMedic)
        RemoveEntityBlip(boatBlip)
        ReleaseConfigModel(Config.BoatModel)
        boatVehicle, boatMedic, boatBlip = nil, nil, nil
        boatHandoffActive = false
    end

    if emsType == "sub" or emsType == nil then
        DeleteIfExists(subVehicle)
        DeleteIfExists(subMedic)
        RemoveEntityBlip(subBlip)
        subVehicle, subMedic, subBlip = nil, nil, nil
        subHandoffActive = false
    end

    if emsType == "walking" or emsType == nil then
        DeleteIfExists(walkingMedic)
        walkingMedic = nil
    end

    ReleasePedModels()

    if emsType == nil then
        activeEMSType = nil
        emsActive = false
        reviveHandled = true
        emsCallInProgress = false
        paymentPending = false
        emsSpawned = false
        subRescueStarted = false
        emsTimer = nil
    end
end

function IsInRestrictedZone()
    local playerCoords = GetEntityCoords(PlayerPedId())
    for _, zone in pairs(Config.RestrictedZones) do
        if #(playerCoords - zone.coords) <= zone.radius then
            return true
        end
    end
    return false
end

function IsWalkingMode()
    return Config.WalkingNPCMode == true
end

function IsValidVehicleType(vehicleType)
    if Config.WalkingNPCMode then
        return vehicleType == "walking"
    end
    return vehicleType == Config.VehicleArgs.Heli
end

function IsSupportedVehicleArg(vehicleType)
    return vehicleType == Config.VehicleArgs.Heli
        or vehicleType == Config.VehicleArgs.Car
        or vehicleType == Config.VehicleArgs.Boat
        or vehicleType == Config.VehicleArgs.Sub
end

function FormatVehicleTypeMessage(localeKey)
    return string.format(locale(localeKey), Config.VehicleArgs.Heli, Config.VehicleArgs.Car, Config.VehicleArgs.Boat, Config.VehicleArgs.Sub)
end

function ApplyCustomPedAppearance(ped)
    if not Config.UseCustomPED then
        return true
    end

    if not DoesEntityExist(ped) then
        return false
    end

    local face = Config.CustomPED.face
    if not face then
        print("^1[AllGamers AI Doctor]^7 Custom PED config error - missing face settings in Config.CustomPED.")
        return false
    end
    SetPedHeadBlendData(ped, face.shapeFirst, face.shapeSecond, 0, face.skinFirst, face.skinSecond, 0, face.shapeMix, face.skinMix, 0.0, false)

    local hair = Config.CustomPED.hair
    if not hair then
        print("^1[AllGamers AI Doctor]^7 Custom PED config error - missing hair settings in Config.CustomPED.")
        return false
    end
    SetPedComponentVariation(ped, 2, hair.hair, 0, 2)

    local makeup = Config.CustomPED.makeup
    if not makeup then
        print("^1[AllGamers AI Doctor]^7 Custom PED config error - missing makeup settings in Config.CustomPED.")
        return false
    end
    SetPedHeadOverlay(ped, 4, makeup.makeupType, makeup.makeupOpacity)
    SetPedHeadOverlayColor(ped, 4, 1, makeup.makeupColor, makeup.makeupSecondaryColor)
    SetPedHeadOverlay(ped, 5, makeup.blushOpacity, makeup.blushOpacity)
    SetPedHeadOverlayColor(ped, 5, 2, makeup.blushColor, makeup.blushColor)
    SetPedHeadOverlay(ped, 8, makeup.lipstickOpacity, makeup.lipstickOpacity)
    SetPedHeadOverlayColor(ped, 8, 1, makeup.lipstickColor, makeup.lipstickColor)

    local clothes = Config.CustomPED.clothes
    if not clothes then
        print("^1[AllGamers AI Doctor]^7 Custom PED config error - missing clothes settings in Config.CustomPED.")
        return false
    end
    for _, item in ipairs(clothes) do
        SetPedComponentVariation(ped, item.componentId, item.drawableId, item.textureId, 0)
    end

    return true
end

function LoadAnimDict(dict, waitMs)
    RequestAnimDict(dict)
    while not HasAnimDictLoaded(dict) do
        Citizen.Wait(waitMs)
    end
end

function PlayCprAnimation(ped, duration, lockY)
    LoadAnimDict(CPR_DICT, 100)
    TaskPlayAnim(ped, CPR_DICT, CPR_ANIM, 8.0, 8.0, duration, 1, 0.0, false, lockY, false)
end

function ChargeForRevive()
    TriggerServerEvent("allgamers:payForRevive", Config.RevivePayment)
    Notify(string.format(locale("treatment_done"), Config.RevivePayment), "success")
end

function WalkPedToCoords(ped, target, arriveDistance, waitMs, speed)
    local arrived = false
    while not arrived do
        Citizen.Wait(waitMs)
        if #(GetEntityCoords(ped) - target) > arriveDistance then
            TaskFollowNavMeshToCoord(ped, target.x, target.y, target.z, speed, -1, 1.0, 0, 0)
        else
            arrived = true
        end
    end
end

function WalkPedBackToVehicle(ped, vehicle, waitMs)
    local arrived = false
    while not arrived do
        Citizen.Wait(waitMs)
        local vehicleCoords = GetEntityCoords(vehicle)
        if #(GetEntityCoords(ped) - vehicleCoords) > 2.0 then
            TaskFollowNavMeshToCoord(ped, vehicleCoords.x, vehicleCoords.y, vehicleCoords.z, 1.5, -1, 1.0, 0, 0)
        else
            arrived = true
        end
    end
end

function GetUpdatedPatientCoords(currentCoords)
    if IsPedInAnyVehicle(PlayerPedId(), false) then
        ExtractPlayerFromVehicle()
        return GetEntityCoords(PlayerPedId())
    end
    return currentCoords
end

function DespawnWhenFarFrom(getVehicle, getPed, origin)
    Citizen.CreateThread(function()
        while true do
            if not DoesEntityExist(getVehicle()) then
                break
            end
            if not DoesEntityExist(getPed()) then
                break
            end
            Citizen.Wait(1000)
            if #(origin - GetEntityCoords(getVehicle())) > 50.0 then
                DeleteEntity(getVehicle())
                DeleteEntity(getPed())
                break
            end
        end
    end)
end

-- Hospital revive scene

function FindClosestHospitalBed(coords)
    local closestHospital, closestBed = nil, nil
    local closestDistance = math.huge

    for _, hospital in ipairs(Config.Hospitals) do
        for _, bed in ipairs(hospital.beds) do
            local distance = #(coords - vector3(bed.x, bed.y, bed.z))
            if distance < closestDistance then
                closestDistance = distance
                closestHospital = hospital
                closestBed = bed
            end
        end
    end

    if closestHospital and closestBed then
        return { hospital = closestHospital, bed = closestBed }
    end
    return nil
end

function GetMedicForActiveType()
    if activeEMSType == "heli" then
        if DoesEntityExist(heliMedic) then
            return heliMedic
        end
    elseif activeEMSType == "car" then
        if DoesEntityExist(carMedic) then
            return carMedic
        end
    elseif activeEMSType == "boat" then
        if DoesEntityExist(boatMedic) then
            return boatMedic
        end
    elseif activeEMSType == "sub" then
        if DoesEntityExist(subMedic) then
            return subMedic
        end
    end
    return nil
end

function StartHospitalScene(emsType)
    DebugPrint("Starting hospital scene: " .. tostring(emsType))

    local bedInfo = FindClosestHospitalBed(GetEntityCoords(PlayerPedId()))
    if not bedInfo then
        print("^3[AllGamers AI Doctor]^7 No hospital beds found in config - reviving on spot instead.")
        RevivePlayer()
        return
    end

    local bed = bedInfo.bed

    LoadAnimDict("amb@medic@standing@kneel@base", 10)

    local medic = GetMedicForActiveType()
    if medic then
        TaskPlayAnim(medic, "amb@medic@standing@kneel@base", "base", 8.0, -8.0, 2000, 1, 0, false, false, false)
    end

    local sent = lib.progressBar({
        duration = Config.HospitalSendDelayMs,
        label = "Sending to hospital...",
        useWhileDead = true,
        canCancel = false,
        disable = {
            car = true,
            move = true,
            combat = true,
            mouse = false,
            sprint = true
        }
    })

    if medic then
        ClearPedTasks(medic)
    end

    if not sent then
        RevivePlayer()
        return
    end

    DoScreenFadeOut(1000)
    while not IsScreenFadedOut() do
        Citizen.Wait(10)
    end

    local playerPed = PlayerPedId()
    SetEntityCoords(playerPed, bed.x, bed.y, bed.z + 0.5, false, false, false, false)
    SetEntityHeading(playerPed, bed.w)
    RevivePlayer()
    FreezeEntityPosition(playerPed, true)
    SetPlayerInvincible(PlayerId(), true)

    lib.requestAnimDict(HOSPITAL_BED_DICT)
    TaskPlayAnim(playerPed, HOSPITAL_BED_DICT, HOSPITAL_BED_ANIM, 8.0, 1.0, -1, 1, 0, false, false, false)
    DoScreenFadeIn(1000)

    local doctorModel = GetHashKey(Config.DefaultPedModel)
    RequestModel(doctorModel)
    local waited = 0
    while not HasModelLoaded(doctorModel) and waited < 1000 do
        Citizen.Wait(10)
        waited = waited + 10
    end

    if not HasModelLoaded(doctorModel) then
        SetModelAsNoLongerNeeded(doctorModel)
    else
        local playerHeading = GetEntityHeading(PlayerPedId())
        local spawnPosition = GetOffsetFromEntityInWorldCoords(PlayerPedId(), 1.0, 0.0, 0.0)
        local doctor = CreatePed(26, doctorModel, spawnPosition.x, spawnPosition.y, spawnPosition.z - 1.5, playerHeading + 90, true, false)

        if DoesEntityExist(doctor) then
            SetPedFleeAttributes(doctor, 0, 0)
            SetPedCombatAttributes(doctor, 46, true)
            SetBlockingOfNonTemporaryEvents(doctor, true)
            SetEntityInvincible(doctor, true)
            LockSpawnedNpcs(doctor)
            Citizen.Wait(2000)

            RequestAnimDict("mini@repair")
            waited = 0
            while not HasAnimDictLoaded("mini@repair") and waited < 1000 do
                Citizen.Wait(10)
                waited = waited + 10
            end

            if HasAnimDictLoaded("mini@repair") then
                TaskPlayAnim(doctor, "mini@repair", "fixing_a_ped", 8.0, 8.0, -1, 1, 0, false, false, false)
            end

            lib.progressBar({
                duration = Config.ReviveTime,
                label = "Receiving medical treatment...",
                useWhileDead = false,
                canCancel = false,
                disable = {
                    car = true,
                    move = true,
                    combat = true,
                    mouse = false,
                    sprint = true
                }
            })

            ClearPedTasks(doctor)
            ClearPedTasks(doctor)
            Citizen.Wait(2000)
            DeleteIfExists(doctor)
            SetModelAsNoLongerNeeded(doctorModel)
            RemoveAnimDict("mini@repair")
            RemoveAnimDict(HOSPITAL_BED_DICT)
            RemoveAnimDict(HOSPITAL_GETUP_DICT)
        end
    end

    LoadAnimDict(HOSPITAL_GETUP_DICT, 10)
    FreezeEntityPosition(playerPed, false)
    SetEntityHeading(playerPed, bed.w + 90)
    TaskPlayAnim(playerPed, HOSPITAL_GETUP_DICT, HOSPITAL_GETUP_ANIM, 100.0, 1.0, -1, 8, -1, false, false, false)
    Citizen.Wait(4000)
    ClearPedTasks(playerPed)
    SetPlayerInvincible(PlayerId(), false)

    ChargeForRevive()
    ResetEMSFlags()
    emsTimer = nil
    ClearActiveEMS()
end

function FormatCountdownTime(totalSeconds)
    local minutes = math.floor(totalSeconds / 60)
    local seconds = totalSeconds % 60
    return string.format("%d:%02d", minutes, seconds)
end

function ShowCountdown(totalTime)
    SendNUIMessage({
        type = "showCountdown",
        totalTime = totalTime,
        formattedTime = FormatCountdownTime(totalTime)
    })
end

function RequestModelSafe(model)
    if lib.requestModel(model, 10000) then
        return true
    end
    print("^1[AllGamers AI Doctor]^7 Failed to load model: " .. tostring(model) .. " - check the model name in config.")
    return false
end

function PerformReviveSequence(medic, targetCoords, vehicle)
    local playerCoords = GetEntityCoords(PlayerPedId())
    PositionPedNearPlayer(medic, playerCoords, false)

    if not Config.HospitalRevive then
        LoadAnimDict(CPR_DICT, 50)
        TaskPlayAnim(medic, CPR_DICT, CPR_ANIM, 1.0, 1.0, -1, 1, 0.0, false, false, false)
    end

    if reviveHandled then
        return
    end

    reviveHandled = true
    Notify(locale("medical_aid"), "primary")

    Citizen.CreateThread(function()
        treatmentInProgress = true
        ClearPedTasks(medic)
        Citizen.Wait(200)

        if Config.HospitalRevive then
            StartHospitalScene("car")
        else
            if ShowReviveProgressBar() then
                RevivePlayer()
            end
            ChargeForRevive()
        end

        if vehicle then
            if DoesEntityExist(vehicle) then
                TaskEnterVehicle(medic, vehicle, -1, -1, 1.0, 1, 0)
                Citizen.Wait(2000)
                if DoesEntityExist(vehicle) then
                    TaskVehicleDriveWander(medic, vehicle, 20.0, 786603)
                    SetPedKeepTask(medic, true)
                end
            end
        else
            TaskFollowNavMeshToCoord(medic, targetCoords.x + 10.0, targetCoords.y + 10.0, targetCoords.z, 1.0, -1, 1.0, 0, 0)
            Citizen.Wait(3000)
            DeleteIfExists(medic)
        end

        ClearActiveEMS("heli")
    end)
end

function ExtractPlayerFromVehicle()
    local playerPed = PlayerPedId()
    local playerCoords = GetEntityCoords(playerPed)

    if not IsPedInAnyVehicle(playerPed, false) then
        return false
    end

    local vehicle = GetVehiclePedIsIn(playerPed, false)
    Notify(locale("extracting_from_vehicle"), "info")

    local exitOffset = GetOffsetFromEntityInWorldCoords(vehicle, 2.0, 0.0, 0.0)
    local exitPosition = vector3(exitOffset.x, exitOffset.y, playerCoords.z)
    SetEntityCoords(playerPed, exitPosition.x, exitPosition.y, exitPosition.z, false, false, false, true)
    Citizen.Wait(1000)
    Notify(locale("extracted_from_vehicle"), "success")
    return true
end

-- Normal EMS: helicopter

function SpawnHeliEMS(coords)
    activeEMSType = "heli"
    reviveHandled = false

    local heliModel = GetHashKey(Config.HeliModel.model)
    local pilotModel = GetHashKey("s_m_y_pilot_01")
    local medicModel = GetPedModelHash()

    if not RequestModelSafe(heliModel) then
        Notify(locale("error_failed_load_heli"), "error")
        ClearActiveEMS("heli")
        return
    end
    if not RequestModelSafe(pilotModel) then
        Notify(locale("error_failed_load_pilot"), "error")
        ClearActiveEMS("heli")
        return
    end
    if not RequestModelSafe(medicModel) then
        Notify(locale("error_failed_load_ped"), "error")
        ClearActiveEMS("heli")
        return
    end

    local spawnPosition = vector3(coords.x, coords.y, coords.z + Config.HeliSpawnHeight)
    heliVehicle = CreateVehicle(heliModel, spawnPosition.x, spawnPosition.y, spawnPosition.z, 0, true, false)
    if not DoesEntityExist(heliVehicle) then
        print("^1[AllGamers AI Doctor]^7 Failed to spawn helicopter - try a different Config.HeliModel.model.")
        return
    end

    if Config.HeliModel.livery ~= nil then
        SetVehicleLivery(heliVehicle, Config.HeliModel.livery)
    end
    SetEntityAsMissionEntity(heliVehicle, true, true)
    MonitorEntity(heliVehicle, "Helicopter")
    SetHeliBladesFullSpeed(heliVehicle)

    heliPilot = CreatePedInsideVehicle(heliVehicle, 26, pilotModel, -1, true, false)
    if not DoesEntityExist(heliPilot) then
        print("^1[AllGamers AI Doctor]^7 Failed to spawn helicopter pilot.")
        return
    end

    heliMedic = CreatePedInsideVehicle(heliVehicle, 26, medicModel, 1, true, false)
    if not DoesEntityExist(heliMedic) then
        print("^1[AllGamers AI Doctor]^7 Failed to spawn EMS ped in helicopter.")
        return
    end

    ApplyCustomPedAppearance(heliMedic)
    SetPedAttributes(heliPilot)
    SetPedAttributes(heliMedic)
    LockSpawnedNpcs(heliPilot, heliMedic)
    heliBlip = CreateEntityBlip(heliMedic, Config.BlipSettings.heli)
    DebugPrint("Helicopter EMS spawned and en route")

    TaskHeliMission(heliPilot, heliVehicle, 0, 0, coords.x, coords.y, coords.z + Config.HeliDescendDistance, 4, 20.0, 10.0, coords.z + Config.HeliDescendDistance, 0, 0, 0, 0)

    Citizen.CreateThread(function()
        while emsActive do
            Citizen.Wait(500)
            local heliCoords = GetEntityCoords(heliVehicle)
            local distance = #(coords - heliCoords)

            if distance < 35.0 and heliCoords.z - coords.z < 30.0 then
                TaskVehicleHeliProtect(heliPilot, heliVehicle, coords.x, coords.y, coords.z + Config.HeliDescendDistance, 20.0, 0.0, 0.0, 0.0, 0.0)
                DebugPrint("EMS rappelling from helicopter")
                TaskRappelFromHeli(heliMedic, 1)
                Citizen.Wait(12000)
                break
            end

            if IsEntityDead(heliMedic) or IsEntityDead(heliPilot) then
                print("^1[AllGamers AI Doctor]^7 Helicopter EMS or pilot died - something may have killed them.")
                Notify(locale("ems_dead"), "error")
                ClearActiveEMS("heli")
                break
            end
        end
    end)

    Citizen.CreateThread(function()
        while emsActive do
            Citizen.Wait(1000)

            if IsEntityDead(heliMedic) then
                print("^1[AllGamers AI Doctor]^7 Helicopter EMS died during approach.")
                Notify(locale("ems_dead"), "error")
                ClearActiveEMS("heli")
                break
            end

            local playerCoords = GetEntityCoords(PlayerPedId())
            local distance = #(playerCoords - GetEntityCoords(heliMedic))

            if distance > 5.0 then
                TaskFollowNavMeshToCoord(heliMedic, playerCoords.x, playerCoords.y, playerCoords.z, 1.5, -1, 1.0, 0, 0)
            else
                DebugPrint("Helicopter EMS reached player - starting treatment")
                playerCoords = GetUpdatedPatientCoords(playerCoords)

                emsActive = false
                ClearPedTasksImmediately(heliMedic)
                PositionPedNearPlayer(heliMedic, playerCoords, false)

                if not Config.HospitalRevive then
                    LoadAnimDict(CPR_DICT, 100)
                    TaskPlayAnim(heliMedic, CPR_DICT, CPR_ANIM, 8.0, 8.0, Config.ReviveTime, 1, 0, false, false, false)
                end

                if Config.HospitalRevive then
                    StartHospitalScene("heli")
                else
                    if ShowReviveProgressBar() then
                        RevivePlayer()
                        DebugPrint("Revive completed successfully")
                    end
                    ChargeForRevive()
                    ResetEMSFlags()
                end

                ClearPedTasks(heliMedic)

                if DoesEntityExist(heliVehicle) and DoesEntityExist(heliPilot) then
                    ReturnMedicToHelicopter()
                else
                    TaskFollowNavMeshToCoord(heliMedic, coords.x + 15, coords.y + 15, coords.z, 1.0, -1, 1.0, 0, 0)
                    Citizen.Wait(10000)
                    DeleteEntity(heliMedic)
                end

                ClearActiveEMS("heli")
                return
            end
        end
    end)

    emsActive = true
end

function ReturnMedicToHelicopter()
    local medicCoords = GetEntityCoords(heliMedic)
    ClearPedTasksImmediately(heliMedic)
    FreezeEntityPosition(heliMedic, true)

    TaskHeliMission(heliPilot, heliVehicle, 0, 0, medicCoords.x, medicCoords.y, medicCoords.z + 3.0, 4, 10.0, 3.0, medicCoords.z + 3.0, 0, 0, 0, 0)

    local waited = 0
    while waited < 15000 do
        Citizen.Wait(500)
        local heliCoords = GetEntityCoords(heliVehicle)
        if #(medicCoords - heliCoords) < 4.0 and math.abs(heliCoords.z - medicCoords.z) < 4.0 then
            break
        end
        waited = waited + 500
    end

    TaskVehicleHeliProtect(heliPilot, heliVehicle, medicCoords.x, medicCoords.y, medicCoords.z + 3.0, 5.0, 0.0, 0.0, 0.0, 0.0)
    Citizen.Wait(1000)
    SetPedIntoVehicle(heliMedic, heliVehicle, 1)
    FreezeEntityPosition(heliMedic, false)
    Citizen.Wait(1000)

    TaskVehicleDriveWander(heliPilot, heliVehicle, 100.0, 786603)
    SetPedKeepTask(heliPilot, true)
    SetPedKeepTask(heliMedic, true)
    Citizen.Wait(15000)

    DeleteIfExists(heliVehicle)
end

-- Normal EMS: car

function SpawnCarEMS(coords)
    activeEMSType = "car"
    reviveHandled = false

    local carModel = GetHashKey(Config.CarModel.model)
    local medicModel = GetPedModelHash()

    if not RequestModelSafe(carModel) then
        Notify(locale("error_failed_load_vehicle"), "error")
        ClearActiveEMS("car")
        return
    end
    if not RequestModelSafe(medicModel) then
        Notify(locale("error_failed_load_ped"), "error")
        ClearActiveEMS("car")
        return
    end

    local found, spawnPosition = FindRoadPosition(coords, Config.CarSpawnRange)
    if not found then
        print("^1[AllGamers AI Doctor]^7 Could not find a suitable road for EMS car - player may be in a bad spot.")
        Notify(locale("no_road_found"), "error")
        ClearActiveEMS("car")
        return
    end

    carVehicle = CreateVehicle(carModel, spawnPosition.x, spawnPosition.y, spawnPosition.z, 0, true, false)
    if Config.CarModel.livery ~= nil then
        SetVehicleLivery(carVehicle, Config.CarModel.livery)
    end
    SetEntityAsMissionEntity(carVehicle, true, true)
    MonitorEntity(carVehicle, "Car")
    DebugPrint("Car EMS spawned and en route")

    carMedic = CreatePedInsideVehicle(carVehicle, 26, medicModel, -1, true, false)
    ApplyCustomPedAppearance(carMedic)
    SetPedAttributes(carMedic, { is_driver = true })
    LockSpawnedNpcs(carMedic)
    carBlip = CreateEntityBlip(carMedic, Config.BlipSettings.car)

    local drivingStyle = 524863
    TaskVehicleDriveToCoord(carMedic, carVehicle, coords.x, coords.y, coords.z, 20.0, 1, 0, drivingStyle, 5.0, 1.0)
    emsActive = true

    Citizen.CreateThread(function()
        while emsActive do
            Citizen.Wait(500)

            local playerPed = PlayerPedId()
            local playerCoords = GetEntityCoords(playerPed)
            local distance = #(playerCoords - GetEntityCoords(carVehicle))
            local isIndoors = GetInteriorFromEntity(playerPed) ~= 0
            local exitDistance = (isIndoors and Config.CarExitDistanceMLO) or Config.CarExitDistanceOutdoor

            if distance <= exitDistance then
                TaskLeaveVehicle(carMedic, carVehicle, 0)
                Citizen.Wait(2000)
                ClearPedTasksImmediately(carMedic)

                WalkPedToCoords(carMedic, playerCoords, 3.0, 250, 1.0)
                DebugPrint("Car EMS reached player - starting treatment")
                playerCoords = GetUpdatedPatientCoords(playerCoords)

                PositionPedNearPlayer(carMedic, playerCoords, true)

                if not Config.HospitalRevive then
                    PlayCprAnimation(carMedic, Config.ReviveTime, true)
                end

                if ShowReviveProgressBar() then
                    RevivePlayer()
                    DebugPrint("Revive completed successfully")
                end
                ChargeForRevive()
                ResetEMSFlags()

                WalkPedBackToVehicle(carMedic, carVehicle, 500)

                TaskEnterVehicle(carMedic, carVehicle, -1, -1, 1.0, 1, 0)
                Citizen.Wait(3000)
                TaskVehicleDriveWander(carMedic, carVehicle, 20.0, drivingStyle)
                SetPedKeepTask(carMedic, true)
                Citizen.Wait(10000)

                DespawnWhenFarFrom(function() return carVehicle end, function() return carMedic end, playerCoords)
                ClearActiveEMS("car")
                return
            end

            if IsEntityDead(carMedic) then
                print("^1[AllGamers AI Doctor]^7 Car EMS died during approach.")
                Notify(locale("ems_dead"), "error")
                ClearActiveEMS("car")
                break
            end
        end
    end)
end

-- Normal EMS: boat

function SpawnBoatEMS(coords)
    activeEMSType = "boat"
    reviveHandled = false

    local boatModel = GetHashKey(Config.BoatModel.model)
    local medicModel = GetPedModelHash()

    if not RequestModelSafe(boatModel) then
        Notify(locale("error_failed_load_boat"), "error")
        ClearActiveEMS("boat")
        return
    end
    if not RequestModelSafe(medicModel) then
        Notify(locale("error_failed_load_ped"), "error")
        ClearActiveEMS("boat")
        return
    end

    local found, waterPosition = FindWaterPosition(coords, Config.BoatSpawnRange, false)
    if not found then
        Notify(locale("no_water_found"), "error")
        ClearActiveEMS("boat")
        return
    end

    boatVehicle = CreateVehicle(boatModel, waterPosition, 0, true, false)
    if Config.BoatModel.livery ~= nil then
        SetVehicleLivery(boatVehicle, Config.BoatModel.livery)
    end
    SetEntityAsMissionEntity(boatVehicle, true, true)
    MonitorEntity(boatVehicle, "Boat")

    boatMedic = CreatePedInsideVehicle(boatVehicle, 26, medicModel, -1, true, false)
    ApplyCustomPedAppearance(boatMedic)
    SetPedAttributes(boatMedic, { extra_max_health = true, is_underwater = true })
    LockSpawnedNpcs(boatMedic)
    boatBlip = CreateEntityBlip(boatMedic, Config.BlipSettings.boat)

    local drivingStyle = 786603
    DebugPrint("Boat EMS spawned and en route")
    TaskVehicleDriveToCoord(boatMedic, boatVehicle, coords.x, coords.y, coords.z, 15.0, 1, 0, drivingStyle, 15.0, 1.0)
    emsActive = true

    Citizen.CreateThread(function()
        local boatStopped = false

        while emsActive do
            Citizen.Wait(500)

            if boatHandoffActive then
                break
            end

            if IsEntityDead(boatMedic) then
                print("^1[AllGamers AI Doctor]^7 Boat EMS died during approach.")
                Notify(locale("ems_dead"), "error")
                ClearActiveEMS("boat")
                break
            end

            local playerCoords = GetEntityCoords(PlayerPedId())
            local distance = #(playerCoords - GetEntityCoords(boatVehicle))

            if distance <= 50.0 and not boatStopped then
                TaskVehicleDriveToCoord(boatMedic, boatVehicle, playerCoords.x, playerCoords.y, playerCoords.z, 8.0, 1, 0, drivingStyle, 12.0, 1.0)
            end

            if distance <= 25.0 and not boatStopped then
                boatStopped = true
                SetVehicleEngineOn(boatVehicle, false, true, true)
                TaskVehicleTempAction(boatMedic, boatVehicle, 1, -1)
                SetBoatAnchor(boatVehicle, true)
                Citizen.Wait(4000)
            end

            if boatStopped then
                TaskLeaveVehicle(boatMedic, boatVehicle, 0)
                Citizen.Wait(2500)
                ClearPedTasksImmediately(boatMedic)
                TaskFollowNavMeshToCoord(boatMedic, playerCoords.x, playerCoords.y, playerCoords.z, 1.0, -1, 1.0, 0, 0)

                WalkPedToCoords(boatMedic, playerCoords, 5.0, 250, 1.0)
                DebugPrint("Boat EMS reached player - starting treatment")

                local playerPed = PlayerPedId()
                playerCoords = GetUpdatedPatientCoords(playerCoords)
                ClearPedTasksImmediately(boatMedic)

                local playerInWater = IsEntityInWater(playerPed)
                if playerInWater then
                    FreezeEntityPosition(playerPed, true)
                end

                PositionPedNearPlayer(boatMedic, playerCoords, false)
                FreezeEntityPosition(boatMedic, true)
                PlayCprAnimation(boatMedic, Config.ReviveTime, true)
                Notify(locale("medical_aid"), "primary")

                if playerInWater then
                    Citizen.Wait(Config.ReviveTime)
                    RevivePlayer()
                else
                    if ShowReviveProgressBar() then
                        RevivePlayer()
                        DebugPrint("Revive completed successfully")
                    end
                end
                ChargeForRevive()

                if playerInWater then
                    FreezeEntityPosition(playerPed, false)
                end
                FreezeEntityPosition(boatMedic, false)
                ResetEMSFlags()

                WalkPedBackToVehicle(boatMedic, boatVehicle, 200)

                SetBoatAnchor(boatVehicle, false)
                TaskEnterVehicle(boatMedic, boatVehicle, -1, -1, 1.0, 1, 0)
                Citizen.Wait(3000)
                SetVehicleEngineOn(boatVehicle, true, true, false)
                TaskVehicleDriveWander(boatMedic, boatVehicle, 20.0, drivingStyle)
                SetPedKeepTask(boatMedic, true)
                Citizen.Wait(10000)

                DespawnWhenFarFrom(function() return boatVehicle end, function() return boatMedic end, playerCoords)
                ClearActiveEMS("boat")
                break
            end
        end
    end)
end

-- Normal EMS: submarine (underwater rescue -> surface -> beach)

function FindWaterSurface(coords)
    local radius = 10.0
    local maxRadius = 100.0
    local radiusStep = 10.0

    while radius <= maxRadius do
        for degrees = 0, 360, 30 do
            local angle = math.rad(degrees)
            local x = coords.x + math.cos(angle) * radius
            local y = coords.y + math.sin(angle) * radius
            local hasWater, waterHeight = GetWaterHeight(x, y, coords.z)
            if hasWater then
                return vector3(x, y, waterHeight + 5.0)
            end
        end
        radius = radius + radiusStep
    end

    return nil
end

function FindClosestBeach(coords)
    local closestBeach = nil
    local closestDistance = 999999.0

    for _, beach in ipairs(Config.SubmarineBeachLocations) do
        local distance = #(coords - beach)
        if distance < closestDistance then
            closestDistance = distance
            closestBeach = beach
        end
    end

    if closestBeach then
        return closestBeach
    end

    print("^1[AllGamers AI Doctor]^7 No beach locations in config for submarine rescue.")
    return nil
end

function SpawnSubmarineUnit(coords, isHospitalRun)
    activeEMSType = "sub"
    reviveHandled = false

    local subModel = GetHashKey(Config.SubModel.model)
    local medicModel = GetPedModelHash()

    if not RequestModelSafe(subModel) then
        Notify(locale("error_failed_load_sub"), "error")
        ClearActiveEMS("sub")
        return false
    end
    if not RequestModelSafe(medicModel) then
        Notify(locale("error_failed_load_ped"), "error")
        ClearActiveEMS("sub")
        return false
    end

    local found, spawnPosition = FindWaterPosition(coords, Config.SubSpawnRange, true)
    if not found then
        if not isHospitalRun then
            print("^1[AllGamers AI Doctor]^7 Could not find underwater spawn for submarine - check player location.")
        end
        Notify(locale("no_underwater_spawn"), "error")
        ClearActiveEMS("sub")
        return false
    end

    subVehicle = CreateVehicle(subModel, spawnPosition.x, spawnPosition.y, spawnPosition.z, 0, true, false)
    if Config.SubModel.livery ~= nil then
        SetVehicleLivery(subVehicle, Config.SubModel.livery)
    end
    SetEntityAsMissionEntity(subVehicle, true, true)
    if not isHospitalRun then
        MonitorEntity(subVehicle, "Submersible")
    end
    SetVehicleEngineOn(subVehicle, true, true, false)
    SetBoatAnchor(subVehicle, false)

    subMedic = CreatePedInsideVehicle(subVehicle, 26, medicModel, -1, true, false)
    ApplyCustomPedAppearance(subMedic)
    SetPedAttributes(subMedic, { is_driver = true, is_underwater = true })
    LockSpawnedNpcs(subMedic)
    subBlip = CreateEntityBlip(subMedic, Config.BlipSettings.sub)

    if not isHospitalRun then
        DebugPrint("Submarine EMS spawned and en route")
    end

    TaskVehicleDriveToCoord(subMedic, subVehicle, coords.x, coords.y, coords.z, 20.0, 1, 0, 786603, 5.0, 1.0)
    emsActive = true
    return true
end

function MonitorSubmarineApproach(isHospitalRun, onBeachReached)
    Citizen.CreateThread(function()
        while emsActive do
            Citizen.Wait(1000)

            if subHandoffActive then
                break
            end

            if IsEntityDead(subMedic) then
                if not isHospitalRun then
                    print("^1[AllGamers AI Doctor]^7 Submarine EMS died during approach.")
                end
                Notify(locale("ems_dead"), "error")
                ClearActiveEMS("sub")
                break
            end

            local playerCoords = GetEntityCoords(PlayerPedId())
            local distance = #(playerCoords - GetEntityCoords(subVehicle))

            if distance <= 30.0 and not subRescueStarted then
                if not isHospitalRun then
                    DebugPrint("Submarine reached player - initiating underwater rescue")
                end
                subRescueStarted = true
                emsSpawned = true

                local surfacePosition = FindWaterSurface(playerCoords)
                if not surfacePosition then
                    if not isHospitalRun then
                        print("^1[AllGamers AI Doctor]^7 Could not find water surface for submarine rescue - player may be too deep.")
                    end
                    Notify(locale("no_water_surface"), "error")
                    ClearActiveEMS("sub")
                    return
                end

                Citizen.CreateThread(function()
                    RunSubmarineRescue(surfacePosition, onBeachReached)
                end)
            end
        end
    end)
end

function AbortSubmarineRescue(localeKey)
    ExtractPedFromVehicle(PlayerPedId(), subVehicle)
    Notify(locale(localeKey), "error")
    ClearActiveEMS("sub")
end

function RunSubmarineRescue(surfacePosition, onBeachReached)
    local playerPed = PlayerPedId()

    if IsPedInAnyVehicle(playerPed, false) then
        ExtractPlayerFromVehicle()
    end
    ClearPedTasksImmediately(playerPed)
    SetPedIntoVehicle(playerPed, subVehicle, -1)
    Citizen.Wait(500)

    if not IsPedInVehicle(playerPed, subVehicle, false) then
        AttachEntityToEntity(playerPed, subVehicle, 0, 0.0, -3.0, 1.0, 0.0, 0.0, 0.0, false, false, false, false, 2, true)
    end

    Notify(locale("sub_transport_to_surface"), "success")
    TaskVehicleDriveToCoord(subMedic, subVehicle, surfacePosition.x, surfacePosition.y, surfacePosition.z, 25.0, 1, 0, 786603, 5.0, 1.0)

    local reachedSurface = false
    local surfaceElapsed = 0

    while not reachedSurface do
        if not emsActive then
            break
        end
        Citizen.Wait(500)
        surfaceElapsed = surfaceElapsed + 0.5

        local distanceToSurface = #(GetEntityCoords(subVehicle) - surfacePosition)

        if distanceToSurface <= 15.0 then
            local subCoords = GetEntityCoords(subVehicle)
            local hasWater, waterHeight = GetWaterHeight(subCoords.x, subCoords.y, subCoords.z)
            if hasWater and subCoords.z < waterHeight + 2.0 then
                SetEntityCoords(subVehicle, subCoords.x, subCoords.y, waterHeight + 3.0, false, false, false, true)
                Citizen.Wait(1000)
            end
            Citizen.Wait(1000)

            local beach = FindClosestBeach(GetEntityCoords(subVehicle))
            if not beach then
                Notify(locale("no_beach_area"), "error")
                ClearActiveEMS("sub")
                return
            end

            Notify(locale("heading_to_beach"), "success")
            TaskVehicleDriveToCoord(subMedic, subVehicle, beach.x, beach.y, beach.z, 25.0, 1, 0, 786468, 10.0, 1.0)

            local arrivedAtBeach = false
            local beachElapsed = 0

            while not arrivedAtBeach do
                if not emsActive then
                    break
                end
                Citizen.Wait(500)
                beachElapsed = beachElapsed + 0.5

                if IsEntityDead(subMedic) then
                    AbortSubmarineRescue("ems_dead")
                    return
                end

                if #(GetEntityCoords(subVehicle) - beach) <= 10.0 then
                    arrivedAtBeach = true
                    reachedSurface = true

                    TaskVehicleTempAction(subMedic, subVehicle, 27, 10000)
                    Citizen.Wait(2000)
                    Notify(locale("reached_beach"), "success")

                    ExtractPedFromVehicle(playerPed, subVehicle)
                    local dropCoords = vector3(beach.x, beach.y, beach.z + 1.0)
                    SetEntityCoords(playerPed, dropCoords.x, dropCoords.y, dropCoords.z, false, false, false, true)

                    onBeachReached(playerPed, beach, dropCoords)
                    return
                elseif beachElapsed > 180 then
                    AbortSubmarineRescue("beach_transport_timeout")
                    return
                end
            end
            return
        elseif surfaceElapsed > 60 then
            AbortSubmarineRescue("surface_transport_timeout")
            return
        end

        if subHandoffActive then
            return
        end

        if IsEntityDead(subMedic) then
            AbortSubmarineRescue("ems_dead")
            return
        end
    end
end

function TreatPatientOnBeach(playerPed, beach, dropCoords)
    Citizen.Wait(500)
    TaskLeaveVehicle(subMedic, subVehicle, 0)
    Citizen.Wait(2000)
    ClearPedTasksImmediately(subMedic)

    WalkPedToCoords(subMedic, dropCoords, 3.0, 250, 1.0)
    GetUpdatedPatientCoords(dropCoords)

    PositionPedNearPlayer(subMedic, GetEntityCoords(playerPed), true)

    if not Config.HospitalRevive then
        PlayCprAnimation(subMedic, Config.ReviveTime, true)
    end

    treatmentInProgress = true

    if Config.HospitalRevive then
        StartHospitalScene("sub")
    else
        if ShowReviveProgressBar() then
            RevivePlayer()
        end
        ChargeForRevive()
    end

    ResetEMSFlags()

    Citizen.CreateThread(function()
        Citizen.Wait(30000)
        DeleteIfExists(subMedic)
        DeleteIfExists(subVehicle)
        ReleaseConfigModel(Config.SubModel)
        ReleasePedModels()
        subVehicle, subMedic, subBlip = nil, nil, nil
    end)

    emsActive = false

    local stuckCount = 0
    local lastDistance = 9999.0

    Citizen.CreateThread(function()
        while true do
            Citizen.Wait(250)
            local medicCoords = GetEntityCoords(subMedic)
            local subCoords = GetEntityCoords(subVehicle)
            local distance = #(subCoords - medicCoords)

            if distance > 2.0 then
                TaskFollowNavMeshToCoord(subMedic, subCoords.x, subCoords.y, subCoords.z, 1.5, -1, 1.0, 0, 0)
                if distance >= lastDistance - 0.5 then
                    stuckCount = stuckCount + 1
                else
                    stuckCount = 0
                end
                lastDistance = distance
            else
                TaskEnterVehicle(subMedic, subVehicle, -1, -1, 1.0, 1, 0)
                Citizen.Wait(3000)
                TaskVehicleDriveWander(subMedic, subVehicle, 20.0, 786603)
                SetPedKeepTask(subMedic, true)
                ClearActiveEMS("sub")
                return
            end
        end
    end)
end

function SpawnSubEMS(coords)
    if SpawnSubmarineUnit(coords, false) then
        MonitorSubmarineApproach(false, TreatPatientOnBeach)
    end
end

-- Hospital revive transport (patient is seated and taken to hospital)

function GetClosestHospital(coords)
    local closestHospital = nil
    local closestDistance = math.huge

    for _, hospital in ipairs(Config.Hospitals) do
        local distance = #(coords - hospital.center)
        if distance < closestDistance then
            closestDistance = distance
            closestHospital = hospital
        end
    end

    return closestHospital
end

function CreateHospitalZone(hospital, onEnter)
    return lib.zones.sphere({
        coords = hospital.center,
        radius = hospital.radius,
        debug = false,
        onEnter = onEnter,
        inside = function() end,
        onExit = function() end
    })
end

function DriveToPatient(driver, vehicle, targetCoords, patient)
    local interior = (patient and GetInteriorFromEntity(patient)) or 0
    local isIndoors = interior ~= 0
    local exitDistance = (isIndoors and Config.CarExitDistanceMLO) or Config.CarExitDistanceOutdoor

    TaskVehicleDriveToCoord(driver, vehicle, targetCoords.x, targetCoords.y, targetCoords.z, 20.0, 1, 0, 524863, 5.0, 1.0)

    while true do
        Citizen.Wait(500)
        if #(targetCoords - GetEntityCoords(vehicle)) <= exitDistance then
            break
        end
    end
end

function WalkToPatient(medic, vehicle, patient)
    TaskLeaveVehicle(medic, vehicle, 0)
    Citizen.Wait(2000)
    ClearPedTasksImmediately(medic)

    local patientCoords = GetEntityCoords(patient)
    TaskFollowNavMeshToCoord(medic, patientCoords.x, patientCoords.y, patientCoords.z, 1.0, -1, 1.0, 0, 0)

    while true do
        Citizen.Wait(250)
        if #(patientCoords - GetEntityCoords(medic)) <= 3.0 then
            break
        end
    end

    ClearPedTasks(medic)
    TaskTurnPedToFaceEntity(medic, patient, -1)
end

function CarryPatientToVehicle(medic, patient, vehicle)
    RequestAnimDict(CARRY_DICT)
    RequestAnimDict(CARRIED_DICT)
    while not (HasAnimDictLoaded(CARRY_DICT) and HasAnimDictLoaded(CARRIED_DICT)) do
        Citizen.Wait(10)
    end

    TaskPlayAnim(medic, CARRY_DICT, "idle", 8.0, -8.0, 30000, 49, 0, false, false, false)
    TaskPlayAnim(patient, CARRIED_DICT, "base", 8.0, -8.0, 30000, 33, 0, false, false, false)
    AttachEntityToEntity(patient, medic, GetPedBoneIndex(medic, 28252), 0.35, 0.15, -0.15, -42.5, -22.5, 22.5, false, false, false, true, 1, true)

    local vehicleCoords = GetEntityCoords(vehicle)
    TaskFollowNavMeshToCoord(medic, vehicleCoords.x, vehicleCoords.y, vehicleCoords.z, 1.0, -1, 1.0, 0, 0)

    local ticks = 0
    while ticks < 120 do
        Citizen.Wait(500)
        if #(vehicleCoords - GetEntityCoords(medic)) <= 2.0 then
            break
        end
        ticks = ticks + 1
    end

    DetachEntity(patient, true, true)
    StopAnimTask(medic, CARRY_DICT, "idle", 1.0)
    StopAnimTask(patient, CARRIED_DICT, "base", 1.0)

    ClearPedTasksImmediately(medic)
    ClearPedTasks(medic)
    ClearPedSecondaryTask(medic)
    ClearPedTasksImmediately(patient)
    ClearPedTasks(patient)
    ClearPedSecondaryTask(patient)

    RemoveAnimDict(CARRY_DICT)
    RemoveAnimDict(CARRIED_DICT)
end

function SeatPatientInVehicle(patient, vehicle)
    if not DoesEntityExist(vehicle) then
        print("^1[AllGamers AI Doctor]^7 Ambulance was deleted - could not seat patient.")
        return false
    end

    StopAnimTask(patient, CARRY_DICT, "idle", 1.0)
    StopAnimTask(patient, CARRIED_DICT, "base", 1.0)
    ClearPedTasksImmediately(patient)
    ClearPedSecondaryTask(patient)
    ClearPedTasks(patient)
    RemoveAnimDict(CARRY_DICT)
    RemoveAnimDict(CARRIED_DICT)
    Citizen.Wait(100)

    if not DoesEntityExist(vehicle) then
        print("^1[AllGamers AI Doctor]^7 Ambulance was deleted during transport - could not seat patient.")
        return false
    end

    SetPedIntoVehicle(patient, vehicle, 1)
    Citizen.Wait(1000)

    return IsPedInVehicle(patient, vehicle, false) and true or false
end

function DriveToHospital(driver, vehicle, destination)
    TaskEnterVehicle(driver, vehicle, -1, -1, 1.0, 1, 0)
    Citizen.Wait(2000)
    TaskVehicleDriveToCoord(driver, vehicle, destination.x, destination.y, destination.z, 100.0, 1, 0, 1074528293, 5.0, 1.0)
end

function ArriveAtHospital(emsType)
    StartHospitalScene(emsType)
end

function DispatchFollowUpHeli(pickupCoords)
    Citizen.CreateThread(function()
        Citizen.Wait(3000)
        local previousSpawned = emsSpawned
        emsSpawned = false
        SpawnHospitalHeliEMS(pickupCoords)
        emsSpawned = previousSpawned
    end)
end

function SpawnHospitalHeliEMS(coords)
    activeEMSType = "heli"

    local hospital = GetClosestHospital(coords)
    if not hospital then
        Notify(locale("no_hospital_found"), "error")
        ClearActiveEMS("heli")
        return
    end

    reviveHandled = false

    local heliModel = GetHashKey(Config.HeliModel.model)
    local pilotModel = GetHashKey("s_m_y_pilot_01")

    if not RequestModelSafe(heliModel) then
        Notify(locale("error_failed_load_heli"), "error")
        ClearActiveEMS("heli")
        return
    end
    if not RequestModelSafe(pilotModel) then
        Notify(locale("error_failed_load_pilot"), "error")
        ClearActiveEMS("heli")
        return
    end

    local spawnPosition = vector3(coords.x, coords.y, coords.z + Config.HeliSpawnHeight)
    heliVehicle = CreateVehicle(heliModel, spawnPosition.x, spawnPosition.y, spawnPosition.z, 0, true, false)
    if not DoesEntityExist(heliVehicle) then
        print("^1[AllGamers AI Doctor]^7 Failed to spawn hospital helicopter.")
        return
    end

    if Config.HeliModel.livery ~= nil then
        SetVehicleLivery(heliVehicle, Config.HeliModel.livery)
    end
    SetEntityAsMissionEntity(heliVehicle, true, true)
    SetHeliBladesFullSpeed(heliVehicle)

    heliPilot = CreatePedInsideVehicle(heliVehicle, 26, pilotModel, -1, true, false)
    if not DoesEntityExist(heliPilot) then
        print("^1[AllGamers AI Doctor]^7 Failed to spawn hospital helicopter pilot.")
        return
    end

    SetPedAttributes(heliPilot)
    LockSpawnedNpcs(heliPilot)
    heliBlip = CreateEntityBlip(heliPilot, Config.BlipSettings.heli)

    local playerPed = PlayerPedId()
    local center = hospital.center

    TaskHeliMission(heliPilot, heliVehicle, 0, 0, coords.x, coords.y, coords.z + 5.0, 4, 25.0, 5.0, coords.z + 5.0, 0, 0, 0, 0)

    Citizen.CreateThread(function()
        local landed = false

        while emsActive do
            Citizen.Wait(500)
            local heliCoords = GetEntityCoords(heliVehicle)
            local distance = #(coords - heliCoords)

            if not landed and distance < 15.0 and heliCoords.z - coords.z < 25.0 then
                TaskHeliMission(heliPilot, heliVehicle, 0, 0, coords.x, coords.y, coords.z + 2.0, 4, 15.0, 2.0, coords.z + 2.0, 0, 0, 0, 0)
                landed = true
                Citizen.Wait(3000)
                SetHeliBladesFullSpeed(heliVehicle, false)
                Citizen.Wait(2000)

                if not IsPedInVehicle(playerPed, heliVehicle, false) then
                    local boardPosition = GetOffsetFromEntityInWorldCoords(heliVehicle, 3.0, 0.0, 0.0)
                    if #(GetEntityCoords(playerPed) - boardPosition) > 2.0 then
                        SetEntityCoords(playerPed, boardPosition.x, boardPosition.y, coords.z, false, false, false, true)
                    end

                    TaskEnterVehicle(playerPed, heliVehicle, -1, 1, 1.0, 1, 0)
                    Citizen.Wait(2000)

                    if IsPedInVehicle(playerPed, heliVehicle, false) then
                        Notify(locale("seated_in_heli"), "success")
                        setVehicleFuel(heliVehicle, 100.0)
                        SetHeliBladesFullSpeed(heliVehicle, true)
                        Citizen.Wait(2000)
                        TaskHeliMission(heliPilot, heliVehicle, 0, 0, coords.x, coords.y, coords.z + 200.0, 4, 40.0, 10.0, coords.z + 200.0, 0, 0, 0, 0)
                        Citizen.Wait(3000)
                        TaskHeliMission(heliPilot, heliVehicle, 0, 0, center.x, center.y, center.z + 200.0, 6, 60.0, 20.0, center.z + 200.0, 0, 0, 0, 0)
                    else
                        Citizen.Wait(1000)
                        SetPedIntoVehicle(playerPed, heliVehicle, 1)
                        Citizen.Wait(1000)

                        if IsPedInVehicle(playerPed, heliVehicle, false) then
                            Notify(locale("seated_in_heli"), "success")
                            setVehicleFuel(heliVehicle, 100.0)
                            SetHeliBladesFullSpeed(heliVehicle, true)
                            Citizen.Wait(2000)
                            TaskHeliMission(heliPilot, heliVehicle, 0, 0, center.x, center.y, center.z + 50.0, 6, 40.0, 10.0, center.z + 50.0, 0, 0, 0, 0)
                            break
                        else
                            ClearActiveEMS("heli")
                            return
                        end
                    end
                end
            end

            if IsEntityDead(heliPilot) then
                print("^1[AllGamers AI Doctor]^7 Hospital helicopter pilot died.")
                Notify(locale("pilot_dead"), "error")
                ClearActiveEMS("heli")
                break
            end
        end
    end)

    Citizen.CreateThread(function()
        while emsActive do
            Citizen.Wait(1000)

            if DoesEntityExist(heliVehicle) and #(GetEntityCoords(heliVehicle) - center) <= 100.0 then
                TaskHeliMission(heliPilot, heliVehicle, 0, 0, center.x, center.y, center.z + 15.0, 4, 25.0, 8.0, center.z + 15.0, 0, 0, 0, 0)
                Citizen.Wait(4000)
                TaskVehicleHeliProtect(heliPilot, heliVehicle, center.x, center.y, center.z + 15.0, 0.0, 0.0, 0.0, 0.0, 0.0)
                ArriveAtHospital("heli")
                break
            end
        end
    end)

    emsActive = true
end

function SpawnHospitalCarEMS(coords)
    activeEMSType = "car"

    local hospital = GetClosestHospital(coords)
    if not hospital then
        ClearActiveEMS("car")
        return
    end

    reviveHandled = false

    local carModel = GetHashKey(Config.CarModel.model)
    local medicModel = GetPedModelHash()

    if not RequestModelSafe(carModel) then
        Notify(locale("error_failed_load_vehicle"), "error")
        ClearActiveEMS("car")
        return
    end
    if not RequestModelSafe(medicModel) then
        Notify(locale("error_failed_load_ped"), "error")
        ClearActiveEMS("car")
        return
    end

    local found, spawnPosition = FindRoadPosition(coords, Config.CarSpawnRange)
    if not found then
        print("^1[AllGamers AI Doctor]^7 Could not find a suitable road for EMS car - player may be in a bad spot.")
        Notify(locale("no_road_found"), "error")
        ClearActiveEMS("car")
        return
    end

    carVehicle = CreateVehicle(carModel, spawnPosition.x, spawnPosition.y, spawnPosition.z, 0, true, false)
    if Config.CarModel.livery ~= nil then
        SetVehicleLivery(carVehicle, Config.CarModel.livery)
    end
    SetEntityAsMissionEntity(carVehicle, true, true)
    SetNetworkIdCanMigrate(NetworkGetNetworkIdFromEntity(carVehicle), false)
    SetEntityCleanupByEngine(carVehicle, false)
    SetVehicleHasBeenOwnedByPlayer(carVehicle, true)
    MonitorEntity(carVehicle, "Car")

    carMedic = CreatePedInsideVehicle(carVehicle, 26, medicModel, -1, true, false)
    ApplyCustomPedAppearance(carMedic)
    SetPedAttributes(carMedic, { is_driver = true })
    LockSpawnedNpcs(carMedic)
    carBlip = CreateEntityBlip(carMedic, Config.BlipSettings.car)

    local playerPed = PlayerPedId()

    DriveToPatient(carMedic, carVehicle, coords, playerPed)
    WalkToPatient(carMedic, carVehicle, playerPed)
    CarryPatientToVehicle(carMedic, playerPed, carVehicle)

    if not SeatPatientInVehicle(playerPed, carVehicle) then
        ClearActiveEMS("car")
        return
    end

    setVehicleFuel(carVehicle, 100.0)
    DriveToHospital(carMedic, carVehicle, hospital.center)

    local arrived = false
    CreateHospitalZone(hospital, function()
        if arrived then
            return
        end
        arrived = true

        ClearPedTasks(carMedic)
        ClearPedTasks(playerPed)
        DetachEntity(playerPed, true, true)

        if DoesEntityExist(carVehicle) then
            SetVehicleEngineOn(carVehicle, false, true, true)
            TaskVehicleTempAction(carMedic, carVehicle, 1, -1)
        end

        ArriveAtHospital("car")

        if zoneId then
            zoneId:remove()
        end
    end)

    emsActive = true
end

function StartHospitalBoatBeachRun(beach, playerPed)
    Notify(locale("seated_in_boat"), "success")
    setVehicleFuel(boatVehicle, 100.0)
    TaskVehicleDriveToCoord(boatMedic, boatVehicle, beach.x, beach.y, beach.z, 15.0, 1, 0, 5, 5.0, 1.0)

    Citizen.CreateThread(function()
        while emsActive do
            Citizen.Wait(1000)

            if DoesEntityExist(boatVehicle) and #(GetEntityCoords(boatVehicle) - beach) <= 15.0 then
                SetVehicleEngineOn(boatVehicle, false, true, true)
                TaskVehicleTempAction(boatMedic, boatVehicle, 1, -1)
                TaskLeaveVehicle(playerPed, boatVehicle, 0)
                Citizen.Wait(3000)
                SetEntityCoords(playerPed, beach.x, beach.y, beach.z, false, false, false, true)
                Notify(locale("heli_rescue_coming"), "success")

                DispatchFollowUpHeli(beach)
                boatHandoffActive = true

                Citizen.CreateThread(function()
                    Citizen.Wait(10000)
                    DeleteIfExists(boatVehicle)
                    DeleteIfExists(boatMedic)
                    RemoveEntityBlip(boatBlip)
                    boatVehicle, boatMedic, boatBlip = nil, nil, nil
                    boatHandoffActive = false
                end)
                break
            end
        end
    end)
end

function SpawnHospitalBoatEMS(coords)
    activeEMSType = "boat"

    local beach = FindClosestBeach(coords)
    if not beach then
        Notify(locale("no_beach_found"), "error")
        ClearActiveEMS("boat")
        return
    end

    reviveHandled = false

    local boatModel = GetHashKey(Config.BoatModel.model)
    if not RequestModelSafe(boatModel) then
        Notify(locale("error_failed_load_boat"), "error")
        ClearActiveEMS("boat")
        return
    end

    local found, waterPosition = FindWaterPosition(coords, Config.BoatSpawnRange, false)
    if not found then
        Notify(locale("no_water_found"), "error")
        ClearActiveEMS("boat")
        return
    end

    boatVehicle = CreateVehicle(boatModel, waterPosition, 0, true, false)
    if DoesEntityExist(boatVehicle) and Config.BoatModel.livery ~= nil then
        SetVehicleLivery(boatVehicle, Config.BoatModel.livery)
    end
    if not DoesEntityExist(boatVehicle) then
        print("^1[AllGamers AI Doctor]^7 Failed to spawn hospital EMS boat.")
        return
    end
    SetEntityAsMissionEntity(boatVehicle, true, true)

    local driverModel = GetHashKey("s_m_m_paramedic_01")
    if not RequestModelSafe(driverModel) then
        Notify(locale("error_failed_load_ped"), "error")
        ClearActiveEMS("boat")
        return
    end

    boatMedic = CreatePedInsideVehicle(boatVehicle, 26, driverModel, -1, true, false)
    if not DoesEntityExist(boatMedic) then
        print("^1[AllGamers AI Doctor]^7 Failed to spawn hospital boat driver.")
        return
    end

    SetPedAttributes(boatMedic)
    LockSpawnedNpcs(boatMedic)
    boatBlip = CreateEntityBlip(boatMedic, Config.BlipSettings.boat)

    local playerPed = PlayerPedId()
    TaskVehicleDriveToCoord(boatMedic, boatVehicle, coords.x, coords.y, coords.z, 20.0, 1, 0, 786603, 1.0, 1.0)

    Citizen.CreateThread(function()
        local seated = false

        while true do
            if not emsActive or seated then
                break
            end
            Citizen.Wait(500)

            local distance = #(coords - GetEntityCoords(boatVehicle))
            if distance < 20.0 then
                SetVehicleEngineOn(boatVehicle, false, true, true)
                TaskVehicleTempAction(boatMedic, boatVehicle, 1, -1)

                if not IsPedInVehicle(playerPed, boatVehicle, false) then
                    local boardPosition = GetOffsetFromEntityInWorldCoords(boatVehicle, 2.0, 0.0, 0.0)
                    if #(GetEntityCoords(playerPed) - boardPosition) > 3.0 then
                        SetEntityCoords(playerPed, boardPosition.x, boardPosition.y, coords.z, false, false, false, true)
                    end

                    TaskEnterVehicle(playerPed, boatVehicle, -1, 0, 1.0, 1, 0)
                    Citizen.Wait(2000)

                    if IsPedInVehicle(playerPed, boatVehicle, false) then
                        StartHospitalBoatBeachRun(beach, playerPed)
                        seated = true
                    else
                        Citizen.Wait(1000)
                        SetPedIntoVehicle(playerPed, boatVehicle, 0)
                        Citizen.Wait(1000)

                        if IsPedInVehicle(playerPed, boatVehicle, false) then
                            StartHospitalBoatBeachRun(beach, playerPed)
                            seated = true
                        else
                            ClearActiveEMS("boat")
                            return
                        end
                    end
                end
            end

            if IsEntityDead(boatMedic) then
                Notify(locale("driver_dead"), "error")
                ClearActiveEMS("boat")
                break
            end
        end
    end)

    emsActive = true
end

function HandOffSubPatientToHeli(playerPed, beach, dropCoords)
    Notify(locale("heli_rescue_coming"), "success")
    DispatchFollowUpHeli(beach)
    subHandoffActive = true

    Citizen.CreateThread(function()
        Citizen.Wait(10000)
        DeleteIfExists(subVehicle)
        DeleteIfExists(subMedic)
        RemoveEntityBlip(subBlip)
        subVehicle, subMedic, subBlip = nil, nil, nil
        subHandoffActive = false
    end)
end

function SpawnHospitalSubEMS(coords)
    if SpawnSubmarineUnit(coords, true) then
        MonitorSubmarineApproach(true, HandOffSubPatientToHeli)
    end
end

-- Walking EMS

function SpawnWalkingEMS(coords)
    activeEMSType = "walking"
    reviveHandled = false

    local medicModel = GetPedModelHash()
    if not RequestModelSafe(medicModel) then
        Notify(locale("error_failed_load_ped"), "error")
        ClearActiveEMS("walking")
        return
    end

    local found, spawnPosition = FindRoadPosition(coords, Config.WalkingNPCSpawnRadius)
    if not found then
        Notify(locale("no_road_found"), "error")
        ClearActiveEMS("walking")
        return
    end

    walkingMedic = CreatePed(26, medicModel, spawnPosition.x, spawnPosition.y, spawnPosition.z - 1.0, 0.0, true, false)
    SetEntityAsMissionEntity(walkingMedic, true, true)
    ApplyCustomPedAppearance(walkingMedic)
    SetPedAttributes(walkingMedic, { is_driver = true })
    LockSpawnedNpcs(walkingMedic)
    walkingBlip = CreateEntityBlip(walkingMedic, Config.BlipSettings.walking)
    emsActive = true

    TaskFollowNavMeshToCoord(walkingMedic, coords.x, coords.y, coords.z, 1.0, -1, 1.0, 0, 0)

    Citizen.CreateThread(function()
        while emsActive and DoesEntityExist(walkingMedic) do
            Citizen.Wait(250)

            if IsEntityDead(walkingMedic) then
                Notify(locale("ems_dead"), "error")
                ClearActiveEMS("walking")
                return
            end

            local playerCoords = GetEntityCoords(PlayerPedId())
            local distance = #(playerCoords - GetEntityCoords(walkingMedic))

            if distance <= 3.0 then
                if not reviveHandled then
                    reviveHandled = true
                    Notify(locale("medical_aid"), "primary")
                end

                playerCoords = GetUpdatedPatientCoords(playerCoords)
                ClearPedTasksImmediately(walkingMedic)
                PositionPedNearPlayer(walkingMedic, playerCoords, false)
                PlayCprAnimation(walkingMedic, Config.ReviveTime, true)

                if ShowReviveProgressBar() then
                    RevivePlayer()
                end
                ChargeForRevive()
                ResetEMSFlags()

                TaskFollowNavMeshToCoord(walkingMedic, spawnPosition.x + 10.0, spawnPosition.y + 10.0, spawnPosition.z, 1.0, -1, 1.0, 0, 0)
                Citizen.Wait(3000)

                RemoveEntityBlip(walkingBlip)
                walkingBlip = nil
                DeleteIfExists(walkingMedic)
                walkingMedic = nil
                ClearActiveEMS("walking")
                return
            end

            TaskFollowNavMeshToCoord(walkingMedic, playerCoords.x, playerCoords.y, playerCoords.z, 1.0, -1, 1.0, 0, 0)
        end
    end)
end

-- Dispatch / payment flow

function DispatchAfterCountdown(vehicleType)
    ShowCountdown(Config.EMSArrivalTime)

    emsTimer = lib.timer(Config.EMSArrivalTime * 1000, function()
        local playerCoords = GetEntityCoords(PlayerPedId())
        local emsType = vehicleType or (Config.WalkingNPCMode and "walking" or Config.VehicleArgs.Car)

        if emsType == "walking" then
            SpawnWalkingEMS(playerCoords)
        elseif emsType == Config.VehicleArgs.Heli then
            if Config.HospitalRevive then
                SpawnHospitalHeliEMS(playerCoords)
            else
                SpawnHeliEMS(playerCoords)
            end
        elseif emsType == Config.VehicleArgs.Boat then
            if Config.HospitalRevive then
                SpawnHospitalBoatEMS(playerCoords)
            else
                SpawnBoatEMS(playerCoords)
            end
        elseif emsType == Config.VehicleArgs.Car then
            if Config.HospitalRevive then
                SpawnHospitalCarEMS(playerCoords)
            else
                SpawnCarEMS(playerCoords)
            end
        elseif emsType == Config.VehicleArgs.Sub then
            if Config.HospitalRevive then
                SpawnHospitalSubEMS(playerCoords)
            else
                SpawnSubEMS(playerCoords)
            end
        end

        emsSpawned = true
        emsTimer = nil
    end, true)
end

function RequestEMSWithPayment(vehicleType)
    if emsCallInProgress or paymentPending then
        Notify(locale("ems_already_on_way"), "error")
        return false
    end

    paymentPending = true

    lib.callback("allgamers_aidoc:server:checkDocOnline", false, function(doctorCount, canAfford, confirmedType)
        if doctorCount <= Config.DisableAIEMSAboveDoctorCount and canAfford then
            lib.callback("allgamers_aidoc:server:processPayment", false, function(paid)
                if paid then
                    Notify(string.format(locale("ems_on_way"), Config.EMSArrivalTime), "success")
                    emsCallInProgress = true
                    paymentPending = false
                    DispatchAfterCountdown(confirmedType)
                else
                    paymentPending = false
                    Notify(locale("payment_failed"), "error")
                end
            end, Config.CallPayment, confirmedType)
        else
            paymentPending = false
            if doctorCount > Config.DisableAIEMSAboveDoctorCount then
                Notify(locale("too_many_ems"), "error")
            elseif not canAfford then
                Notify(locale("cannot_afford"), "error")
            else
                Notify(locale("waiting_for_paramedic"), "primary")
            end
        end
    end, Config.CallPayment, vehicleType)

    return true
end

function TryCallEMS(vehicleType)
    local emsType = vehicleType or (Config.WalkingNPCMode and "walking" or Config.VehicleArgs.Car)

    if emsCallInProgress then
        Notify(locale("ems_already_on_way"), "error")
        return false
    end

    if IsInRestrictedZone() then
        Notify(locale("restricted_zone"), "error")
        return false
    end

    if not IsPlayerDead() and not Config.AlivePlayerCanCall then
        Notify(locale("only_when_dead"), "error")
        return false
    end

    if not IsValidVehicleType(emsType) then
        Notify(FormatVehicleTypeMessage("invalid_vehicle_type"), "error")
        return false
    end

    RequestEMSWithPayment(emsType)
    return true
end

RegisterCommand(Config.CallCommand, function(source, args, rawCommand)
    if emsCallInProgress then
        Notify(locale("ems_already_on_way"), "error")
        return
    end

    if IsInRestrictedZone() then
        Notify(locale("restricted_zone"), "error")
        return
    end

    local vehicleType
    if Config.WalkingNPCMode then
        vehicleType = "walking"
    else
        if #args < 1 then
            if Config.AutoSelectEMSType then
                vehicleType = AutoDetectEMSType()
            else
                Notify(FormatVehicleTypeMessage("specify_vehicle_type"), "error")
                return
            end
        else
            vehicleType = args[1]
        end

        if not IsSupportedVehicleArg(vehicleType) then
            Notify(FormatVehicleTypeMessage("invalid_vehicle_type"), "error")
            return
        end
    end

    if (IsPlayerDead() or Config.AlivePlayerCanCall) and reviveHandled then
        RequestEMSWithPayment(vehicleType)
    else
        Notify(locale("only_when_dead"), "error")
    end
end)

function SendEMSForPlayer(targetPlayerId, vehicleType)
    if emsCallInProgress then
        Notify(locale("ems_already_on_way"), "error")
        return false
    end

    if not IsValidVehicleType(vehicleType) then
        Notify(FormatVehicleTypeMessage("invalid_vehicle_type"), "error")
        return false
    end

    lib.callback("allgamers_aidoc:server:checkDocOnlineForDoctor", false, function(allowed, _, reason)
        if allowed then
            lib.callback("allgamers_aidoc:server:processPayment", false, function(paid)
                if paid then
                    TriggerServerEvent("allgamers_aidoc:server:triggerEMSForPlayer", targetPlayerId, vehicleType)
                    Notify(string.format(locale("ems_called_for_player"), targetPlayerId), "success")
                else
                    Notify(locale("payment_failed"), "error")
                end
            end, Config.CallPayment, vehicleType, targetPlayerId)
        elseif reason == "not_ambulance" then
            Notify(locale("not_ambulance"), "error")
        elseif reason == "player_not_found" then
            Notify(locale("player_not_found"), "error")
        else
            Notify(locale("cannot_call_ems"), "error")
        end
    end, targetPlayerId, Config.CallPayment, vehicleType)

    return true
end

RegisterCommand(Config.SendEMSCommand, function(source, args, rawCommand)
    if Config.WalkingNPCMode then
        if #args < 1 then
            Notify(locale("sendems_usage"), "error")
            return
        end
    elseif #args < 2 then
        Notify(locale("sendems_usage"), "error")
        return
    end

    local targetPlayerId = tonumber(args[1])
    local vehicleType = Config.WalkingNPCMode and "walking" or args[2]

    if not targetPlayerId then
        Notify(locale("invalid_player_id"), "error")
        return
    end

    SendEMSForPlayer(targetPlayerId, vehicleType)
end)

RegisterNetEvent("allgamers_aidoc:client:startEMSProcess")
AddEventHandler("allgamers_aidoc:client:startEMSProcess", function(vehicleType, isForced)
    emsCallInProgress = true
    paymentPending = false
    DispatchAfterCountdown(vehicleType)
end)

RegisterCommand(Config.CancelCommand, function()
    if not emsCallInProgress then
        Notify(locale("no_active_call"), "error")
        return
    end

    if emsSpawned then
        Notify(locale("cannot_cancel_spawned"), "error")
        return
    end

    if emsTimer then
        emsTimer:forceEnd(false)
        emsTimer = nil
    end

    SendNUIMessage({ type = "hideCountdown" })
    ClearActiveEMS()
    Notify(locale("ems_cancelled"), "success")
end)

RegisterNetEvent("allgamers_ai_doctor:client:ResetEMSCall", function()
    emsCallInProgress = false
    paymentPending = false
end)

-- EMS selection menus / keybinds / exports

function CreateEMSSelectHandler(vehicleType)
    return function()
        if emsCallInProgress then
            Notify(locale("ems_already_on_way"), "error")
            return
        end

        if IsInRestrictedZone() then
            Notify(locale("restricted_zone"), "error")
            return
        end

        if (IsPlayerDead() or Config.AlivePlayerCanCall) and reviveHandled then
            RequestEMSWithPayment(vehicleType)
        else
            Notify(locale("only_when_dead"), "error")
        end
    end
end

function OpenEMSSelection()
    if Config.WalkingNPCMode then
        RequestEMSWithPayment("walking")
    elseif Config.AutoSelectEMSType then
        RequestEMSWithPayment(AutoDetectEMSType())
    else
        OpenPlayerEMSMenu(function(choice)
            if choice == "auto" then
                RequestEMSWithPayment(AutoDetectEMSType())
            elseif choice == "walking" then
                RequestEMSWithPayment("walking")
            else
                RequestEMSWithPayment(choice)
            end
        end)
    end
end

local emsMenuOptions
if Config.WalkingNPCMode then
    emsMenuOptions = {
        {
            title = locale("walking_title"),
            description = locale("walking_description"),
            icon = "user-doctor",
            onSelect = CreateEMSSelectHandler("walking")
        }
    }
else
    emsMenuOptions = {
        {
            title = locale("heli_title"),
            description = locale("heli_description"),
            icon = "helicopter",
            onSelect = CreateEMSSelectHandler(Config.VehicleArgs.Heli)
        },
        {
            title = locale("car_title"),
            description = locale("car_description"),
            icon = "car",
            onSelect = CreateEMSSelectHandler(Config.VehicleArgs.Car)
        },
        {
            title = locale("boat_title"),
            description = locale("boat_description"),
            icon = "ship",
            onSelect = CreateEMSSelectHandler(Config.VehicleArgs.Boat)
        },
        {
            title = locale("sub_title"),
            description = locale("sub_description"),
            icon = "anchor",
            onSelect = CreateEMSSelectHandler(Config.VehicleArgs.Sub)
        }
    }
end

if not Config.WalkingNPCMode and Config.AutoSelectEMSType then
    table.insert(emsMenuOptions, 1, {
        title = locale("auto_title"),
        description = locale("auto_description"),
        icon = "wand-magic-sparkles",
        onSelect = function()
            RequestEMSWithPayment(AutoDetectEMSType())
        end
    })
end

if Config.RegisterKeybind then
    lib.addKeybind({
        name = "open_ems_menu",
        description = "Open AI EMS Menu",
        defaultKey = Config.Keybind,
        onPressed = function()
            if IsInRestrictedZone() then
                Notify(locale("restricted_zone"), "error")
                return
            end

            if (IsPlayerDead() or Config.AlivePlayerCanCall) and reviveHandled then
                OpenEMSSelection()
            elseif not IsPlayerDead() and not Config.AlivePlayerCanCall then
                Notify(locale("only_when_dead"), "error")
            end
        end
    })
end

if Config.QuickAction then
    lib.addKeybind({
        name = "call_ai_ems_quick",
        description = "Quick Action EMS Call",
        defaultKey = Config.QuickActionKey,
        onPressed = function()
            if quickActionCooldown then
                Notify(locale("wait_before_use"), "error")
                return
            end

            quickActionCooldown = true
            Citizen.SetTimeout(5000, function()
                quickActionCooldown = false
            end)

            if emsCallInProgress then
                Notify(locale("ems_already_on_way"), "error")
                return
            end

            if IsInRestrictedZone() then
                Notify(locale("restricted_zone"), "error")
                return
            end

            if not IsPlayerDead() and not Config.AlivePlayerCanCall then
                Notify(locale("only_when_dead"), "error")
                return
            end

            if Config.WalkingNPCMode then
                RequestEMSWithPayment("walking")
                return
            end

            local vehicleType
            if Config.AutoSelectEMSType then
                vehicleType = AutoDetectEMSType()
            else
                vehicleType = Config.QuickActionCommand
                if not IsSupportedVehicleArg(vehicleType) then
                    Notify(FormatVehicleTypeMessage("invalid_vehicle_type"), "error")
                    return
                end
            end

            RequestEMSWithPayment(vehicleType)
        end
    })
end

exports("OpenEMSMenu", function()
    if not IsPlayerDead() and not Config.AlivePlayerCanCall then
        return false
    end

    if emsCallInProgress then
        return false
    end

    if IsInRestrictedZone() then
        return false
    end

    OpenEMSSelection()
    return true
end)

exports("CallSpecificEMS", function(vehicleType)
    return TryCallEMS(vehicleType)
end)

RegisterNetEvent("allgamers_aidoc:client:OpenEMSMenu", function()
    if not IsPlayerDead() and not Config.AlivePlayerCanCall then
        return
    end

    if emsCallInProgress then
        return
    end

    if IsInRestrictedZone() then
        return
    end

    OpenEMSSelection()
end)

RegisterNetEvent("allgamers_aidoc:client:CallSpecificEMS", function(vehicleType)
    TryCallEMS(vehicleType)
end)

-- Debug + chat suggestions

if Config.Debug then
    Citizen.CreateThread(function()
        Citizen.Wait(1000)

        for index, beach in ipairs(Config.SubmarineBeachLocations) do
            local blip = AddBlipForCoord(beach.x, beach.y, beach.z)
            SetBlipSprite(blip, 308)
            SetBlipColour(blip, 1)
            SetBlipScale(blip, 0.6)
            SetBlipAsShortRange(blip, true)
            BeginTextCommandSetBlipName("STRING")
            AddTextComponentString("Sub Rescue #" .. index)
            EndTextCommandSetBlipName(blip)
        end

        Citizen.CreateThread(function()
            while true do
                Citizen.Wait(0)
                local playerCoords = GetEntityCoords(PlayerPedId())
                for index, beach in ipairs(Config.SubmarineBeachLocations) do
                    if #(playerCoords - beach) < 50.0 then
                        DrawText3D(beach.x, beach.y, beach.z + 1.0, string.format("Sub Rescue #%d\n%.2f, %.2f, %.2f", index, beach.x, beach.y, beach.z))
                    end
                end
            end
        end)
    end)
end

CreateThread(function()
    local vehicleTypeHelp = "Vehicle type: " .. Config.VehicleArgs.Car .. ", " .. Config.VehicleArgs.Heli .. ", " .. Config.VehicleArgs.Boat .. ", " .. Config.VehicleArgs.Sub

    if Config.WalkingNPCMode then
        TriggerEvent("chat:addSuggestion", "/" .. Config.SendEMSCommand, locale("sendems_usage"), {
            { name = locale("player_id"), help = "Player ID to call EMS for" }
        })
        TriggerEvent("chat:addSuggestion", "/" .. Config.CallCommand, locale("walking_description"), {})
    else
        TriggerEvent("chat:addSuggestion", "/" .. Config.SendEMSCommand, locale("sendems_usage"), {
            { name = locale("player_id"), help = "Player ID to call EMS for" },
            { name = locale("vehicle_type"), help = vehicleTypeHelp }
        })

        if Config.AutoSelectEMSType then
            TriggerEvent("chat:addSuggestion", "/" .. Config.CallCommand, locale("auto_description"), {})
        else
            TriggerEvent("chat:addSuggestion", "/" .. Config.CallCommand, locale("specify_vehicle_type"), {
                { name = locale("vehicle_type"), help = vehicleTypeHelp }
            })
        end
    end

    TriggerEvent("chat:addSuggestion", "/" .. Config.CancelCommand, locale("cancel_command_desc"), {})
end)
