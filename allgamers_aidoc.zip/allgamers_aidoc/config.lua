Config = {}

-- General bootstrap settings (kept in config.lua, not managed by admin UI)
Config.Debug = false
Config.Language = 'en' -- Available: 'en' (English), 'bn' (Bengali), 'es' (Spanish), 'fr' (French), 'de' (German), 'pt' (Portuguese), 'ru' (Russian), 'tr' (Turkish), 'zh-cn' (Chinese Simplified)
Config.Notify = 'bridge'   -- Uses allgamers_bridge so the same config works on ESX / QBCore / Qbox. Also: 'ox' | 'qb' | 'esx' | 'qbx'

Config.AdminSetupCommand = "aidocsetup" -- For admins: type / and this name in chat to open the Setup menu or Settings menu
Config.adminjob = false -- If true, the job below can also open that menu; if false, only admins with permission can
Config.adminjobname = "admin" -- Exact job name when adminjob is on (spelling must match your server)

Config.AmbulanceScriptOptions = {  -- These will show in the Settings menu for admins to choose from. 
    { value = 'default', label = 'Default (Framework)' },
    { value = 'VisnAre', label = 'Visn Are' },
    { value = 'wasabi_ambulance', label = 'Wasabi Ambulance' },
    { value = 'brutal_ambulancejob', label = 'Brutal Ambulance' },
    { value = 'ars_ambulancejob', label = 'ARS Ambulance' },
    { value = 'osp_ambulance', label = 'OSP Ambulance' },
    { value = 'tk_ambulancejob', label = 'TK Ambulance' },
    { value = 'quasar_ambulance', label = 'Quasar Ambulance' }, -- For servers using Quasar's new Medical Creator script.
}

-- Submarine beach rescue locations (static map data, not shown in admin UI)
Config.SubmarineBeachLocations = {
    vector3(-650.03, 6336.33, 1.52), vector3(-202.01, 6686.95, 2.01), vector3(-26.18, 6993.72, 1.26), vector3(50.52, 7256.19, 1.03),
    vector3(-1006.77, 6274.56, 1.16), vector3(-922.35, 5778.50, 0.86), vector3(-1264.98, 5401.47, 0.53), vector3(-1413.02, 5235.45, 0.94),
    vector3(-1821.50, 4861.68, 0.61), vector3(-1821.58, 4861.77, 0.57), vector3(-2297.35, 4474.04, 1.05), vector3(-2529.17, 4030.54, 0.63),
    vector3(-2593.25, 3670.85, 0.78), vector3(-3052.03, 3534.38, 0.66), vector3(-3190.73, 3260.15, 0.61), vector3(-2961.95, 2242.83, 1.12),
    vector3(-3107.75, 1893.60, -0.01), vector3(-3229.04, 1366.65, 0.66), vector3(-3177.22, 269.13, 0.82), vector3(-2443.48, -335.43, 1.23),
    vector3(-1822.86, -959.80, 0.36), vector3(-1260.65, -1853.46, 0.64), vector3(-1977.27, -3144.69, 0.81), vector3(-988.92, -3593.75, 0.15),
    vector3(-856.11, -3073.98, 0.54), vector3(1373.26, -2752.88, 1.25), vector3(2280.79, -2164.77, 1.18), vector3(2677.90, -1722.71, 1.16),
    vector3(2844.28, -784.48, 0.84), vector3(2936.95, 322.76, 1.02), vector3(2963.72, 736.09, 0.63), vector3(2793.27, 1250.11, 1.28),
    vector3(3031.26, 1841.59, 1.02), vector3(3303.44, 2208.01, 0.41), vector3(3390.66, 2674.25, 0.81), vector3(3762.91, 3816.08, 0.73),
    vector3(3828.91, 4519.88, 1.34), vector3(3306.72, 5253.30, 0.80), vector3(3446.90, 5914.59, 0.68), vector3(2988.93, 6384.88, 0.46),
    vector3(1507.84, 6639.83, 1.16), vector3(1067.14, 6636.42, 1.10), vector3(802.27, 6674.50, 0.78), vector3(411.44, 6921.15, 1.07),
    vector3(242.74, 7073.42, 1.11), vector3(-2753.47, -106.27, 0.80), vector3(-2527.18, -278.47, 0.97), vector3(-2104.02, -583.44, 1.11),
    vector3(-1939.21, -776.15, 0.96), vector3(-1525.04, -1351.92, 0.98), vector3(-1448.77, -1533.06, 1.21), vector3(-1309.13, -1767.01, 0.90),
    vector3(-1120.85, -1855.58, 0.76), vector3(-782.50, -1497.76, 1.06), vector3(625.11, -1980.69, 8.55), vector3(1037.46, -666.47, 55.87),
    vector3(815.90, 3680.34, 30.14), vector3(1919.13, 3999.26, 30.10), vector3(2357.53, 4498.60, 30.10), vector3(1897.37, 4510.35, 30.43),
    vector3(1361.77, 4272.29, 30.18), vector3(782.97, 4141.48, 30.41), vector3(217.30, 4288.58, 30.15), vector3(-143.40, 3910.47, 30.83),
    vector3(-591.05, 4404.69, 15.40), vector3(-1477.78, 2597.57, 0.81),
    vector3(-1381.02, -3468.01, 0.55), vector3(-1699.31, -3355.35, 1.07), vector3(-1896.26, -3238.14, 0.40), vector3(-1997.38, -2979.57, 0.48),
    vector3(-1875.62, -2753.76, 0.49), vector3(-1737.85, -2510.25, 0.94), vector3(-1524.82, -2195.00, 0.86), vector3(-1289.53, -2031.70, 0.86),
    vector3(1074.17, -2685.91, 0.59), vector3(1838.91, -2703.54, 0.32),
    vector3(-821.75, -3415.64, 0.30), vector3(36.89, -2243.40, 0.59),
    vector3(1906.83, 254.68, 160.53), vector3(1925.74, 379.53, 160.50), vector3(1995.35, 351.43, 160.62)
}

