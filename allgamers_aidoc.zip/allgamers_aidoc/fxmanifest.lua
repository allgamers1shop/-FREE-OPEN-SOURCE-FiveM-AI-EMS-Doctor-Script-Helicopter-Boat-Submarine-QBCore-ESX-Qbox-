fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'allgamers AI EMS SYSTEM'
author 'APOLLO'

version '2.1.0'

shared_scripts {
    '@allgamers_bridge/shared/init.lua',
    '@ox_lib/init.lua',
    'config.lua',
    'shared/settings.lua',
}

client_scripts {
    'client/cl_utils.lua',
    'client/settings.lua',
    'client/main.lua',
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/logs.lua',
    'server/settings.lua',
    'server/main.lua',
}

files {
    'locales/*.json',
    'ui/build/index.html',
    'ui/build/assets/*',
    'ui/build/img/*',
}

ui_page 'ui/build/index.html'
-- ui_page 'http://localhost:5173/'


escrow_ignore {
    'config.lua',
    'client/cl_utils.lua',
    'client/settings.lua',
    'server/logs.lua',
}

dependencies {
    'allgamers_bridge',
    'ox_lib',
    'oxmysql',
}

dependency '/assetpacks'
