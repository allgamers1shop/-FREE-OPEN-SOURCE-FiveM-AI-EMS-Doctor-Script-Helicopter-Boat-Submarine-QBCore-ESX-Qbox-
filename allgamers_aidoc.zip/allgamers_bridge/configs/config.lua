config = {}

config.Debug = false


-- Keep Framework/Target/Inventory/etc on "auto" so the same bridge works on ESX, QBCore, and Qbox.
config.Framework = "auto"
config.Dispatch = "custom"   -- set to cd_dispatch / linden when that resource is installed; custom = safe no-op
config.Target = "auto"       -- auto | ox_target | qb-target
config.TextUI = "auto"       -- auto | ox_lib | jg-textui | okokTextUI | cd_drawtextui | lation_ui
config.ProgressBar = "auto"    -- auto | ox_lib | lation_ui | progressbar
config.Banking = "auto"      -- auto | qb-banking | p_banking | okokBanking | fd_banking | renewed-banking | tgg-banking | kartik-banking | tgiann-bank | wasabi_banking | qb-management | qbx_management | esx_society | qs-banking
config.Inventory = "auto"     -- auto | qb-inventory | ox_inventory | codem-inventory | origen_inventory | qs-inventory | tgiann-inventory | jpr-inventory | ps-inventory | core_inventory
config.Fuel = "auto"  -- auto | ox_fuel | qb-fuel | savana-fuel | ps-fuel | qs-fuelstations | legacyfuel | renewed-fuel | ti_fuel | lc_fuel | lj-fuel | x-fuel | cdn-fuel | esx-sna-fuel | bigdaddy-fuel | okokgasstation | rcore_fuel
config.VehicleKeys = "auto"   -- auto | qb-vehiclekeys | qbx_vehiclekeys | qs-vehiclekeys | Renewed-Vehiclekeys | wasabi_carlock | okokGarage | cd_garage | mk_vehiclekeys | mono_carkeys | MrNewbVehicleKeys | mVehicle | t1ger_keys | F_RealCarKeysSystem | jacksam

config.AdminGroups = {
    ["owner"] = true,
    ["admin"] = true,
    ["moderator"] = true,
    ["helper"] = true,
}

config.EnableAcePermissions = true
config.AcePermissions = {
    "command",
    "admin",
    "allgamers.admin",
}
