---@diagnostic disable: duplicate-set-field
if GetResourceState('qs-inventory') == 'missing' then return end

local QsInventoryClientAPI = {}

local invExport
local isInitialized = false

local function initializeQsInventoryClient()
    if isInitialized then return true end

    if GetResourceState('qs-inventory') ~= 'started' then
        return false
    end

    invExport = exports['qs-inventory']
    if not invExport then
        return false
    end

    isInitialized = true
    if config and config.Debug then
        DebugPrint("QS-Inventory client initialized", "success")
    end

    return true
end

local function validateItem(item, operation)
    if not item then
        DebugPrint(string.format("%s: Item parameter required", operation), "error")
        return false
    end
    return true
end

QsInventoryClientAPI.GetResourceName = function()
    return "qs-inventory"
end

QsInventoryClientAPI.GetItemInfo = function(item)
    if not initializeQsInventoryClient() then return {} end
    if not validateItem(item, "GetItemInfo") then return {} end

    local itemsData = invExport:GetItemList()
    if not itemsData then return {} end
    local itemData = itemsData[item]
    if not itemData then return {} end
    return {
        name = itemData.name or "Missing Name",
        label = itemData.label or "Missing Label",
        stack = itemData.unique or "false",
        weight = itemData.weight or "0",
        description = itemData.description or "none",
        image = QsInventoryClientAPI.GetImagePath(item),
    }
end

QsInventoryClientAPI.Items = function()
    if not initializeQsInventoryClient() then return {} end
    return invExport:GetItemList()
end

QsInventoryClientAPI.HasItem = function(item, requiredCount)
    if not initializeQsInventoryClient() then return false end
    if not validateItem(item, "HasItem") then return false end

    local check = invExport:Search(item)
    return check and true or false
end

QsInventoryClientAPI.GetItemCount = function(item)
    if not initializeQsInventoryClient() then return 0 end
    if not validateItem(item, "GetItemCount") then return 0 end

    local searchItem = invExport:Search(item)
    return searchItem or 0
end

QsInventoryClientAPI.GetPlayerInventory = function()
    if not initializeQsInventoryClient() then return {} end

    local items = {}
    local inventory = invExport:getUserInventory()
    for _, v in pairs(inventory) do
        table.insert(items, {
            name = v.name,
            label = v.label,
            count = v.amount or v.count,
            slot = v.slot,
            metadata = v.info or v.metadata or {},
            stack = v.unique or v.stack or false,
            close = v.useable,
            weight = v.weight
        })
    end
    return items
end

QsInventoryClientAPI.GetImagePath = function(item)
    if not item then return "" end

    item = QsInventoryClientAPI.StripImageExtension(item)
    local file = LoadResourceFile("qs-inventory", string.format("html/images/%s.png", item))
    local imagePath = file and string.format("nui://qs-inventory/html/images/%s.png", item)
    return imagePath or "https://raw.githubusercontent.com/AllGamers-Scripts/allgamers-assets/main/inventory-placeholder.png"
end

QsInventoryClientAPI.StripImageExtension = function(item)
    if not item then return "" end
    return item:gsub("%.png$", ""):gsub("%.jpg$", ""):gsub("%.jpeg$", ""):gsub("%.webp$", "")
end

QsInventoryClientAPI.CanCarryItem = function(item, count)
    if not initializeQsInventoryClient() then return true end
    if not validateItem(item, "CanCarryItem") or not count then return false end
    if invExport and invExport.CanCarryItem then
        return invExport:CanCarryItem(item, count)
    end
    return true
end

QsInventoryClientAPI.GetInventoryWeight = function()
    if not initializeQsInventoryClient() then return 0 end
    if invExport and invExport.GetWeight then
        return invExport:GetWeight()
    end
    return 0
end

QsInventoryClientAPI.GetInventoryMaxWeight = function()
    if not initializeQsInventoryClient() then return 100000 end
    if invExport and invExport.GetMaxWeight then
        return invExport:GetMaxWeight()
    end
    return 100000
end

return QsInventoryClientAPI
