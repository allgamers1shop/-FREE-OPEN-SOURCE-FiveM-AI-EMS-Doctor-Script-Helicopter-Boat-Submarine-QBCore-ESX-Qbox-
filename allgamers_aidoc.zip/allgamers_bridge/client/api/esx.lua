if GetResourceState('es_extended') ~= 'started' then return end

local ESX = exports["es_extended"]:getSharedObject()
local ALLGAMERS = {}

function ALLGAMERS.IsPlayerLoaded()
    return ESX.IsPlayerLoaded()
end

function ALLGAMERS.GetPlayerData()
    return ESX.GetPlayerData()
end

function ALLGAMERS.SetPlayerData(key, value)
    ESX.SetPlayerData(key, value)
end

function ALLGAMERS.OpenInventory()
    ESX.ShowInventory()
end

function ALLGAMERS.ShowNotification(text)
    ESX.ShowNotification(text)
end

function ALLGAMERS.CloseMenu()
    ESX.UI.Menu.CloseAll()
end

function ALLGAMERS.GetJob()
    local playerData = ALLGAMERS.GetPlayerData()
    return playerData.job.name or "unemployed"
end

function ALLGAMERS.GetJobGrade()
    local playerData = ALLGAMERS.GetPlayerData()
    return playerData.job.grade
end

function ALLGAMERS.GetJobInfo()
    local playerData = ALLGAMERS.GetPlayerData()
    local job = playerData.job
    local isBoss = (job.grade_name == "boss")
    return {
        jobName = job.name,
        jobLabel = job.label,
        gradeName = job.grade_name,
        gradeLabel = job.grade_label,
        gradeRank = job.grade,
        boss = isBoss,
        onDuty = job.onduty
    }
end

function ALLGAMERS.HasItem(item_name)
    local count = 0
    for _, v in pairs(ALLGAMERS.GetPlayerData().inventory or {}) do
        if v.name == item_name then
            count = v.count or 0
            return count > 0, count
        end
    end
    return false, 0
end

function ALLGAMERS.GetInventory()
    local playerData = ALLGAMERS.GetPlayerData()
    return playerData.inventory
end

function ALLGAMERS.GetPlayerMetaData(metadata)
    return ALLGAMERS.GetPlayerData().metadata[metadata]
end

function ALLGAMERS.GetIsPlayerDead()
    if LocalPlayer.state and LocalPlayer.state.isDead == true then
        return true
    end

    local playerData = ALLGAMERS.GetPlayerData()
    return (playerData and playerData.dead) == true
end

function ALLGAMERS.GetPlayerName()
    local data = ESX.GetPlayerData()
    local firstName, lastName = "", ""
    
    if data then
        if data.firstName or data.lastName then
            firstName = data.firstName or ""
            lastName = data.lastName or ""
        elseif data.name then
            local fn, ln = data.name:match("^(%S+)%s*(.*)$")
            firstName = fn or data.name
            lastName = ln or ""
        end
    end
    
    return tostring(firstName), tostring(lastName)
end

function ALLGAMERS.Dispatch(code, title, message, blip, jobs, important)
    if config.Dispatch:lower() == "cd_dispatch" then
        local data = exports['cd_dispatch']:GetPlayerInfo()
        TriggerServerEvent('cd_dispatch:AddNotification', {
            job_table = jobs or { "police" },
            coords = data.coords,
            title = ("%s - %s"):format(code or "10-00", title or "Missing Title"),
            message = message or "Sample Message",
            flash = 0,
            unique_id = data.unique_id,
            sound = 1,
            blip = {
                sprite = blip,
                scale = 1.2,
                colour = 3,
                flashes = false,
                text = title,
                time = 5,
                radius = 0,
            }
        })
    elseif config.Dispatch:lower() == "linden" then
        local data = {
            displayCode = code,
            description = title,
            isImportant = important and 1 or 0,
            recipientList = jobs,
            length = '10000',
            infoM = 'fa-info-circle',
            info = message
        }
        local dispatchData = { dispatchData = data, caller = 'Alarm', coords = GetEntityCoords(PlayerPedId()) }
        TriggerServerEvent('wf-alerts:svNotify', dispatchData)
    elseif config.Dispatch:lower() == "custom" then
    end
end


return ALLGAMERS