if GetResourceState('qbx_core') ~= 'started' then return end

local ALLGAMERS = {}

function ALLGAMERS.IsPlayerLoaded()
    return (LocalPlayer and LocalPlayer.state and LocalPlayer.state.isLoggedIn) == true
end

function ALLGAMERS.GetPlayerData()
    return exports.qbx_core:GetPlayerData()
end

function ALLGAMERS.SetPlayerData(key, value)
    exports.qbx_core:SetPlayerData(key, value)
end

function ALLGAMERS.OpenInventory()
    local ox = exports.ox_inventory
    if ox and ox.openInventory then
        ox:openInventory('player')
    else
        TriggerEvent('ox_inventory:openInventory')
    end
end

function ALLGAMERS.ShowNotification(text)
    exports.qbx_core:Notify(text)
end

function ALLGAMERS.CloseMenu()
    exports.ox_lib:hideContext()
end

function ALLGAMERS.GetJob()
    local playerData = ALLGAMERS.GetPlayerData()
    return playerData.job.name or "unemployed"
end

function ALLGAMERS.GetJobGrade()
    local playerData = ALLGAMERS.GetPlayerData()
    return playerData.job.grade.level
end

function ALLGAMERS.GetJobInfo()
    local playerData = ALLGAMERS.GetPlayerData()
    local job = playerData.job
    local isBoss = (job.grade.name == "boss")
    return {
        jobName = job.name,
        jobLabel = job.label,
        gradeName = job.grade.name,
        gradeLabel = job.grade.label,
        gradeRank = job.grade.level,
        boss = isBoss,
        onDuty = job.onduty
    }
end

function ALLGAMERS.HasItem(item_name)
    if GetResourceState('ox_inventory') ~= 'started' then return false, 0 end
    local count = exports.ox_inventory:GetItemCount(item_name) or 0
    return count > 0, count
end

function ALLGAMERS.GetInventory()
    return exports.ox_inventory:GetInventory()
end

function ALLGAMERS.GetPlayerMetaData(metadata)
    return ALLGAMERS.GetPlayerData().metadata[metadata]
end

function ALLGAMERS.GetIsPlayerDead()
    local playerData = ALLGAMERS.GetPlayerData()
    return playerData.metadata["isdead"] or playerData.metadata["inlaststand"]
end

function ALLGAMERS.GetPlayerName()
    local data = exports.qbx_core:GetPlayerData()
    local firstName, lastName = "", ""
    
    if data and data.charinfo then
        firstName = data.charinfo.firstname or ""
        lastName = data.charinfo.lastname or ""
    end
    
    return tostring(firstName), tostring(lastName)
end

function ALLGAMERS.Dispatch(code, title, message, blip, jobs, important)
    if config.Dispatch:lower() == "cd_dispatch" then
        local data = exports['cd_dispatch']:GetPlayerInfo()
        TriggerServerEvent('cd_dispatch:AddNotification', {
            job_table = jobs or { "police" },
            coords = data.coords,
            title = ("%s - %s"):format(code or "10-00", title or "Missing Title"),
            message = message or "Sample Message",
            flash = 0,
            unique_id = data.unique_id,
            sound = 1,
            blip = {
                sprite = blip,
                scale = 1.2,
                colour = 3,
                flashes = false,
                text = title,
                time = 5,
                radius = 0,
            }
        })
    elseif config.Dispatch:lower() == "linden" then
        local data = {
            displayCode = code,
            description = title,
            isImportant = important and 1 or 0,
            recipientList = jobs,
            length = '10000',
            infoM = 'fa-info-circle',
            info = message
        }
        local dispatchData = { dispatchData = data, caller = 'Alarm', coords = GetEntityCoords(PlayerPedId()) }
        TriggerServerEvent('wf-alerts:svNotify', dispatchData)
    elseif config.Dispatch:lower() == "custom" then
    end
end

return ALLGAMERS