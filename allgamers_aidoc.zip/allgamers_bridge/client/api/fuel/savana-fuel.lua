---@diagnostic disable: duplicate-set-field
if GetResourceState('savana-fuel') == 'missing' then return end

local SavanaFuelAPI = {}

function SavanaFuelAPI.GetResourceName()
    return "savana-fuel"
end

function SavanaFuelAPI.GetFuel(vehicle)
    if not DoesEntityExist(vehicle) then return 0.0 end
    return exports["savana-fuel"]:GetFuel(vehicle) or 0.0
end

function SavanaFuelAPI.SetFuel(vehicle, fuel, fuelType)
    if not DoesEntityExist(vehicle) then return end
    exports["savana-fuel"]:SetFuel(vehicle, fuel)
end

function SavanaFuelAPI.GetFuelCapacity(vehicle)
    return 65.0
end

return SavanaFuelAPI
