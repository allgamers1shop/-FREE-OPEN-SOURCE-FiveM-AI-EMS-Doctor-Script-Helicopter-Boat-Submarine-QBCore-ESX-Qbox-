if GetResourceState('lj-fuel') == 'missing' then return end

local LjFuelAPI = {}

function LjFuelAPI.GetResourceName()
    return "lj-fuel"
end

function LjFuelAPI.GetFuel(vehicle)
    if not DoesEntityExist(vehicle) then return 0.0 end
    return exports['lj-fuel']:GetFuel(vehicle) or 0.0
end

function LjFuelAPI.SetFuel(vehicle, fuel, fuelType)
    if not DoesEntityExist(vehicle) then return end
    exports['lj-fuel']:SetFuel(vehicle, fuel)
end

function LjFuelAPI.GetFuelCapacity(vehicle)
    return 65.0
end

return LjFuelAPI
