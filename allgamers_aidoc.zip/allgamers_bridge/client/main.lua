local ALLGAMERS = ALLGAMERS or {}
local API
local framework

local function waitFor(res)
    local t = GetGameTimer()
    while GetResourceState(res) ~= 'started' do
        if GetGameTimer() - t > 15000 then
            print(('^1[allgamers_bridge]^7 timeout waiting for %s'):format(res))
            break
        end
        Wait(50)
    end
end

if config.Framework:lower() ~= "auto" then
    framework = config.Framework:lower()
    if config.Debug then
        DebugPrint("Using manually configured framework: " .. framework, "info")
    end
else
    local qb = GetResourceState('qb-core') == "started"
    local qbx = GetResourceState('qbx_core') == "started"
    local esx = GetResourceState('es_extended') == "started"

    if config.Debug then
        DebugPrint("Framework detection results:", "debug")
        DebugPrint("QB-Core: " .. (qb and "Found" or "Not found"), "debug")
        DebugPrint("QBX-Core: " .. (qbx and "Found" or "Not found"), "debug")
        DebugPrint("ESX Extended: " .. (esx and "Found" or "Not found"), "debug")
    end

    if qbx then 
        framework = 'qbx'
        if config.Debug then
            DebugPrint("Framework detected: QBX-Core", "success")
        end
    elseif qb then 
        framework = 'qb'
        if config.Debug then
            DebugPrint("Framework detected: QB-Core", "success")
        end
    elseif esx then 
        framework = 'esx'
        if config.Debug then
            DebugPrint("Framework detected: ESX Extended", "success")
        end
    else
        DebugPrint("Couldn't detect your framework! Please make sure that allgamers_bridge starts AFTER your framework resource.", "error")
        return error("Unknown Framework")
    end
end

local function loadApiFile(name)
    local res = GetCurrentResourceName()
    local path = ('client/api/%s.lua'):format(name)
    local src = LoadResourceFile(res, path)
    assert(src, ('[allgamers_bridge] missing api file: %s'):format(path))
    local chunk, err = load(src, ('=@%s'):format(path))
    assert(chunk, err)
    local mod = chunk()
    assert(type(mod) == 'table', ('[allgamers_bridge] %s must return a table'):format(path))
    return mod
end

local function loadInventoryFile(name)
    local res = GetCurrentResourceName()

    local fileVariations = {
        name,
        name:gsub("-", "_"),
        name:gsub("_", "-"),
    }

    local src, path
    for _, fileName in ipairs(fileVariations) do
        path = ('client/api/inventory/%s.lua'):format(fileName)
        src = LoadResourceFile(res, path)
        if src then
            if config.Debug then
                DebugPrint(('Found inventory file: %s'):format(path), "debug")
            end
            break
        end
    end

    if not src then
        if config.Debug then
            DebugPrint(('Inventory file not found for %s (tried multiple variations)'):format(name), "debug")
        end
        return nil
    end
    local chunk, err = load(src, ('=@%s'):format(path))
    if not chunk then
        if config.Debug then
            DebugPrint(('Error loading inventory file %s: %s'):format(path, err), "error")
        end
        return nil
    end
    local mod = chunk()
    if type(mod) ~= 'table' then
        if config.Debug then
            DebugPrint(('Inventory file %s must return a table'):format(path), "error")
        end
        return nil
    end
    return mod
end

if framework == 'qb' then
    waitFor('qb-core')
    API = loadApiFile('qb')
    -- Register QB-Core player loaded event
    RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
        Wait(1500)
        TriggerEvent('allgamers_bridge:Client:OnPlayerLoaded')
    end)
    -- Register QB-Core player unload event
    RegisterNetEvent('QBCore:Client:OnPlayerUnload', function()
        TriggerEvent('allgamers_bridge:Client:OnPlayerUnload')
    end)
    -- Register QB-Core job update event
    RegisterNetEvent('QBCore:Client:OnJobUpdate', function(data)
        TriggerEvent('allgamers_bridge:Client:OnPlayerJobUpdate', data.name, data.label, data.grade_label, data.grade)
    end)
elseif framework == 'qbx' then
    waitFor('qbx_core')
    API = loadApiFile('qbx')
    -- Register QBX-Core player loaded event
    RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
        Wait(1500)
        TriggerEvent('allgamers_bridge:Client:OnPlayerLoaded')
    end)
    -- Register QBX-Core player unload event
    RegisterNetEvent('QBCore:Client:OnPlayerUnload', function()
        TriggerEvent('allgamers_bridge:Client:OnPlayerUnload')
    end)
    -- Register QBX-Core job update event
    RegisterNetEvent('QBCore:Client:OnJobUpdate', function(data)
        TriggerEvent('allgamers_bridge:Client:OnPlayerJobUpdate', data.name, data.label, data.grade_label, data.grade)
    end)
elseif framework == 'esx' then
    waitFor('es_extended')
    API = loadApiFile('esx')
    -- Register ESX player loaded event
    RegisterNetEvent('esx:playerLoaded', function(xPlayer)
        Wait(1500)
        TriggerEvent('allgamers_bridge:Client:OnPlayerLoaded')
    end)
    -- Register ESX player unload event
    RegisterNetEvent('esx:playerDropped', function()
        TriggerEvent('allgamers_bridge:Client:OnPlayerUnload')
    end)
    -- Register ESX job update event
    RegisterNetEvent('esx:setJob', function(job, lastJob)
        TriggerEvent('allgamers_bridge:Client:OnPlayerJobUpdate', job.name, job.label, job.grade_label, job.grade)
    end)
end

if framework == 'qb' then
    _G.Framework = exports['qb-core']:GetCoreObject()
elseif framework == 'qbx' then
    _G.Framework = exports['qb-core']:GetCoreObject()
elseif framework == 'esx' then
    _G.Framework = exports['es_extended']:getSharedObject()
end

-- Register inventory update event
RegisterNetEvent('allgamers_bridge:client:inventory:update', function(updateData)
    if config.Debug then
        DebugPrint("Inventory update received: " .. json.encode(updateData), "debug")
    end
    -- Trigger custom event for scripts that want to listen to inventory updates
    TriggerEvent('allgamers_bridge:client:inventoryUpdate', updateData)
end)

-- Load Target, TextUI, ProgressBar, Fuel, VehicleKeys and Inventory modules
local TARGET = loadApiFile('target')
local TEXTUI = loadApiFile('textui')
local PROGRESSBAR = loadApiFile('progressbar')
local FUEL = loadApiFile('fuel')
local VEHICLEKEYS = loadApiFile('vehiclekeys')

-- Load appropriate inventory system
local inventorySystems = {
    'qb-inventory',
    'ox_inventory',
    'codem-inventory',
    'origen_inventory',
    'qs-inventory',
    'tgiann-inventory',
    'jpr-inventory',
    'ps-inventory',
    'core_inventory'
}

local INVENTORY


if config.Inventory and config.Inventory:lower() ~= "auto" then
    local requestedSystem = config.Inventory:lower()
    local mod = loadInventoryFile(requestedSystem)
    if mod and mod.GetResourceName then
        INVENTORY = mod
        if config.Debug then
            DebugPrint("Loaded inventory client: " .. requestedSystem, "success")
        end
    else
        DebugPrint("Failed to load manually configured inventory system: " .. requestedSystem, "error")
        if config.Debug then
            DebugPrint("Manual inventory system not available, loading default", "debug")
        end
        INVENTORY = loadInventoryFile('_default') 
        if not INVENTORY then
            INVENTORY = {} 
        end
    end
else
    -- Auto-detection mode
    if config.Debug then
        DebugPrint("Inventory system set to auto-detection", "debug")
        DebugPrint("Inventory detection results:", "debug")
        for _, system in ipairs(inventorySystems) do
            local status = GetResourceState(system) == 'started' and "Found" or "Not found"
            DebugPrint(system .. ": " .. status, "debug")
        end
    end

    for _, system in ipairs(inventorySystems) do
        if GetResourceState(system) == 'started' then
            local mod = loadInventoryFile(system)
            if mod and mod.GetResourceName then
                INVENTORY = mod
                if config.Debug then
                    DebugPrint("Loaded inventory client: " .. system, "success")
                end
                break
            end
        end
    end

    if not INVENTORY then
        INVENTORY = loadInventoryFile('_default') 
        if not INVENTORY then
            INVENTORY = {} 
        end
        if config.Debug then
            DebugPrint("No inventory system found, using framework default", "warning")
        end
    end
end

if config.Debug then
    DebugPrint("AllGamers Bridge initialized successfully with framework: " .. framework, "success")
end

---@return string
function ALLGAMERS.GetFrameworkName()
    if config.Debug then
        DebugPrint("GetFrameworkName function called", "debug")
    end
    return framework
end

function ALLGAMERS.IsPlayerLoaded()
    if config.Debug then
        DebugPrint("IsPlayerLoaded function called", "debug")
    end
    return API.IsPlayerLoaded()
end

---@return table
function ALLGAMERS.GetPlayerData()
    if config.Debug then
        DebugPrint("GetPlayerData function called", "debug")
    end
    return API.GetPlayerData()
end

---@param key string
---@param value any
function ALLGAMERS.SetPlayerData(key, value)
    if config.Debug then
        DebugPrint("SetPlayerData function called with Key: " .. key .. ", Value: " .. tostring(value), "debug")
    end
    API.SetPlayerData(key, value)
end

function ALLGAMERS.OpenInventory()
    if config.Debug then
        DebugPrint("OpenInventory function called", "debug")
    end
    API.OpenInventory()
end

---@param text string
function ALLGAMERS.ShowNotification(text)
    if config.Debug then
        DebugPrint("ShowNotification function called with Text: " .. text, "debug")
    end
    API.ShowNotification(text)
end

---@param code string Dispatch code (10-XX)
---@param title string Dispatch title message
---@param message string Dispatch description
---@param blip number Blip sprite number
---@param jobs table Table containing recipient jobs
---@param important boolean | number Is the dispatch important?
function ALLGAMERS.Dispatch(code, title, message, blip, jobs, important)
    if config.Debug then
        DebugPrint("Dispatch function called with Code: " .. tostring(code) .. ", Title: " .. tostring(title), "debug")
    end
    API.Dispatch(code, title, message, blip, jobs, important)
end

---@return string
function ALLGAMERS.GetJob()
    if config.Debug then
        DebugPrint("GetJob function called", "debug")
    end
    return API.GetJob()
end

---@return number
function ALLGAMERS.GetJobGrade()
    if config.Debug then
        DebugPrint("GetJobGrade function called", "debug")
    end
    return API.GetJobGrade()
end

---@return table jobInfo
function ALLGAMERS.GetJobInfo()
    if config.Debug then
        DebugPrint("GetJobInfo function called", "debug")
    end
    return API.GetJobInfo()
end

---@param item_name string Item name
---@return boolean, number hasItem Returns true if player has given item in inventory and item count
function ALLGAMERS.HasItem(item_name)
    if config.Debug then
        DebugPrint("HasItem function called with Item: " .. item_name, "debug")
    end
    if INVENTORY and INVENTORY.HasItem then
        local hasItem = INVENTORY.HasItem(item_name, 1)
        if hasItem then
            local count = (INVENTORY.GetItemCount and INVENTORY.GetItemCount(item_name)) or 1
            return true, count
        end
        return false, 0
    end
    if API and API.HasItem then
        return API.HasItem(item_name)
    end
    return false, 0
end

---@return table
function ALLGAMERS.GetInventory()
    if config.Debug then
        DebugPrint("GetInventory function called", "debug")
    end
    return API.GetInventory()
end

--- Inventory System Functions

function ALLGAMERS.GetInventoryResourceName()
    if config.Debug then
        DebugPrint("GetInventoryResourceName function called", "debug")
    end
    if INVENTORY and INVENTORY.GetResourceName then
        return INVENTORY.GetResourceName()
    end
    return "default"
end

function ALLGAMERS.GetItemInfo(item)
    if config.Debug then
        DebugPrint("GetItemInfo function called with Item: " .. tostring(item), "debug")
    end
    if INVENTORY and INVENTORY.GetItemInfo then
        return INVENTORY.GetItemInfo(item)
    end
    return {}
end

function ALLGAMERS.GetAllItems()
    if config.Debug then
        DebugPrint("GetAllItems function called", "debug")
    end
    if INVENTORY and INVENTORY.Items then
        return INVENTORY.Items()
    end
    return {}
end

function ALLGAMERS.GetItemCount(item)
    if config.Debug then
        DebugPrint("GetItemCount function called with Item: " .. tostring(item), "debug")
    end
    if INVENTORY and INVENTORY.GetItemCount then
        return INVENTORY.GetItemCount(item)
    end
    return 0
end

function ALLGAMERS.GetPlayerInventory()
    if config.Debug then
        DebugPrint("GetPlayerInventory function called", "debug")
    end
    if INVENTORY and INVENTORY.GetPlayerInventory then
        return INVENTORY.GetPlayerInventory()
    end
    return {}
end

function ALLGAMERS.GetImagePath(item)
    if config.Debug then
        DebugPrint("GetImagePath function called with Item: " .. tostring(item), "debug")
    end
    if INVENTORY and INVENTORY.GetImagePath then
        return INVENTORY.GetImagePath(item)
    end
    return "https://raw.githubusercontent.com/AllGamers-Scripts/allgamers-assets/main/inventory-placeholder.png"
end

function ALLGAMERS.CanCarryItem(item, count)
    if config.Debug then
        DebugPrint("CanCarryItem function called with Item: " .. tostring(item) .. ", Count: " .. tostring(count), "debug")
    end
    if INVENTORY and INVENTORY.CanCarryItem then
        return INVENTORY.CanCarryItem(item, count)
    end
    return true
end

function ALLGAMERS.GetInventoryWeight()
    if config.Debug then
        DebugPrint("GetInventoryWeight function called", "debug")
    end
    if INVENTORY and INVENTORY.GetInventoryWeight then
        return INVENTORY.GetInventoryWeight()
    end
    return 0
end

function ALLGAMERS.GetInventoryMaxWeight()
    if config.Debug then
        DebugPrint("GetInventoryMaxWeight function called", "debug")
    end
    if INVENTORY and INVENTORY.GetInventoryMaxWeight then
        return INVENTORY.GetInventoryMaxWeight()
    end
    return 100000
end

-- ============================================
-- FUEL SYSTEM FUNCTIONS
-- ============================================

---@return string
function ALLGAMERS.GetFuelResourceName()
    if config.Debug then
        DebugPrint("GetFuelResourceName function called", "debug")
    end
    if FUEL and FUEL.GetResourceName then
        return FUEL.GetResourceName()
    end
    return "default"
end

---@param vehicle number Vehicle entity handle
---@return number Fuel level (0-100)
function ALLGAMERS.GetFuel(vehicle)
    if config.Debug then
        DebugPrint("GetFuel function called", "debug")
    end
    if FUEL and FUEL.GetFuel then
        return FUEL.GetFuel(vehicle)
    end
    return 0.0
end

---@param vehicle number Vehicle entity handle
---@param fuel number Fuel level to set
---@param fuelType? string Fuel type (for systems that support it)
function ALLGAMERS.SetFuel(vehicle, fuel, fuelType)
    if config.Debug then
        DebugPrint("SetFuel function called with fuel: " .. tostring(fuel), "debug")
    end
    if FUEL and FUEL.SetFuel then
        FUEL.SetFuel(vehicle, fuel, fuelType)
    end
end

---@return boolean
function ALLGAMERS.IsFuelSystemAvailable()
    if config.Debug then
        DebugPrint("IsFuelSystemAvailable function called", "debug")
    end
    if FUEL and FUEL.IsAvailable then
        return FUEL.IsAvailable()
    end
    return false
end

---@param vehicle number Vehicle entity handle
---@return number Max fuel capacity
function ALLGAMERS.GetFuelCapacity(vehicle)
    if config.Debug then
        DebugPrint("GetFuelCapacity function called", "debug")
    end
    if FUEL and FUEL.GetFuelCapacity then
        return FUEL.GetFuelCapacity(vehicle)
    end
    return 65.0
end

---@param vehicle number Vehicle entity handle
---@param threshold? number Fuel threshold (default: 10.0)
---@return boolean
function ALLGAMERS.NeedsFuel(vehicle, threshold)
    if config.Debug then
        DebugPrint("NeedsFuel function called", "debug")
    end
    if FUEL and FUEL.NeedsFuel then
        return FUEL.NeedsFuel(vehicle, threshold)
    end
    threshold = threshold or 10.0
    local fuel = ALLGAMERS.GetFuel(vehicle)
    return fuel <= threshold
end

---@param vehicle number Vehicle entity handle
---@param fuelType? string Fuel type
function ALLGAMERS.Refuel(vehicle, fuelType)
    if config.Debug then
        DebugPrint("Refuel function called", "debug")
    end
    if FUEL and FUEL.Refuel then
        FUEL.Refuel(vehicle, fuelType)
    else
        local capacity = ALLGAMERS.GetFuelCapacity(vehicle)
        ALLGAMERS.SetFuel(vehicle, capacity, fuelType)
    end
end

---@return string
function ALLGAMERS.GetVehicleKeysResourceName()
    if config.Debug then
        DebugPrint("GetVehicleKeysResourceName function called", "debug")
    end
    if VEHICLEKEYS and VEHICLEKEYS.GetResourceName then
        return VEHICLEKEYS.GetResourceName()
    end
    return "unknown"
end

---@param vehicle number Vehicle entity handle
---@param plate? string Vehicle plate
function ALLGAMERS.GiveVehicleKeys(vehicle, plate)
    if config.Debug then
        DebugPrint("GiveVehicleKeys function called", "debug")
    end
    if VEHICLEKEYS and VEHICLEKEYS.GiveKeys then
        VEHICLEKEYS.GiveKeys(vehicle, plate)
    else
        if DoesEntityExist(vehicle) then
            SetVehicleDoorsLocked(vehicle, 1)
        end
    end
end

---@param vehicle number Vehicle entity handle
---@param plate? string Vehicle plate
function ALLGAMERS.RemoveVehicleKeys(vehicle, plate)
    if config.Debug then
        DebugPrint("RemoveVehicleKeys function called", "debug")
    end
    if VEHICLEKEYS and VEHICLEKEYS.RemoveKeys then
        VEHICLEKEYS.RemoveKeys(vehicle, plate)
    end
end

---@return boolean
function ALLGAMERS.IsVehicleKeysSystemAvailable()
    if config.Debug then
        DebugPrint("IsVehicleKeysSystemAvailable function called", "debug")
    end
    if VEHICLEKEYS and VEHICLEKEYS.IsAvailable then
        return VEHICLEKEYS.IsAvailable()
    end
    return false
end

function ALLGAMERS.CloseMenu()
    if config.Debug then
        DebugPrint("CloseMenu function called", "debug")
    end
    API.CloseMenu()
end

---@param metadata string Metadata key
---@return any metadata value
function ALLGAMERS.GetPlayerMetaData(metadata)
    if config.Debug then
        DebugPrint("GetPlayerMetaData function called with Metadata: " .. metadata, "debug")
    end
    return API.GetPlayerMetaData(metadata)
end

---@return boolean dead status
function ALLGAMERS.GetIsPlayerDead()
    if config.Debug then
        DebugPrint("GetIsPlayerDead function called", "debug")
    end
    return API.GetIsPlayerDead()
end

---@return string firstname, string lastname
function ALLGAMERS.GetPlayerName()
    if config.Debug then
        DebugPrint("GetPlayerName function called", "debug")
    end
    return API.GetPlayerName()
end

-- ============================================
-- TARGET SYSTEM FUNCTIONS
-- ============================================

---Toggle targeting system on/off
---@param disable boolean
function ALLGAMERS.DisableTargeting(disable)
    if config.Debug then
        DebugPrint("DisableTargeting function called with: " .. tostring(disable), "debug")
    end
    return TARGET.DisableTargeting(disable)
end

---Add target options to all players
---@param options table
function ALLGAMERS.AddGlobalPlayer(options)
    if config.Debug then
        DebugPrint("AddGlobalPlayer function called", "debug")
    end
    return TARGET.AddGlobalPlayer(options)
end

---Remove target options from all players
---@param optionNames string|table|nil
function ALLGAMERS.RemoveGlobalPlayer(optionNames)
    if config.Debug then
        DebugPrint("RemoveGlobalPlayer function called", "debug")
    end
    return TARGET.RemoveGlobalPlayer(optionNames)
end

---Add target options to all peds
---@param options table
function ALLGAMERS.AddGlobalPed(options)
    if config.Debug then
        DebugPrint("AddGlobalPed function called", "debug")
    end
    return TARGET.AddGlobalPed(options)
end

---Remove target options from all peds
---@param optionNames string|table|nil
function ALLGAMERS.RemoveGlobalPed(optionNames)
    if config.Debug then
        DebugPrint("RemoveGlobalPed function called", "debug")
    end
    return TARGET.RemoveGlobalPed(optionNames)
end

---Add target options to all vehicles
---@param options table
function ALLGAMERS.AddGlobalVehicle(options)
    if config.Debug then
        DebugPrint("AddGlobalVehicle function called", "debug")
    end
    return TARGET.AddGlobalVehicle(options)
end

---Remove target options from all vehicles
---@param optionNames string|table|nil
function ALLGAMERS.RemoveGlobalVehicle(optionNames)
    if config.Debug then
        DebugPrint("RemoveGlobalVehicle function called", "debug")
    end
    return TARGET.RemoveGlobalVehicle(optionNames)
end

---Add target to local entity
---@param entities number|table
---@param options table
function ALLGAMERS.AddLocalEntity(entities, options)
    if config.Debug then
        DebugPrint("AddLocalEntity function called", "debug")
    end
    return TARGET.AddLocalEntity(entities, options)
end

---Remove target from local entity
---@param entities number|table
---@param labels string|table|nil
function ALLGAMERS.RemoveLocalEntity(entities, labels)
    if config.Debug then
        DebugPrint("RemoveLocalEntity function called", "debug")
    end
    return TARGET.RemoveLocalEntity(entities, labels)
end

---Add target to networked entity
---@param netids number|table
---@param options table
function ALLGAMERS.AddNetworkedEntity(netids, options)
    if config.Debug then
        DebugPrint("AddNetworkedEntity function called", "debug")
    end
    return TARGET.AddNetworkedEntity(netids, options)
end

---Remove target from networked entity
---@param netids number|table
---@param labels string|table|nil
function ALLGAMERS.RemoveNetworkedEntity(netids, labels)
    if config.Debug then
        DebugPrint("RemoveNetworkedEntity function called", "debug")
    end
    return TARGET.RemoveNetworkedEntity(netids, labels)
end

---Add target to model
---@param models number|table
---@param options table
function ALLGAMERS.AddModel(models, options)
    if config.Debug then
        DebugPrint("AddModel function called", "debug")
    end
    return TARGET.AddModel(models, options)
end

---Remove target from model
---@param models number|table
---@param labels string|table|nil
function ALLGAMERS.RemoveModel(models, labels)
    if config.Debug then
        DebugPrint("RemoveModel function called", "debug")
    end
    return TARGET.RemoveModel(models, labels)
end

---Add box zone target
---@param name string
---@param coords vector3
---@param size vector3
---@param heading number
---@param options table
---@param debug boolean|nil
function ALLGAMERS.AddBoxZone(name, coords, size, heading, options, debug)
    if config.Debug then
        DebugPrint("AddBoxZone function called with name: " .. name, "debug")
    end
    return TARGET.AddBoxZone(name, coords, size, heading, options, debug)
end

---Add sphere/circle zone target
---@param name string
---@param coords vector3
---@param radius number
---@param options table
---@param debug boolean|nil
function ALLGAMERS.AddSphereZone(name, coords, radius, options, debug)
    if config.Debug then
        DebugPrint("AddSphereZone function called with name: " .. name, "debug")
    end
    return TARGET.AddSphereZone(name, coords, radius, options, debug)
end

---Remove zone by name
---@param name string
function ALLGAMERS.RemoveZone(name)
    if config.Debug then
        DebugPrint("RemoveZone function called with name: " .. name, "debug")
    end
    return TARGET.RemoveZone(name)
end

---Get current target system name
---@return string|nil
function ALLGAMERS.GetTargetResourceName()
    return TARGET.GetResourceName()
end

-- ============================================
-- TEXTUI SYSTEM FUNCTIONS
-- ============================================

---Show help text on screen
---@param message string
---@param position string|nil
function ALLGAMERS.ShowHelpText(message, position)
    if config.Debug then
        DebugPrint("ShowHelpText function called with message: " .. message, "debug")
    end
    return TEXTUI.ShowHelpText(message, position)
end

---Hide help text from screen
function ALLGAMERS.HideHelpText()
    if config.Debug then
        DebugPrint("HideHelpText function called", "debug")
    end
    return TEXTUI.HideHelpText()
end

---Show advanced textui with icon
---@param options table
function ALLGAMERS.ShowAdvancedText(options)
    if config.Debug then
        DebugPrint("ShowAdvancedText function called", "debug")
    end
    return TEXTUI.ShowAdvancedText(options)
end

---Update textui message
---@param message string
function ALLGAMERS.UpdateText(message)
    if config.Debug then
        DebugPrint("UpdateText function called with message: " .. message, "debug")
    end
    return TEXTUI.UpdateText(message)
end

---Check if textui is showing
---@return boolean
function ALLGAMERS.IsTextUIShowing()
    return TEXTUI.IsShowing()
end

---Get current TextUI system name
---@return string
function ALLGAMERS.GetTextUIResourceName()
    return TEXTUI.GetResourceName()
end

---Show key-based help text
---@param key string
---@param message string
function ALLGAMERS.ShowKeyHelp(key, message)
    if config.Debug then
        DebugPrint("ShowKeyHelp function called with key: " .. key, "debug")
    end
    return TEXTUI.ShowKeyHelp(key, message)
end

---Draw 3D text at coords
---@param coords vector3
---@param text string
---@param scale number|nil
function ALLGAMERS.Draw3DText(coords, text, scale)
    return TEXTUI.Draw3DText(coords, text, scale)
end

-- ============================================
-- PROGRESS BAR SYSTEM FUNCTIONS
-- ============================================

---Show progress bar
---@param options table
---@param callback function|nil
---@param isQBFormat boolean|nil
function ALLGAMERS.ShowProgress(options, callback, isQBFormat)
    if config.Debug then
        DebugPrint("ShowProgress function called", "debug")
    end
    return PROGRESSBAR.ShowProgress(options, callback, isQBFormat)
end

---Get current progress bar system name
---@return string|nil
function ALLGAMERS.GetProgressBarResourceName()
    return PROGRESSBAR.GetResourceName()
end


exports("GetPlayerData", function()
    return ALLGAMERS.GetPlayerData()
end)

exports("IsPlayerLoaded", function()
    return ALLGAMERS.IsPlayerLoaded()
end)

exports("SetPlayerData", function(key, value)
    ALLGAMERS.SetPlayerData(key, value)
end)

exports("OpenInventory", function()
    ALLGAMERS.OpenInventory()
end)

exports("ShowNotification", function(text)
    ALLGAMERS.ShowNotification(text)
end)

exports("Dispatch", function(code, title, message, blip, jobs, important)
    ALLGAMERS.Dispatch(code, title, message, blip, jobs, important)
end)

exports("GetJob", function()
    return ALLGAMERS.GetJob()
end)

exports("GetJobGrade", function()
    return ALLGAMERS.GetJobGrade()
end)

exports("GetJobInfo", function()
    return ALLGAMERS.GetJobInfo()
end)

exports("HasItem", function(item_name)
    return ALLGAMERS.HasItem(item_name)
end)

exports("GetInventory", function()
    return ALLGAMERS.GetInventory()
end)

exports("GetItemInfo", function(item)
    return ALLGAMERS.GetItemInfo(item)
end)

exports("Items", function()
    return ALLGAMERS.GetAllItems()
end)

exports("CloseMenu", function()
    return ALLGAMERS.CloseMenu()
end)

exports("GetPlayerMetaData", function(metadata)
    return ALLGAMERS.GetPlayerMetaData(metadata)
end)

exports("GetIsPlayerDead", function()
    return ALLGAMERS.GetIsPlayerDead()
end)

exports("GetPlayerName", function()
    return ALLGAMERS.GetPlayerName()
end)

exports("GetALLGAMERS", function()
    return ALLGAMERS
end)

-- ============================================
-- TARGET EXPORTS
-- ============================================

exports("DisableTargeting", function(disable)
    return ALLGAMERS.DisableTargeting(disable)
end)

exports("AddGlobalPlayer", function(options)
    return ALLGAMERS.AddGlobalPlayer(options)
end)

exports("RemoveGlobalPlayer", function(optionNames)
    return ALLGAMERS.RemoveGlobalPlayer(optionNames)
end)

exports("AddGlobalPed", function(options)
    return ALLGAMERS.AddGlobalPed(options)
end)

exports("RemoveGlobalPed", function(optionNames)
    return ALLGAMERS.RemoveGlobalPed(optionNames)
end)

exports("AddGlobalVehicle", function(options)
    return ALLGAMERS.AddGlobalVehicle(options)
end)

exports("RemoveGlobalVehicle", function(optionNames)
    return ALLGAMERS.RemoveGlobalVehicle(optionNames)
end)

exports("AddLocalEntity", function(entities, options)
    return ALLGAMERS.AddLocalEntity(entities, options)
end)

exports("RemoveLocalEntity", function(entities, labels)
    return ALLGAMERS.RemoveLocalEntity(entities, labels)
end)

exports("AddNetworkedEntity", function(netids, options)
    return ALLGAMERS.AddNetworkedEntity(netids, options)
end)

exports("RemoveNetworkedEntity", function(netids, labels)
    return ALLGAMERS.RemoveNetworkedEntity(netids, labels)
end)

exports("AddModel", function(models, options)
    return ALLGAMERS.AddModel(models, options)
end)

exports("RemoveModel", function(models, labels)
    return ALLGAMERS.RemoveModel(models, labels)
end)

exports("AddBoxZone", function(name, coords, size, heading, options, debug)
    return ALLGAMERS.AddBoxZone(name, coords, size, heading, options, debug)
end)

exports("AddSphereZone", function(name, coords, radius, options, debug)
    return ALLGAMERS.AddSphereZone(name, coords, radius, options, debug)
end)

exports("RemoveZone", function(name)
    return ALLGAMERS.RemoveZone(name)
end)

exports("GetTargetResourceName", function()
    return ALLGAMERS.GetTargetResourceName()
end)

-- ============================================
-- TEXTUI EXPORTS
-- ============================================

exports("ShowHelpText", function(message, position)
    return ALLGAMERS.ShowHelpText(message, position)
end)

exports("HideHelpText", function()
    return ALLGAMERS.HideHelpText()
end)

exports("ShowAdvancedText", function(options)
    return ALLGAMERS.ShowAdvancedText(options)
end)

exports("UpdateText", function(message)
    return ALLGAMERS.UpdateText(message)
end)

exports("IsTextUIShowing", function()
    return ALLGAMERS.IsTextUIShowing()
end)

exports("GetTextUIResourceName", function()
    return ALLGAMERS.GetTextUIResourceName()
end)

exports("ShowKeyHelp", function(key, message)
    return ALLGAMERS.ShowKeyHelp(key, message)
end)

exports("Draw3DText", function(coords, text, scale)
    return ALLGAMERS.Draw3DText(coords, text, scale)
end)

-- ============================================
-- PROGRESS BAR EXPORTS
-- ============================================

exports("ShowProgress", function(options, callback, isQBFormat)
    return ALLGAMERS.ShowProgress(options, callback, isQBFormat)
end)

exports("GetProgressBarResourceName", function()
    return ALLGAMERS.GetProgressBarResourceName()
end)

-- ============================================
-- FUEL EXPORTS
-- ============================================

exports("GetFuelResourceName", function()
    return ALLGAMERS.GetFuelResourceName()
end)

exports("GetFuel", function(vehicle)
    return ALLGAMERS.GetFuel(vehicle)
end)

exports("SetFuel", function(vehicle, fuel, fuelType)
    ALLGAMERS.SetFuel(vehicle, fuel, fuelType)
end)

exports("IsFuelSystemAvailable", function()
    return ALLGAMERS.IsFuelSystemAvailable()
end)

exports("GetFuelCapacity", function(vehicle)
    return ALLGAMERS.GetFuelCapacity(vehicle)
end)

exports("NeedsFuel", function(vehicle, threshold)
    return ALLGAMERS.NeedsFuel(vehicle, threshold)
end)

exports("Refuel", function(vehicle, fuelType)
    ALLGAMERS.Refuel(vehicle, fuelType)
end)

-- ============================================
-- VEHICLE KEYS EXPORTS
-- ============================================

exports("GetVehicleKeysResourceName", function()
    return ALLGAMERS.GetVehicleKeysResourceName()
end)

exports("GiveVehicleKeys", function(vehicle, plate)
    ALLGAMERS.GiveVehicleKeys(vehicle, plate)
end)

exports("RemoveVehicleKeys", function(vehicle, plate)
    ALLGAMERS.RemoveVehicleKeys(vehicle, plate)
end)

exports("IsVehicleKeysSystemAvailable", function()
    return ALLGAMERS.IsVehicleKeysSystemAvailable()
end)

-- Player loaded event handler (similar to community_bridge)
local playerLoaded = false
AddEventHandler('allgamers_bridge:Client:OnPlayerLoaded', function()
    if playerLoaded then return end
    playerLoaded = true

    if config.Debug then
        DebugPrint("Player loaded via AllGamers Bridge", "success")
    end
end)