---@diagnostic disable: duplicate-set-field
if GetResourceState('renewed-banking') == 'missing' then return end
ALLGAMERS_Banking = ALLGAMERS_Banking or {}

local renewed_banking = exports['renewed-banking']

ALLGAMERS_Banking.GetSystemName = function()
    return 'renewed-banking'
end

ALLGAMERS_Banking.GetResourceName = function()
    return 'renewed-banking'
end

ALLGAMERS_Banking.GetAccountBalance = function(account)
    return renewed_banking:GetAccountBalance(account)
end

ALLGAMERS_Banking.AddAccountFunds = function(account, amount, reason)
    return renewed_banking:AddMoney(account, amount, reason)
end

ALLGAMERS_Banking.RemoveAccountFunds = function(account, amount, reason)
    return renewed_banking:RemoveMoney(account, amount, reason)
end

return ALLGAMERS_Banking
