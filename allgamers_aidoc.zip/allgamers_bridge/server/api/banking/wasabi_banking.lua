---@diagnostic disable: duplicate-set-field
if GetResourceState('wasabi_banking') == 'missing' then return end
ALLGAMERS_Banking = ALLGAMERS_Banking or {}

local wasabi_banking = exports['wasabi_banking']

ALLGAMERS_Banking.GetSystemName = function()
    return 'wasabi_banking'
end

ALLGAMERS_Banking.GetResourceName = function()
    return 'wasabi_banking'
end

ALLGAMERS_Banking.GetAccountBalance = function(account)
    local balance = wasabi_banking:GetAccountBalance(account, 'society')
    return balance or 0
end

ALLGAMERS_Banking.AddAccountFunds = function(account, amount, reason)
    return wasabi_banking:AddMoney('society', account, amount)
end

ALLGAMERS_Banking.RemoveAccountFunds = function(account, amount, reason)
    return wasabi_banking:RemoveMoney('society', account, amount)
end

return ALLGAMERS_Banking
