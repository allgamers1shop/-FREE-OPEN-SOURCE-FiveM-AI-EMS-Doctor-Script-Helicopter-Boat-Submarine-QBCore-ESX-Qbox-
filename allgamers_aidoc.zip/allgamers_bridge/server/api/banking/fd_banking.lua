---@diagnostic disable: duplicate-set-field
if GetResourceState('fd_banking') == 'missing' then return end
ALLGAMERS_Banking = ALLGAMERS_Banking or {}

local fd_banking = exports['fd_banking']

ALLGAMERS_Banking.GetSystemName = function()
    return 'fd_banking'
end

ALLGAMERS_Banking.GetResourceName = function()
    return 'fd_banking'
end

ALLGAMERS_Banking.GetAccountBalance = function(account)
    return fd_banking:GetAccount(account)
end

ALLGAMERS_Banking.AddAccountFunds = function(account, amount, reason)
    return fd_banking:AddMoney(account, amount, reason)
end

ALLGAMERS_Banking.RemoveAccountFunds = function(account, amount, reason)
    return fd_banking:RemoveMoney(account, amount, reason)
end

return ALLGAMERS_Banking
