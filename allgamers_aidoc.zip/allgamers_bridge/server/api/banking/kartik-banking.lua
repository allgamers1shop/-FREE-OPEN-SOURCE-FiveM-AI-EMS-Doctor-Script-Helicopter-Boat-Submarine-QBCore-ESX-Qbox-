---@diagnostic disable: duplicate-set-field
if GetResourceState('kartik-banking') == 'missing' then return end
ALLGAMERS_Banking = ALLGAMERS_Banking or {}

local kartik = exports['kartik-banking']

ALLGAMERS_Banking.GetSystemName = function()
    return 'kartik-banking'
end

ALLGAMERS_Banking.GetResourceName = function()
    return 'kartik-banking'
end

ALLGAMERS_Banking.GetAccountBalance = function(account)
    local balance = kartik:GetAccountMoney(account)
    return balance or 0
end

ALLGAMERS_Banking.AddAccountFunds = function(account, amount, reason)
    return kartik:AddAccountMoney(account, amount, reason)
end

ALLGAMERS_Banking.RemoveAccountFunds = function(account, amount, reason)
    return kartik:RemoveAccountMoney(account, amount, reason)
end

return ALLGAMERS_Banking
