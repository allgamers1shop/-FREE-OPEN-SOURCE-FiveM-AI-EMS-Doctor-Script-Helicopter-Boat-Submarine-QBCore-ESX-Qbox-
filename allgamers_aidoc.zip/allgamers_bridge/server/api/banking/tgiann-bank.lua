---@diagnostic disable: duplicate-set-field
if GetResourceState('tgiann-bank') == 'missing' then return end
ALLGAMERS_Banking = ALLGAMERS_Banking or {}

local tgiann = exports["tgiann-bank"]

ALLGAMERS_Banking.GetSystemName = function()
    return 'tgiann-bank'
end

ALLGAMERS_Banking.GetResourceName = function()
    return 'tgiann-bank'
end

ALLGAMERS_Banking.GetAccountBalance = function(account)
    return tgiann:GetJobAccountBalance(account)
end

ALLGAMERS_Banking.AddAccountFunds = function(account, amount, _)
    return tgiann:AddJobMoney(account, amount)
end

ALLGAMERS_Banking.RemoveAccountFunds = function(account, amount, _)
    return tgiann:RemoveJobMoney(account, amount)
end

return ALLGAMERS_Banking
