---@diagnostic disable: duplicate-set-field
if GetResourceState('p_banking') == 'missing' then return end
ALLGAMERS_Banking = ALLGAMERS_Banking or {}

local p_banking = exports['p_banking']

ALLGAMERS_Banking.GetSystemName = function()
    return 'p_banking'
end

ALLGAMERS_Banking.GetResourceName = function()
    return 'p_banking'
end

ALLGAMERS_Banking.GetAccountBalance = function(account)
    return p_banking:getAccountMoney(account) or 0
end

ALLGAMERS_Banking.AddAccountFunds = function(account, amount, _)
    return p_banking:addAccountMoney(account, amount)
end

ALLGAMERS_Banking.RemoveAccountFunds = function(account, amount, _)
    return p_banking:removeAccountMoney(account, amount)
end

return ALLGAMERS_Banking
