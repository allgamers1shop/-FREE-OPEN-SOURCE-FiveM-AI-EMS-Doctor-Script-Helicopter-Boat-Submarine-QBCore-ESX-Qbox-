---@diagnostic disable: duplicate-set-field
if GetResourceState('okokBanking') == 'missing' then return end
ALLGAMERS_Banking = ALLGAMERS_Banking or {}

local okokBanking = exports['okokBanking']

ALLGAMERS_Banking.GetSystemName = function()
    return 'okokBanking'
end

ALLGAMERS_Banking.GetResourceName = function()
    return 'okokBanking'
end

ALLGAMERS_Banking.GetAccountBalance = function(account)
    return okokBanking:GetAccount(account)
end

ALLGAMERS_Banking.AddAccountFunds = function(account, amount, _)
    return okokBanking:AddMoney(account, amount)
end

ALLGAMERS_Banking.RemoveAccountFunds = function(account, amount, _)
    return okokBanking:RemoveMoney(account, amount)
end

return ALLGAMERS_Banking
