---@diagnostic disable: duplicate-set-field
ALLGAMERS_Banking = ALLGAMERS_Banking or {}

ALLGAMERS_Banking.GetSystemName = function()
    return 'default'
end

ALLGAMERS_Banking.GetResourceName = function()
    return 'default'
end

ALLGAMERS_Banking.GetAccountBalance = function(account)
    return 0, print("The resource you are using does not support this function.")
end

ALLGAMERS_Banking.AddAccountFunds = function(account, amount, reason)
    return false, print("The resource you are using does not support this function.")
end

ALLGAMERS_Banking.RemoveAccountFunds = function(account, amount, reason)
    return false, print("The resource you are using does not support this function.")
end

return ALLGAMERS_Banking
