---@diagnostic disable: duplicate-set-field
if GetResourceState('qs-banking') == 'missing' then return end
ALLGAMERS_Banking = ALLGAMERS_Banking or {}

local qsBanking = exports['qs-banking']

ALLGAMERS_Banking.GetSystemName = function()
    return 'qs-banking'
end

ALLGAMERS_Banking.GetResourceName = function()
    return 'qs-banking'
end

ALLGAMERS_Banking.GetAccountBalance = function(account)
    return qsBanking:GetAccountBalance(account)
end

ALLGAMERS_Banking.AddAccountFunds = function(account, amount, reason)
    return qsBanking:AddMoney(account, amount, reason)
end

ALLGAMERS_Banking.RemoveAccountFunds = function(account, amount, reason)
    return qsBanking:RemoveMoney(account, amount, reason)
end

return ALLGAMERS_Banking
