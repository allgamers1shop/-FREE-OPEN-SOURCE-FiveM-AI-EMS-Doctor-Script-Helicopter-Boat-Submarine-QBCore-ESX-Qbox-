---@diagnostic disable: duplicate-set-field
if GetResourceState('qb-banking') == 'missing' then return end
ALLGAMERS_Banking = ALLGAMERS_Banking or {}

local qbBanking = exports['qb-banking']

ALLGAMERS_Banking.GetSystemName = function()
    return 'qb-banking'
end

ALLGAMERS_Banking.GetResourceName = function()
    return 'qb-banking'
end

ALLGAMERS_Banking.GetAccountBalance = function(account)
    return qbBanking:GetAccountBalance(account)
end

ALLGAMERS_Banking.AddAccountFunds = function(account, amount, reason)
    return qbBanking:AddMoney(account, amount, reason)
end

ALLGAMERS_Banking.RemoveAccountFunds = function(account, amount, reason)
    return qbBanking:RemoveMoney(account, amount, reason)
end

return ALLGAMERS_Banking
