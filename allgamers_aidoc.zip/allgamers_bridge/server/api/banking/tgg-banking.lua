---@diagnostic disable: duplicate-set-field
if GetResourceState('tgg-banking') == 'missing' then return end
ALLGAMERS_Banking = ALLGAMERS_Banking or {}

local tgg = exports['tgg-banking']

ALLGAMERS_Banking.GetSystemName = function()
    return 'tgg-banking'
end

ALLGAMERS_Banking.GetResourceName = function()
    return 'tgg-banking'
end

ALLGAMERS_Banking.GetAccountBalance = function(account)
    return tgg:GetSocietyAccountMoney(account) or 0
end

ALLGAMERS_Banking.AddAccountFunds = function(account, amount, _)
    return tgg:AddSocietyMoney(account, amount)
end

ALLGAMERS_Banking.RemoveAccountFunds = function(account, amount, _)
    return tgg:RemoveSocietyMoney(account, amount)
end

return ALLGAMERS_Banking
