if GetResourceState('es_extended') ~= 'started' then return end

local ESX = exports['es_extended']:getSharedObject()
local ALLGAMERS = {}

function ALLGAMERS.GetPlayer(id)
    return ESX.GetPlayerFromId(id)
end

function ALLGAMERS.GetAllPlayers()
    local raw = ESX.GetPlayers()
    local result = {}
    for i = 1, #raw do
        local id = raw[i]
        local num = (type(id) == "number") and id or tonumber(id)
        if num then
            result[#result + 1] = num
        end
    end
    return result
end

function ALLGAMERS.GetPlayerJob(id)
    local x = ALLGAMERS.GetPlayer(id); if not x then return nil,nil,nil,nil end
    local j = x.getJob()
    return j.name, j.label, j.grade_label, j.grade
end

function ALLGAMERS.GetPlayerJobGrade(id)
    local x = ALLGAMERS.GetPlayer(id); if not x then return 0 end
    return x.getJob().grade
end

function ALLGAMERS.GetPlayerJobInfo(id)
    local x = ALLGAMERS.GetPlayer(id)
    if not x then return {} end
    local job = x.getJob()
    local isBoss = (job.grade_name == "boss")
    return {
        jobName = job.name,
        jobLabel = job.label,
        gradeName = job.grade_name,
        gradeLabel = job.grade_label,
        gradeRank = job.grade,
        boss = isBoss,
        onDuty = job.onDuty or false
    }
end

function ALLGAMERS.GetPlayerGang(id)
    return nil, nil, nil, nil
end

function ALLGAMERS.GetPlayerGangInfo(id)
    return {}
end

function ALLGAMERS.HasPermission(id)
    local x = ALLGAMERS.GetPlayer(id)
    return config.AdminGroups[x.getGroup()]
end

function ALLGAMERS.AddMoney(id, amt, reason)
    local x = ALLGAMERS.GetPlayer(id); if not x then return false end
    if reason then
        x.addMoney(amt, reason)
    else
        x.addMoney(amt)
    end
    return true
end

function ALLGAMERS.RemoveMoney(id, amt, reason)
    local x = ALLGAMERS.GetPlayer(id); if not x then return false end
    if reason then
        x.removeMoney(amt, reason)
    else
        x.removeMoney(amt)
    end
    return true
end

function ALLGAMERS.RemoveBankMoney(id, amt, reason)
    local x = ALLGAMERS.GetPlayer(id); if not x then return false end
    if reason then
        x.removeAccountMoney("bank", amt, reason)
    else
        x.removeAccountMoney("bank", amt)
    end
    return true
end

function ALLGAMERS.AddBankMoney(id, amt, reason)
    local x = ALLGAMERS.GetPlayer(id); if not x then return false end
    if reason then
        x.addAccountMoney("bank", amt, reason)
    else
        x.addAccountMoney("bank", amt)
    end
    return true
end

function ALLGAMERS.GetMoney(id)
    local x = ALLGAMERS.GetPlayer(id)
    return x and x.getMoney() or 0
end

function ALLGAMERS.GetBankMoney(id)
    local x = ALLGAMERS.GetPlayer(id)
    return x and x.getAccount("bank").money or 0
end

function ALLGAMERS.TransferMoney(from, to, amount)
    local xFrom = ALLGAMERS.GetPlayer(from)
    local xTo   = ALLGAMERS.GetPlayer(to)
    if not xFrom or not xTo then return false, "Player not found" end
    if xFrom.getAccount("bank").money >= amount then
        xFrom.removeAccountMoney("bank", amount)
        xTo.addAccountMoney("bank", amount)
        return true, "Success"
    else
        return false, "Not enough money in sender's account"
    end
end

function ALLGAMERS.SetJob(id, job, grade)
    local x = ALLGAMERS.GetPlayer(id); if not x then return false end
    x.setJob(job, grade); return true
end

function ALLGAMERS.GetIdentifier(id)
    local x = ALLGAMERS.GetPlayer(id)
    return x and x.getIdentifier() or nil
end

function ALLGAMERS.GetPlayerByCitizenId(cid)
    for _, playerId in ipairs(ESX.GetPlayers()) do
        local xPlayer = ESX.GetPlayerFromId(playerId)
        if xPlayer and xPlayer.getIdentifier and xPlayer.getIdentifier() == cid then
            return xPlayer
        end
    end
    return nil
end

function ALLGAMERS.GetPlayerName(id)
    local xPlayer = ALLGAMERS.GetPlayer(id)
    if not xPlayer then return "", "" end
    local firstName = xPlayer.firstName or xPlayer.firstname or ""
    local lastName  = xPlayer.lastName  or xPlayer.lastname  or ""
    if (firstName == "" and lastName == "") and xPlayer.getName then
        local full = xPlayer.getName() or ""
        local fn, ln = full:match("^(%S+)%s*(.*)$")
        firstName = fn or full
        lastName  = ln or ""
    end
    return tostring(firstName), tostring(lastName)
end

function ALLGAMERS.GetPlayerCoords(id)
    local ped = GetPlayerPed(id)
    if not ped or ped == 0 then
        return vector3(0.0, 0.0, 0.0)
    end
    return GetEntityCoords(ped)
end

function ALLGAMERS.GetPlayerMetadata(id, metadata)
    local x = ALLGAMERS.GetPlayer(id)
    if not x then return false end
    return x.getMeta(metadata) or false
end

function ALLGAMERS.SetPlayerMetadata(id, metadata, value)
    local x = ALLGAMERS.GetPlayer(id)
    if not x then return false end
    if x.setMeta then
        x.setMeta(metadata, value)
        return true
    else
        x.set(metadata, value)
        return true
    end
end

function ALLGAMERS.GetPlayerDuty(id)
    local x = ALLGAMERS.GetPlayer(id)
    if not x then return false end
    local job = x.getJob()
    if not job.onDuty then return false end
    return true
end

function ALLGAMERS.GetIsPlayerDead(id)
    -- Modern ESX Legacy uses esx_death state bags / export
    if GetResourceState('esx_death') == 'started' then
        local ok, dead = pcall(function()
            return exports.esx_death:IsDead(id)
        end)
        if ok then
            return dead == true
        end
    end

    local state = Player(id) and Player(id).state
    if state and state.isDead == true then
        return true
    end

    local x = ALLGAMERS.GetPlayer(id)
    if not x then return false end
    return x.get("is_dead") or false
end

function ALLGAMERS.RevivePlayer(id)
    -- esx_ambulancejob:revive is a SERVER medic event (duty/nearby/medikit checks).
    -- On current ESX Legacy, actual revive is exports.esx_death:Revive.
    if GetResourceState('esx_death') == 'started' then
        local ok, revived = pcall(function()
            return exports.esx_death:Revive(id, 'allgamers')
        end)
        if ok then
            return revived == true
        end
        return false
    end

    -- Older ambulancejob setups that still expose a client revive event
    TriggerClientEvent('esx_ambulancejob:revive', id)
    return true
end

function ALLGAMERS.RegisterUsableItem(itemName, cb)
    local func = function(src, item, itemData)
        itemData = itemData or item
        itemData.metadata = itemData.metadata or itemData.info or {}
        itemData.slot = itemData.id or itemData.slot
        cb(src, itemData)
    end
    ESX.RegisterUsableItem(itemName, func)
    return true
end

return ALLGAMERS