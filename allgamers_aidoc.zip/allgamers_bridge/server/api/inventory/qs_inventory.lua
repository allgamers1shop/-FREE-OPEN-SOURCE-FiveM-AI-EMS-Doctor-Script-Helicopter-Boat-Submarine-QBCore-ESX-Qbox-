---@diagnostic disable: duplicate-set-field
if GetResourceState('qs-inventory') == 'missing' then return end

local QsInventoryAPI = {}

local invExport
local inventoryStorage = {}
local isInitialized = false

local function initializeQsInventory()
    if isInitialized then return true end
    if GetResourceState('qs-inventory') ~= 'started' then
        DebugPrint("Tgiann-Inventory resource is not started", "error")
        return false
    end

    invExport = exports['qs-inventory']
    if not invExport then
        DebugPrint("Failed to get qs-inventory export", "error")
        return false
    end

    if config.Debug then
        DebugPrint("QS-Inventory initialized successfully", "success")
    end
    isInitialized = true
    return true
end

local function validateOperation(src, item, count, operation)
    if not src or not item then
        DebugPrint(string.format("%s: Invalid parameters", operation), "error")
        return false
    end
    return true
end

QsInventoryAPI.GetResourceName = function()
    return "qs-inventory"
end

QsInventoryAPI.AddItem = function(src, item, count, slot, metadata)
    if not initializeQsInventory() then return false end
    if not validateOperation(src, item, count, "AddItem") then return false end

    count = count or 1
    local success = invExport:AddItem(src, item, count, slot, metadata)
    if success then
        TriggerClientEvent('allgamers_bridge:client:inventory:update', src, {
            action = "add", item = item, count = count, slot = slot, metadata = metadata
        })
    end
    return success
end

QsInventoryAPI.RemoveItem = function(src, item, count, slot, metadata)
    if not initializeQsInventory() then return false end
    if not validateOperation(src, item, count, "RemoveItem") then return false end

    count = count or 1
    local success = invExport:RemoveItem(src, item, count, slot, metadata)
    if success then
        TriggerClientEvent('allgamers_bridge:client:inventory:update', src, {
            action = "remove", item = item, count = count, slot = slot, metadata = metadata
        })
    end
    return success
end

QsInventoryAPI.HasItem = function(src, item, requiredCount)
    if not initializeQsInventory() then return false end
    if not src or not item then return false end
    requiredCount = requiredCount or 1
    local count = invExport:GetItemTotalAmount(src, item)
    if not count then return false end
    return count >= requiredCount
end

QsInventoryAPI.CanCarryItem = function(src, item, count)
    if not src or not item or not count then return false end
    if invExport and invExport.CanCarryItem then
        return invExport:CanCarryItem(src, item, count)
    end
    return true
end

QsInventoryAPI.GetItemInfo = function(item)
    if not initializeQsInventory() then return nil end
    if not item then return {} end

    local itemsData = invExport:GetItemList()
    if not itemsData then return {} end
    local itemData = itemsData[item]
    if not itemData then return {} end
    return {
        name = itemData.name or "Missing Name",
        label = itemData.label or "Missing Label",
        stack = itemData.unique or "false",
        weight = itemData.weight or "0",
        description = itemData.description or "none",
        image = QsInventoryAPI.GetImagePath(item),
    }
end

QsInventoryAPI.Items = function()
    if not initializeQsInventory() then return {} end
    return invExport:GetItemList()
end

QsInventoryAPI.GetItemCount = function(src, item, metadata)
    if not initializeQsInventory() then return 0 end
    if not src or not item then return 0 end
    if metadata then
        DebugPrint("qs-inventory does not support metadata searching for item counts, using inventory iteration", "warning")
        local Player = Framework.Functions.GetPlayer(src)
        if not Player then return 0 end
        local total = 0
        if Player.PlayerData and Player.PlayerData.items then
            for _, it in pairs(Player.PlayerData.items) do
                if it and it.name == item then
                    if not metadata or (it.info and Bridge.Tables.DeepEquals(it.info, metadata)) then
                        total = total + (it.amount or 0)
                    end
                end
            end
        end
        return total
    end
    return invExport:GetItemTotalAmount(src, item) or 0
end

QsInventoryAPI.GetPlayerInventory = function(src)
    if not initializeQsInventory() then return {} end
    if not src then return {} end
    if invExport.GetInventory then
        local playerItems = invExport:GetInventory(src)
        local repackedTable = {}
        for _, v in pairs(playerItems) do
            table.insert(repackedTable, {
                name = v.name,
                count = v.amount or v.count,
                metadata = v.info or v.metadata or {},
                slot = v.slot,
            })
        end
        return repackedTable
    end
    return {}
end

QsInventoryAPI.GetItemBySlot = function(src, slot)
    if not src or not slot then return {} end
    if invExport.GetInventory then
        local playerItems = invExport:GetInventory(src)
        for _, item in pairs(playerItems) do
            if item.slot == slot then
                return {
                    name = item.name,
                    label = item.label,
                    weight = item.weight,
                    slot = slot,
                    count = item.amount or item.count,
                    metadata = item.info or item.metadata or {},
                    stack = item.unique or item.stack or false,
                    description = item.description
                }
            end
        end
    end
    return {}
end

QsInventoryAPI.SetMetadata = function(src, item, slot, metadata)
    if not src or not item or not slot or not metadata then return false end
    if invExport.SetMetadata then
        invExport:SetMetadata(src, slot, metadata)
        return true
    end
    return false
end

QsInventoryAPI.GetImagePath = function(item)
    if not item then return "" end
    item = QsInventoryAPI.StripImageExtension(item)
    local file = LoadResourceFile("qs-inventory", string.format("html/images/%s.png", item))
    local imagePath = file and string.format("nui://qs-inventory/html/images/%s.png", item)
    return imagePath or "https://raw.githubusercontent.com/AllGamers-Scripts/allgamers-assets/main/inventory-placeholder.png"
end

QsInventoryAPI.StripImageExtension = function(item)
    if not item then return "" end
    return item:gsub("%.png$", ""):gsub("%.jpg$", ""):gsub("%.jpeg$", ""):gsub("%.webp$", "")
end

QsInventoryAPI.OpenStash = function(src, stashType, stashId)
    if not src or not stashId then return false end
    if invExport.OpenStash then
        invExport:OpenStash(src, stashId)
        return true
    end
    return false
end

QsInventoryAPI.RegisterStash = function(stashId, label, slots, weight, owner, groups, coords)
    if not stashId then return false end
    inventoryStorage[stashId] = {id = stashId, label = label or stashId, slots = slots or 30, weight = weight or 50000}
    if config.Debug then DebugPrint(string.format("Registered QS stash: %s", stashId), "info") end
    return true
end

QsInventoryAPI.AddStashItems = function(stashId, items)
    DebugPrint("AddStashItems not implemented for QS-Inventory", "warning")
    return false
end

QsInventoryAPI.RemoveStashItems = function(stashId, items)
    DebugPrint("RemoveStashItems not implemented for QS-Inventory", "warning")
    return false
end

QsInventoryAPI.ClearStash = function(stashId, stashType)
    if inventoryStorage[stashId] then
        inventoryStorage[stashId] = nil
        if config.Debug then DebugPrint(string.format("Cleared QS stash: %s", stashId), "info") end
    end
    return true
end

QsInventoryAPI.AddTrunkItems = function(vehiclePlate, items)
    DebugPrint("AddTrunkItems not implemented for QS-Inventory", "warning")
    return false
end

QsInventoryAPI.OpenShop = function(src, shopId)
    if not src or not shopId then return false end
    if invExport.OpenShop then
        invExport:OpenShop(src, shopId)
        return true
    end
    return false
end

QsInventoryAPI.RegisterShop = function(shopId, inventory, coords, groups)
    if not shopId or not inventory then return false end
    DebugPrint("RegisterShop not implemented for QS-Inventory", "warning")
    return false
end

QsInventoryAPI.UpdatePlate = function(oldPlate, newPlate)
    DebugPrint("UpdatePlate not implemented for QS-Inventory", "warning")
    return false
end

QsInventoryAPI.OpenPlayerInventory = function(src, targetSrc)
    if not src or not targetSrc then return false end
    if invExport.OpenPlayerInventory then
        invExport:OpenPlayerInventory(src, targetSrc)
        return true
    end
    return false
end

return QsInventoryAPI
