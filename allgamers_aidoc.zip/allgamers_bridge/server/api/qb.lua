if GetResourceState('qb-core') ~= 'started' then return end

local QBCore = exports['qb-core']:GetCoreObject()
local ALLGAMERS = {}

local GetPlayer = QBCore.Functions.GetPlayer
local GetPlayers = QBCore.Functions.GetPlayers

function ALLGAMERS.GetPlayer(id)
    return GetPlayer(id)
end

function ALLGAMERS.GetAllPlayers()
    return GetPlayers()
end

function ALLGAMERS.GetPlayerJob(id)
    local p = GetPlayer(id); if not p then return nil,nil,nil,nil end
    local j = p.PlayerData.job
    return j.name, j.label, j.grade and j.grade.name, j.grade and j.grade.level
end

function ALLGAMERS.GetPlayerJobGrade(id)
    local p = GetPlayer(id); if not p then return 0 end
    return p.PlayerData.job.grade.level
end

function ALLGAMERS.GetPlayerJobInfo(id)
    local p = GetPlayer(id)
    if not p then return {} end
    local playerData = p.PlayerData
    local job = playerData.job
    local grade = job.grade or {}
    local isBoss = job.isboss == true
    return {
        jobName = job.name,
        jobLabel = job.label,
        gradeName = grade.name,
        gradeLabel = grade.label,
        gradeRank = grade.level,
        boss = isBoss,
        onDuty = job.onduty
    }
end

function ALLGAMERS.GetPlayerGang(id)
    local p = GetPlayer(id)
    if not p then return nil, nil, nil, nil end
    local g = p.PlayerData.gang
    if not g or not g.name or g.name == '' or g.name == 'none' then
        return nil, nil, nil, nil
    end
    local gr = g.grade or {}
    return g.name, g.label or g.name, gr.name, gr.level
end

function ALLGAMERS.GetPlayerGangInfo(id)
    local p = GetPlayer(id)
    if not p then return {} end
    local g = p.PlayerData.gang
    if not g or not g.name or g.name == '' or g.name == 'none' then
        return {}
    end
    local gr = g.grade or {}
    local gradeName = gr.name
    local isBoss = (g.isboss == true) or (gradeName == "boss")
    return {
        gangName = g.name,
        gangLabel = g.label or g.name,
        gradeName = gradeName,
        gradeLabel = gr.label or gradeName,
        gradeRank = gr.level,
        boss = isBoss,
    }
end

function ALLGAMERS.HasPermission(id)
    for group, _ in pairs(config.AdminGroups) do
        if QBCore.Functions.HasPermission(id, group) then
            return true
        end
    end
    return false
end

function ALLGAMERS.AddMoney(id, amt, reason)
    local p = GetPlayer(id); if not p then return false end
    return p.Functions.AddMoney('cash', amt, reason or 'allgamers_bridge') == true
end

function ALLGAMERS.RemoveMoney(id, amt, reason)
    local p = GetPlayer(id); if not p then return false end
    return p.Functions.RemoveMoney('cash', amt, reason or 'allgamers_bridge') == true
end

function ALLGAMERS.RemoveBankMoney(id, amt, reason)
    local p = GetPlayer(id); if not p then return false end
    return p.Functions.RemoveMoney('bank', amt, reason or 'allgamers_bridge') == true
end

function ALLGAMERS.AddBankMoney(id, amt, reason)
    local p = GetPlayer(id); if not p then return false end
    return p.Functions.AddMoney('bank', amt, reason or 'allgamers_bridge') == true
end

function ALLGAMERS.GetMoney(id)
    local p = GetPlayer(id)
    return p and p.Functions.GetMoney('cash') or 0
end

function ALLGAMERS.GetBankMoney(id)
    local p = GetPlayer(id)
    return p and p.Functions.GetMoney('bank') or 0
end

function ALLGAMERS.TransferMoney(from, to, amount)
    local s = GetPlayer(from)
    local r = GetPlayer(to)
    if not s or not r then return false, "Player not found" end
    local bal = s.Functions.GetMoney('bank')
    if bal >= amount then
        s.Functions.RemoveMoney('bank', amount, 'allgamers_bridge_transfer')
        r.Functions.AddMoney('bank', amount, 'allgamers_bridge_transfer')
        return true, "Success"
    else
        return false, "Not enough money in sender's account"
    end
end

function ALLGAMERS.SetJob(id, job, grade)
    local p = GetPlayer(id); if not p then return false end
    p.Functions.SetJob(job, grade); return true
end

function ALLGAMERS.GetIdentifier(id)
    local p = GetPlayer(id)
    return p and p.PlayerData and p.PlayerData.citizenid or nil
end

function ALLGAMERS.GetPlayerByCitizenId(cid)
    local Player = QBCore.Functions.GetPlayerByCitizenId(cid)
    return Player and Player.PlayerData or nil
end

function ALLGAMERS.GetPlayerName(id)
    local p = GetPlayer(id)
    local c = p and p.PlayerData and p.PlayerData.charinfo
    local firstName = c and (c.firstname or "") or ""
    local lastName  = c and (c.lastname  or "") or ""
    return tostring(firstName), tostring(lastName)
end

function ALLGAMERS.GetPlayerCoords(id)
    local ped = GetPlayerPed(id)
    if not ped or ped == 0 then
        return vector3(0.0, 0.0, 0.0)
    end
    return GetEntityCoords(ped)
end

function ALLGAMERS.GetPlayerMetadata(id, metadata)
    local p = GetPlayer(id)
    if not p then return false end
    local playerData = p.PlayerData
    return playerData.metadata[metadata] or false
end

function ALLGAMERS.SetPlayerMetadata(id, metadata, value)
    local p = GetPlayer(id)
    if not p then return false end
    p.Functions.SetMetaData(metadata, value)
    return true
end

function ALLGAMERS.GetPlayerDuty(id)
    local p = GetPlayer(id)
    if not p then return false end
    local playerData = p.PlayerData
    if not playerData.job.onduty then return false end
    return true
end

function ALLGAMERS.GetIsPlayerDead(id)
    local p = GetPlayer(id)
    if not p then return false end
    local playerData = p.PlayerData
    return playerData.metadata.isdead or playerData.metadata.inlaststand or false
end

function ALLGAMERS.RevivePlayer(id)
    TriggerClientEvent('hospital:client:Revive', id)
    return true
end

function ALLGAMERS.RegisterUsableItem(itemName, cb)
    local func = function(src, item, itemData)
        itemData = itemData or item
        itemData.metadata = itemData.metadata or itemData.info or {}
        itemData.slot = itemData.id or itemData.slot
        cb(src, itemData)
    end
    QBCore.Functions.CreateUseableItem(itemName, func)
    return true
end

return ALLGAMERS