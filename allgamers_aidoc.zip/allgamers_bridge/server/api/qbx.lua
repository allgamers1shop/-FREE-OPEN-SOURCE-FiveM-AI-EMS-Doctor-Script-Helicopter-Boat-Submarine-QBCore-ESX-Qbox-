if GetResourceState('qbx_core') ~= 'started' then return end

local ALLGAMERS = {}
local core = exports.qbx_core


function ALLGAMERS.GetPlayer(id)
    return core:GetPlayer(id)
end

function ALLGAMERS.GetAllPlayers()
    local playerSources = {}
    if core.GetQBPlayers then
        local players = core:GetQBPlayers()
        for src, _ in pairs(players) do
            playerSources[#playerSources + 1] = src
        end
    else
        playerSources = GetPlayers()
    end
    return playerSources
end



function ALLGAMERS.GetPlayerJob(id)
    local p = core:GetPlayer(id); if not p then return nil,nil,nil,nil end
    local j = p.PlayerData.job
    return j.name, j.label, j.grade and j.grade.name, j.grade and j.grade.level
end

function ALLGAMERS.GetPlayerJobGrade(id)
    local p = core:GetPlayer(id); if not p then return 0 end
    return p.PlayerData.job.grade.level
end

function ALLGAMERS.GetPlayerJobInfo(id)
    local p = core:GetPlayer(id)
    if not p then return {} end
    local playerData = p.PlayerData
    local job = playerData.job
    local grade = job.grade or {}
    local isBoss = job.isboss == true
    return {
        jobName = job.name,
        jobLabel = job.label,
        gradeName = grade.name,
        gradeLabel = grade.label,
        gradeRank = grade.level,
        boss = isBoss,
        onDuty = job.onduty
    }
end

function ALLGAMERS.GetPlayerGang(id)
    local p = core:GetPlayer(id)
    if not p then return nil, nil, nil, nil end
    local g = p.PlayerData.gang
    if not g or not g.name or g.name == '' or g.name == 'none' then
        return nil, nil, nil, nil
    end
    local gr = g.grade or {}
    return g.name, g.label or g.name, gr.name, gr.level
end

function ALLGAMERS.GetPlayerGangInfo(id)
    local p = core:GetPlayer(id)
    if not p then return {} end
    local g = p.PlayerData.gang
    if not g or not g.name or g.name == '' or g.name == 'none' then
        return {}
    end
    local gr = g.grade or {}
    local gradeName = gr.name
    local isBoss = (g.isboss == true) or (gradeName == "boss")
    return {
        gangName = g.name,
        gangLabel = g.label or g.name,
        gradeName = gradeName,
        gradeLabel = gr.label or gradeName,
        gradeRank = gr.level,
        boss = isBoss,
    }
end

function ALLGAMERS.HasPermission(id)
    for group, _ in pairs(config.AdminGroups) do
        if core:HasGroup(id, group) then
            return true
        end
    end
    return false
end

local function GetPlayerMoney(id, account)
    local player = core:GetPlayer(id)
    if not player then return 0 end

    if player.Functions and player.Functions.GetMoney then
        return tonumber(player.Functions.GetMoney(account)) or 0
    end

    local money = player.PlayerData and player.PlayerData.money
    if type(money) == 'table' then
        return tonumber(money[account]) or 0
    end

    return 0
end

local function AddPlayerMoney(id, account, amount, reason)
    local player = core:GetPlayer(id)
    if not player or not player.Functions or not player.Functions.AddMoney then return false end
    return player.Functions.AddMoney(account, amount, reason or 'allgamers_bridge') == true
end

local function RemovePlayerMoney(id, account, amount, reason)
    local player = core:GetPlayer(id)
    if not player or not player.Functions or not player.Functions.RemoveMoney then return false end
    return player.Functions.RemoveMoney(account, amount, reason or 'allgamers_bridge') == true
end

function ALLGAMERS.AddMoney(id, amt, reason)
    return AddPlayerMoney(id, 'cash', amt, reason)
end

function ALLGAMERS.RemoveMoney(id, amt, reason)
    return RemovePlayerMoney(id, 'cash', amt, reason)
end

function ALLGAMERS.RemoveBankMoney(id, amt, reason)
    return RemovePlayerMoney(id, 'bank', amt, reason)
end

function ALLGAMERS.AddBankMoney(id, amt, reason)
    return AddPlayerMoney(id, 'bank', amt, reason)
end

function ALLGAMERS.GetMoney(id)
    return GetPlayerMoney(id, 'cash')
end

function ALLGAMERS.GetBankMoney(id)
    return GetPlayerMoney(id, 'bank')
end

function ALLGAMERS.TransferMoney(from, to, amount)
    local senderMoney = GetPlayerMoney(from, 'bank')
    if senderMoney >= amount then
        RemovePlayerMoney(from, 'bank', amount, 'allgamers_bridge_transfer')
        AddPlayerMoney(to, 'bank', amount, 'allgamers_bridge_transfer')
        return true, "Success"
    else
        return false, "Not enough money in sender's account"
    end
end

function ALLGAMERS.SetJob(id, job, grade)
    core:SetJob(id, job, grade); return true
end

function ALLGAMERS.GetIdentifier(id)
    local player = core:GetPlayer(id)
    if player and player.PlayerData then
        return player.PlayerData.citizenid or player.PlayerData.license or GetPlayerIdentifierByType(id, 'license')
    end
    return GetPlayerIdentifierByType(id, 'license')
end

function ALLGAMERS.GetPlayerByCitizenId(cid)
    if core.GetPlayerByCitizenId then
        local player = core:GetPlayerByCitizenId(cid)
        if not player then return nil end
        if player.PlayerData then
            return player.PlayerData
        end
        return player
    end
    for _, src in ipairs(GetPlayers()) do
        local player = core:GetPlayer(src)
        if player and player.PlayerData.citizenid == cid then
            return player.PlayerData
        end
    end
    return nil
end


function ALLGAMERS.GetPlayerName(id)
    local p = core:GetPlayer(id)
    local c = p and p.PlayerData and p.PlayerData.charinfo
    local firstName = c and (c.firstname or "") or ""
    local lastName  = c and (c.lastname  or "") or ""
    return tostring(firstName), tostring(lastName)
end

function ALLGAMERS.GetPlayerCoords(id)
    local ped = GetPlayerPed(id)
    if not ped or ped == 0 then
        return vector3(0.0, 0.0, 0.0)
    end
    return GetEntityCoords(ped)
end

function ALLGAMERS.GetPlayerMetadata(id, metadata)
    local p = core:GetPlayer(id)
    if not p then return false end
    local playerData = p.PlayerData
    return playerData.metadata[metadata] or false
end

function ALLGAMERS.SetPlayerMetadata(id, metadata, value)
    local p = core:GetPlayer(id)
    if not p then return false end
    p.Functions.SetMetaData(metadata, value)
    return true
end

function ALLGAMERS.GetPlayerDuty(id)
    local p = core:GetPlayer(id)
    if not p then return false end
    local playerData = p.PlayerData
    if not playerData.job.onduty then return false end
    return true
end

function ALLGAMERS.GetIsPlayerDead(id)
    local p = core:GetPlayer(id)
    if not p then return false end
    local playerData = p.PlayerData
    return playerData.metadata.isdead or false
end

function ALLGAMERS.RevivePlayer(id)
    TriggerClientEvent('qbx_medical:client:playerRevived', id)
    return true
end

function ALLGAMERS.RegisterUsableItem(itemName, cb)
    local func = function(src, item, itemData)
        itemData = itemData or item
        itemData.metadata = itemData.metadata or itemData.info or {}
        itemData.slot = itemData.id or itemData.slot
        cb(src, itemData)
    end
    return core:CreateUseableItem(itemName, func)
end

return ALLGAMERS
