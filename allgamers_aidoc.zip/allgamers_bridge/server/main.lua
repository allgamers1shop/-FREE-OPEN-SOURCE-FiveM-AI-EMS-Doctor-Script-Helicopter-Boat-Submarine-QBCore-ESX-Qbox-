local ALLGAMERS = ALLGAMERS or {}
local API
local framework

local function waitFor(res)
    local t = GetGameTimer()
    while GetResourceState(res) ~= 'started' do
        if GetGameTimer() - t > 15000 then
            print(('^1[allgamers_bridge]^7 timeout waiting for %s'):format(res))
            break
        end
        Wait(50)
    end
end

if config.Framework:lower() ~= "auto" then
    framework = config.Framework:lower()
    if config.Debug then
        DebugPrint("Using manually configured framework: " .. framework, "info")
    end
else
    local qb = GetResourceState('qb-core') == "started"
    local qbx = GetResourceState('qbx_core') == "started"
    local esx = GetResourceState('es_extended') == "started"

    if config.Debug then
        DebugPrint("Framework detection results:", "debug")
        DebugPrint("QB-Core: " .. (qb and "Found" or "Not found"), "debug")
        DebugPrint("QBX-Core: " .. (qbx and "Found" or "Not found"), "debug")
        DebugPrint("ESX Extended: " .. (esx and "Found" or "Not found"), "debug")
    end

    if qbx then 
        framework = 'qbx'
        if config.Debug then
            DebugPrint("Framework detected: QBX-Core", "success")
        end
    elseif qb then 
        framework = 'qb'
        if config.Debug then
            DebugPrint("Framework detected: QB-Core", "success")
        end
    elseif esx then 
        framework = 'esx'
        if config.Debug then
            DebugPrint("Framework detected: ESX Extended", "success")
        end
    else
        DebugPrint("Couldn't detect your framework! Please make sure that allgamers_bridge starts AFTER your framework resource.", "error")
        return error("Unknown Framework")
    end
end

local function loadApiFile(name)
    local res = GetCurrentResourceName()
    local path = ('server/api/%s.lua'):format(name)
    local src = LoadResourceFile(res, path)
    assert(src, ('[allgamers_bridge] missing api file: %s'):format(path))
    local chunk, err = load(src, ('=@%s'):format(path))
    assert(chunk, err)
    local mod = chunk()
    assert(type(mod) == 'table', ('[allgamers_bridge] %s must return a table'):format(path))
    return mod
end

local function loadInventoryFile(name)
    local res = GetCurrentResourceName()

    local fileVariations = {
        name,                           
        name:gsub("-", "_"),           
        name:gsub("_", "-"),           
    }

    local src, path
    for _, fileName in ipairs(fileVariations) do
        path = ('server/api/inventory/%s.lua'):format(fileName)
        src = LoadResourceFile(res, path)
        if src then
            if config.Debug then
                DebugPrint(('Found inventory file: %s'):format(path), "debug")
            end
            break
        end
    end

    if not src then
        if config.Debug then
            DebugPrint(('Inventory file not found for %s (tried multiple variations)'):format(name), "debug")
        end
        return nil
    end
    local chunk, err = load(src, ('=@%s'):format(path))
    if not chunk then
        if config.Debug then
            DebugPrint(('Error loading inventory file %s: %s'):format(path, err), "error")
        end
        return nil
    end
    local mod = chunk()
    if type(mod) ~= 'table' then
        if config.Debug then
            DebugPrint(('Inventory file %s must return a table'):format(path), "error")
        end
        return nil
    end
    return mod
end

if framework == 'qb' then
    waitFor('qb-core')
    API = loadApiFile('qb')
elseif framework == 'qbx' then
    waitFor('qbx_core')
    API = loadApiFile('qbx')
elseif framework == 'esx' then
    waitFor('es_extended')
    API = loadApiFile('esx')
end

-- Set Framework globally for server-side inventory APIs
if framework == 'qb' then
    _G.Framework = exports['qb-core']:GetCoreObject()
elseif framework == 'qbx' then
    _G.Framework = exports['qb-core']:GetCoreObject()
elseif framework == 'esx' then
    _G.Framework = exports['es_extended']:getSharedObject()
end

local function loadALLGAMERS_BankingModule()
    local bankingSystems = {
        'qb-banking',
        'p_banking',
        'okokBanking',
        'fd_banking',
        'renewed-banking',
        'tgg-banking',
        'kartik-banking',
        'tgiann-bank',
        'wasabi_banking',
        'qb-management',
        'qbx_management',
        'esx_society',
        'qs-banking'
    }

    if config.Banking and config.Banking:lower() ~= "auto" then
        local requestedSystem = config.Banking:lower()
        local found = false

        for _, system in ipairs(bankingSystems) do
            if system:lower() == requestedSystem then
                local fileName = 'banking/' .. system
                local path = ('server/api/%s.lua'):format(fileName)

                if LoadResourceFile(GetCurrentResourceName(), path) then
                    if config.Debug then
                        DebugPrint("Loading manually configured ALLGAMERS_Banking module: " .. system, "debug")
                    end

                    local success, mod = pcall(loadApiFile, fileName)
                    if success and mod and mod.GetSystemName then
                        ALLGAMERS_Banking = mod
                        if config.Debug then
                            DebugPrint("ALLGAMERS_Banking module loaded: " .. mod.GetSystemName(), "success")
                        end
                        return
                    else
                        DebugPrint("Failed to load manually configured banking system: " .. system, "error")
                        found = true
                        break
                    end
                else
                    DebugPrint("Manually configured banking system '" .. system .. "' file not found", "error")
                    found = true
                    break
                end
            end
        end

        if not found then
            DebugPrint("Invalid banking system specified in config: " .. config.Banking, "error")
            DebugPrint("Valid options: auto, " .. table.concat(bankingSystems, ", "), "error")
        end

        if config.Debug then
            DebugPrint("Manual banking system not available, loading default", "debug")
        end
        ALLGAMERS_Banking = loadApiFile('banking/_default')
        return
    end

    -- Auto-detection mode (original behavior)
    if config.Debug then
        DebugPrint("Banking system set to auto-detection", "debug")
    end

    for _, system in ipairs(bankingSystems) do
        local fileName = 'banking/' .. system
        local path = ('server/api/%s.lua'):format(fileName)

        if LoadResourceFile(GetCurrentResourceName(), path) then
            if config.Debug then
                DebugPrint("Loading ALLGAMERS_Banking module: " .. system, "debug")
            end

            local success, mod = pcall(loadApiFile, fileName)
            if success and mod and mod.GetSystemName then
                ALLGAMERS_Banking = mod
                if config.Debug then
                    DebugPrint("ALLGAMERS_Banking module loaded: " .. mod.GetSystemName(), "success")
                end
                return
            end
        end
    end

    if config.Debug then
        DebugPrint("No banking system found, loading default", "debug")
    end
    ALLGAMERS_Banking = loadApiFile('banking/_default')
end

loadALLGAMERS_BankingModule()

local function loadALLGAMERS_InventoryModule()
    if config.Inventory and config.Inventory:lower() ~= "auto" then
        local requestedSystem = config.Inventory:lower()
        local fileName = 'inventory/' .. requestedSystem
        local path = ('server/api/%s.lua'):format(fileName)

        local mod = loadInventoryFile(requestedSystem)
        if mod and mod.GetResourceName then
            ALLGAMERS_Inventory = mod
            if config.Debug then
                DebugPrint("ALLGAMERS_Inventory module loaded: " .. mod.GetResourceName(), "success")
            end
            return
        else
            DebugPrint("Failed to load manually configured inventory system: " .. requestedSystem, "error")
        end

        if config.Debug then
            DebugPrint("Manual inventory system not available, loading default", "debug")
        end
        ALLGAMERS_Inventory = loadInventoryFile('_default')
        return
    end

    -- Auto-detection mode
    if config.Debug then
        DebugPrint("Inventory system set to auto-detection", "debug")
    end

    local inventorySystems = {
        'qb-inventory',
        'ox_inventory',
        'codem-inventory',
        'origen_inventory',
        'qs-inventory',
        'tgiann-inventory',
        'jpr-inventory',
        'ps-inventory',
        'core_inventory'
    }

    if config.Debug then
        DebugPrint("Inventory detection results:", "debug")
        for _, system in ipairs(inventorySystems) do
            local status = GetResourceState(system) == 'started' and "Found" or "Not found"
            DebugPrint(system .. ": " .. status, "debug")
        end
    end

    for _, system in ipairs(inventorySystems) do
        if GetResourceState(system) == 'started' then
            if config.Debug then
                DebugPrint("Loading ALLGAMERS_Inventory module: " .. system, "debug")
            end

            local mod = loadInventoryFile(system)
            if mod and mod.GetResourceName then
                ALLGAMERS_Inventory = mod
                if config.Debug then
                    DebugPrint("ALLGAMERS_Inventory module loaded: " .. mod.GetResourceName(), "success")
                end
                return
            else
                if config.Debug then
                    DebugPrint("Failed to load " .. system .. " inventory module", "warning")
                end
            end
        end
    end

    if config.Debug then
        DebugPrint("No inventory system found, loading default", "debug")
    end
    ALLGAMERS_Inventory = loadInventoryFile('_default')
end

loadALLGAMERS_InventoryModule()

if config.Debug then
    DebugPrint("AllGamers Bridge initialized successfully with framework: " .. framework, "success")
end

---@return string
function ALLGAMERS.GetFrameworkName()
    if config.Debug then
        DebugPrint("GetFrameworkName function called", "debug")
    end
    return framework
end

---@param id number
---@return table
function ALLGAMERS.GetPlayer(id)
    if config.Debug then
        DebugPrint("GetPlayer function called with ID: " .. id, "debug")
    end
    return API.GetPlayer(id)
end

---@return table
function ALLGAMERS.GetAllPlayers()
    if config.Debug then
        DebugPrint("GetAllPlayers function called", "debug")
    end
    return API.GetAllPlayers()
end

---@param id number
---@return string name, string label, string grade_name, number grade_level
function ALLGAMERS.GetPlayerJob(id)
    if config.Debug then
        DebugPrint("GetPlayerJob function called with ID: " .. id, "debug")
    end
    return API.GetPlayerJob(id)
end

---@param id number
---@return number
function ALLGAMERS.GetPlayerJobGrade(id)
    if config.Debug then
        DebugPrint("GetPlayerJobGrade function called with ID: " .. id, "debug")
    end
    return API.GetPlayerJobGrade(id)
end

---@param id number
---@return table jobInfo
function ALLGAMERS.GetPlayerJobInfo(id)
    if config.Debug then
        DebugPrint("GetPlayerJobInfo function called with ID: " .. id, "debug")
    end
    return API.GetPlayerJobInfo(id)
end

function ALLGAMERS.GetPlayerGang(id)
    if config.Debug then
        DebugPrint("GetPlayerGang function called with ID: " .. id, "debug")
    end
    return API.GetPlayerGang(id)
end

function ALLGAMERS.GetPlayerGangInfo(id)
    if config.Debug then
        DebugPrint("GetPlayerGangInfo function called with ID: " .. id, "debug")
    end
    return API.GetPlayerGangInfo(id)
end

local function addAcePermissionTarget(targets, seen, permission)
    if type(permission) ~= 'string' or permission == '' or seen[permission] then
        return
    end
    targets[#targets + 1] = permission
    seen[permission] = true
end

local function HasAcePermission(playerId, permission)
    if not config.EnableAcePermissions then
        return false
    end

    playerId = tonumber(playerId)
    if not playerId then
        return false
    end

    local targets = {}
    local seen = {}

    addAcePermissionTarget(targets, seen, permission)

    if type(config.AcePermissions) == 'table' then
        for _, acePermission in ipairs(config.AcePermissions) do
            addAcePermissionTarget(targets, seen, acePermission)
        end
    elseif type(config.AcePermissions) == 'string' then
        addAcePermissionTarget(targets, seen, config.AcePermissions)
    end

    for _, acePermission in ipairs(targets) do
        if IsPlayerAceAllowed(playerId, acePermission) then
            if config.Debug then
                DebugPrint(("ACE permission matched for PlayerID: %s | Permission: %s"):format(playerId, acePermission), "debug")
            end
            return true
        end
    end

    return false
end

---@param playerId number
---@param permission? string
---@return boolean
function ALLGAMERS.HasPermission(playerId, permission)
    if config.Debug then
        DebugPrint("HasPermission function called with PlayerID: " .. playerId, "debug")
    end

    if API and API.HasPermission then
        local ok, hasFrameworkPermission = pcall(API.HasPermission, playerId, permission)
        if ok and hasFrameworkPermission then
            return true
        elseif not ok and config.Debug then
            DebugPrint(("Framework permission check failed for PlayerID: %s | Error: %s"):format(tostring(playerId), tostring(hasFrameworkPermission)), "warning")
        end
    end

    return HasAcePermission(playerId, permission)
end

---@param playerId number Target player ID
---@param amount number Amount to add
function ALLGAMERS.AddMoney(playerId, amount, reason)
    if config.Debug then
        DebugPrint("AddMoney function called with PlayerID: " .. playerId .. ", Amount: " .. amount, "debug")
    end
    amount = tonumber(amount) or 0
    if amount <= 0 then return false end
    return API.AddMoney(playerId, amount, reason)
end

---@param playerId number
---@param amount number
function ALLGAMERS.RemoveMoney(playerId, amount, reason)
    if config.Debug then
        DebugPrint("RemoveMoney function called with PlayerID: " .. playerId .. ", Amount: " .. amount, "debug")
    end
    amount = tonumber(amount) or 0
    if amount <= 0 then return false end
    return API.RemoveMoney(playerId, amount, reason)
end

function ALLGAMERS.RemoveBankMoney(playerId, amount, reason)
    if config.Debug then
        DebugPrint("RemoveBankMoney function called with PlayerID: " .. playerId .. ", Amount: " .. amount, "debug")
    end
    amount = tonumber(amount) or 0
    if amount <= 0 then return false end
    return API.RemoveBankMoney(playerId, amount, reason)
end

function ALLGAMERS.AddBankMoney(playerId, amount, reason)
    if config.Debug then
        DebugPrint("AddBankMoney function called with PlayerID: " .. playerId .. ", Amount: " .. amount, "debug")
    end
    amount = tonumber(amount) or 0
    if amount <= 0 then return false end
    return API.AddBankMoney(playerId, amount, reason)
end

function ALLGAMERS.GetMoney(playerId)
    if config.Debug then
        DebugPrint("GetMoney function called with PlayerID: " .. playerId, "debug")
    end
    return API.GetMoney(playerId)
end

function ALLGAMERS.GetBankMoney(playerId)
    if config.Debug then
        DebugPrint("GetBankMoney function called with PlayerID: " .. playerId, "debug")
    end
    return API.GetBankMoney(playerId)
end

---@param from number Sender's ID
---@param to number Receiver's ID
---@param amount number Amount to transfer
---@return boolean status, string statusMessage
function ALLGAMERS.TransferMoney(from, to, amount)
    if config.Debug then
        DebugPrint(("TransferMoney From:%s To:%s Amount:%s"):format(from, to, amount), "debug")
    end
    amount = tonumber(amount) or 0
    if amount <= 0 then return false, "Invalid amount" end
    if not GetPlayerName(to) then return false, "Not Online" end
    return API.TransferMoney(from, to, amount)
end


function ALLGAMERS.SetJob(playerId, job_name, job_grade)
    if config.Debug then
        DebugPrint("SetJob function called with PlayerID: " .. playerId .. ", Job: " .. job_name .. ", Grade: " .. job_grade, "debug")
    end
    return API.SetJob(playerId, job_name, job_grade)
end

function ALLGAMERS.GetIdentifier(playerId)
    if config.Debug then
        DebugPrint("GetIdentifier function called with PlayerID: " .. playerId, "debug")
    end
    return API.GetIdentifier(playerId)
end

---@param cid string
---@return table|nil
function ALLGAMERS.GetPlayerByCitizenId(cid)
    if config.Debug then
        DebugPrint("GetPlayerByCitizenId function called with CID: " .. tostring(cid), "debug")
    end
    if not cid then return nil end
    return API.GetPlayerByCitizenId(cid)
end

---@param playerId number Target player ID
---@return string firstname, string lastname
function ALLGAMERS.GetPlayerName(playerId) 
    if config.Debug then
        DebugPrint("GetPlayerName function called" .. (playerId and (" with PlayerID: "..playerId) or ""), "debug")
    end
    return API.GetPlayerName(playerId)
end

---@param playerId number Target player ID
---@return vector3 coords Player Coords
function ALLGAMERS.GetPlayerCoords(playerId)
    if config.Debug then
        DebugPrint("GetPlayerCoords function called with PlayerID: " .. playerId, "debug")
    end
    return API.GetPlayerCoords(playerId)
end

---@param playerId number Target player ID
---@param metadata string Metadata key
---@return any metadata value
function ALLGAMERS.GetPlayerMetadata(playerId, metadata)
    if config.Debug then
        DebugPrint("GetPlayerMetadata function called with PlayerID: " .. playerId .. ", Metadata: " .. metadata, "debug")
    end
    return API.GetPlayerMetadata(playerId, metadata)
end

---@param playerId number Target player ID
---@param metadata string Metadata key
---@param value any Metadata value
---@return boolean success
function ALLGAMERS.SetPlayerMetadata(playerId, metadata, value)
    if config.Debug then
        DebugPrint(("SetPlayerMetadata called | PlayerID: %s | Key: %s | Value: %s")
            :format(tostring(playerId), tostring(metadata), tostring(value)), "debug")
    end
    return API.SetPlayerMetadata(playerId, metadata, value)
end

---@param playerId number Target player ID
---@return boolean duty status
function ALLGAMERS.GetPlayerDuty(playerId)
    if config.Debug then
        DebugPrint("GetPlayerDuty function called with PlayerID: " .. playerId, "debug")
    end
    return API.GetPlayerDuty(playerId)
end

---@param playerId number Target player ID
---@return boolean dead status
function ALLGAMERS.GetIsPlayerDead(playerId)
    if config.Debug then
        DebugPrint("GetIsPlayerDead function called with PlayerID: " .. playerId, "debug")
    end
    return API.GetIsPlayerDead(playerId)
end

function ALLGAMERS.RevivePlayer(playerId)
    if config.Debug then
        DebugPrint("RevivePlayer function called with PlayerID: " .. playerId, "debug")
    end
    playerId = tonumber(playerId)
    if not playerId then return false end
    return API.RevivePlayer(playerId)
end

function ALLGAMERS.RegisterUsableItem(itemName, cb)
    if config.Debug then
        DebugPrint("RegisterUsableItem function called with ItemName: " .. itemName, "debug")
    end
    return API.RegisterUsableItem(itemName, cb)
end

function ALLGAMERS.AddAccountMoney(accountName, amount, reason)
    if config.Debug then
        DebugPrint("AddAccountMoney function called with Account: " .. accountName .. ", Amount: " .. amount, "debug")
    end
    amount = tonumber(amount) or 0
    if amount <= 0 then return false end
    return ALLGAMERS_Banking.AddAccountFunds(accountName, amount, reason)
end

function ALLGAMERS.RemoveAccountMoney(accountName, amount, reason)
    if config.Debug then
        DebugPrint("RemoveAccountMoney function called with Account: " .. accountName .. ", Amount: " .. amount, "debug")
    end
    amount = tonumber(amount) or 0
    if amount <= 0 then return false end
    return ALLGAMERS_Banking.RemoveAccountFunds(accountName, amount, reason)
end

function ALLGAMERS.GetAccountMoney(accountName)
    if config.Debug then
        DebugPrint("GetAccountMoney function called with Account: " .. accountName, "debug")
    end
    return ALLGAMERS_Banking.GetAccountBalance(accountName)
end

--- Inventory System Functions

function ALLGAMERS.GetInventoryResourceName()
    if config.Debug then
        DebugPrint("GetInventoryResourceName function called", "debug")
    end
    if ALLGAMERS_Inventory and ALLGAMERS_Inventory.GetResourceName then
        return ALLGAMERS_Inventory.GetResourceName()
    end
    return "default"
end

function ALLGAMERS.GetItemInfo(item)
    if config.Debug then
        DebugPrint("GetItemInfo function called with Item: " .. tostring(item), "debug")
    end
    if ALLGAMERS_Inventory and ALLGAMERS_Inventory.GetItemInfo then
        return ALLGAMERS_Inventory.GetItemInfo(item)
    end
    return {}
end

function ALLGAMERS.GetAllItems()
    if config.Debug then
        DebugPrint("GetAllItems function called", "debug")
    end
    if ALLGAMERS_Inventory and ALLGAMERS_Inventory.Items then
        return ALLGAMERS_Inventory.Items()
    end
    return {}
end

function ALLGAMERS.GetItemCount(playerId, item, metadata)
    if config.Debug then
        DebugPrint("GetItemCount function called with PlayerID: " .. playerId .. ", Item: " .. item, "debug")
    end
    if ALLGAMERS_Inventory and ALLGAMERS_Inventory.GetItemCount then
        return ALLGAMERS_Inventory.GetItemCount(playerId, item, metadata)
    end
    return 0
end

function ALLGAMERS.GetPlayerInventory(playerId)
    if config.Debug then
        DebugPrint("GetPlayerInventory function called with PlayerID: " .. playerId, "debug")
    end
    if ALLGAMERS_Inventory and ALLGAMERS_Inventory.GetPlayerInventory then
        return ALLGAMERS_Inventory.GetPlayerInventory(playerId)
    end
    return {}
end

function ALLGAMERS.GetItemBySlot(playerId, slot)
    if config.Debug then
        DebugPrint("GetItemBySlot function called with PlayerID: " .. playerId .. ", Slot: " .. slot, "debug")
    end
    if ALLGAMERS_Inventory and ALLGAMERS_Inventory.GetItemBySlot then
        return ALLGAMERS_Inventory.GetItemBySlot(playerId, slot)
    end
    return {}
end

function ALLGAMERS.SetItemMetadata(playerId, item, slot, metadata)
    if config.Debug then
        DebugPrint("SetItemMetadata function called with PlayerID: " .. playerId .. ", Item: " .. item, "debug")
    end
    if ALLGAMERS_Inventory and ALLGAMERS_Inventory.SetMetadata then
        return ALLGAMERS_Inventory.SetMetadata(playerId, item, slot, metadata)
    end
    return false
end

function ALLGAMERS.GetImagePath(item)
    if config.Debug then
        DebugPrint("GetImagePath function called with Item: " .. tostring(item), "debug")
    end
    if ALLGAMERS_Inventory and ALLGAMERS_Inventory.GetImagePath then
        return ALLGAMERS_Inventory.GetImagePath(item)
    end
    return "https://raw.githubusercontent.com/AllGamers-Scripts/allgamers-assets/main/inventory-placeholder.png"
end

function ALLGAMERS.OpenStash(playerId, stashType, stashId)
    if config.Debug then
        DebugPrint("OpenStash function called with PlayerID: " .. playerId .. ", Type: " .. tostring(stashType) .. ", ID: " .. tostring(stashId), "debug")
    end
    if ALLGAMERS_Inventory and ALLGAMERS_Inventory.OpenStash then
        return ALLGAMERS_Inventory.OpenStash(playerId, stashType, stashId)
    end
    return false
end

function ALLGAMERS.RegisterStash(stashId, label, slots, weight, owner, groups, coords)
    if config.Debug then
        DebugPrint("RegisterStash function called with ID: " .. tostring(stashId), "debug")
    end
    if ALLGAMERS_Inventory and ALLGAMERS_Inventory.RegisterStash then
        return ALLGAMERS_Inventory.RegisterStash(stashId, label, slots, weight, owner, groups, coords)
    end
    return false
end

function ALLGAMERS.AddStashItems(stashId, items)
    if config.Debug then
        DebugPrint("AddStashItems function called with StashID: " .. tostring(stashId), "debug")
    end
    if ALLGAMERS_Inventory and ALLGAMERS_Inventory.AddStashItems then
        return ALLGAMERS_Inventory.AddStashItems(stashId, items)
    end
    return false
end

function ALLGAMERS.RemoveStashItems(stashId, items)
    if config.Debug then
        DebugPrint("RemoveStashItems function called with StashID: " .. tostring(stashId), "debug")
    end
    if ALLGAMERS_Inventory and ALLGAMERS_Inventory.RemoveStashItems then
        return ALLGAMERS_Inventory.RemoveStashItems(stashId, items)
    end
    return false
end

function ALLGAMERS.ClearStash(stashId, stashType)
    if config.Debug then
        DebugPrint("ClearStash function called with StashID: " .. tostring(stashId), "debug")
    end
    if ALLGAMERS_Inventory and ALLGAMERS_Inventory.ClearStash then
        return ALLGAMERS_Inventory.ClearStash(stashId, stashType)
    end
    return false
end

function ALLGAMERS.AddTrunkItems(vehiclePlate, items)
    if config.Debug then
        DebugPrint("AddTrunkItems function called with Plate: " .. tostring(vehiclePlate), "debug")
    end
    if ALLGAMERS_Inventory and ALLGAMERS_Inventory.AddTrunkItems then
        return ALLGAMERS_Inventory.AddTrunkItems(vehiclePlate, items)
    end
    return false
end

function ALLGAMERS.OpenShop(playerId, shopId)
    if config.Debug then
        DebugPrint("OpenShop function called with PlayerID: " .. playerId .. ", ShopID: " .. tostring(shopId), "debug")
    end
    if ALLGAMERS_Inventory and ALLGAMERS_Inventory.OpenShop then
        return ALLGAMERS_Inventory.OpenShop(playerId, shopId)
    end
    return false
end

function ALLGAMERS.RegisterShop(shopId, inventory, coords, groups)
    if config.Debug then
        DebugPrint("RegisterShop function called with ShopID: " .. tostring(shopId), "debug")
    end
    if ALLGAMERS_Inventory and ALLGAMERS_Inventory.RegisterShop then
        return ALLGAMERS_Inventory.RegisterShop(shopId, inventory, coords, groups)
    end
    return false
end

function ALLGAMERS.UpdateVehiclePlate(oldPlate, newPlate)
    if config.Debug then
        DebugPrint("UpdateVehiclePlate function called with Old: " .. tostring(oldPlate) .. ", New: " .. tostring(newPlate), "debug")
    end
    if ALLGAMERS_Inventory and ALLGAMERS_Inventory.UpdatePlate then
        return ALLGAMERS_Inventory.UpdatePlate(oldPlate, newPlate)
    end
    return false
end

function ALLGAMERS.OpenPlayerInventory(src, targetSrc)
    if config.Debug then
        DebugPrint("OpenPlayerInventory function called with Src: " .. src .. ", Target: " .. targetSrc, "debug")
    end
    if ALLGAMERS_Inventory and ALLGAMERS_Inventory.OpenPlayerInventory then
        return ALLGAMERS_Inventory.OpenPlayerInventory(src, targetSrc)
    end
    return false
end

-- Update existing inventory functions to use ALLGAMERS_Inventory instead of API
function ALLGAMERS.AddItem(playerId, item_name, amount, slot, metadata)
    if config.Debug then
        DebugPrint("AddItem function called with PlayerID: " .. playerId .. ", Item: " .. item_name .. ", Amount: " .. amount, "debug")
    end
    amount = tonumber(amount) or 0
    if amount <= 0 then return false end
    if ALLGAMERS_Inventory and ALLGAMERS_Inventory.AddItem then
        return ALLGAMERS_Inventory.AddItem(playerId, item_name, amount, slot, metadata)
    end
    return false
end

function ALLGAMERS.RemoveItem(playerId, item_name, amount, slot, metadata)
    if config.Debug then
        DebugPrint("RemoveItem function called with PlayerID: " .. playerId .. ", Item: " .. item_name .. ", Amount: " .. amount, "debug")
    end
    amount = tonumber(amount) or 0
    if amount <= 0 then return false end
    if ALLGAMERS_Inventory and ALLGAMERS_Inventory.RemoveItem then
        return ALLGAMERS_Inventory.RemoveItem(playerId, item_name, amount, slot, metadata)
    end
    return false
end

function ALLGAMERS.GetItem(playerId, item_name)
    if config.Debug then
        DebugPrint("GetItem function called with PlayerID: " .. playerId .. ", Item: " .. item_name, "debug")
    end
    if ALLGAMERS_Inventory and ALLGAMERS_Inventory.GetPlayerInventory then
        local inventory = ALLGAMERS_Inventory.GetPlayerInventory(playerId)
        if inventory then
            for _, item in pairs(inventory) do
                if item.name == item_name then
                    return item
                end
            end
        end
    end
    return {}
end

function ALLGAMERS.CanCarryItem(playerId, item_name, amount)
    if config.Debug then
        DebugPrint("CanCarryItem function called with PlayerID: " .. playerId .. ", Item: " .. item_name .. ", Amount: " .. amount, "debug")
    end
    if ALLGAMERS_Inventory and ALLGAMERS_Inventory.CanCarryItem then
        return ALLGAMERS_Inventory.CanCarryItem(playerId, item_name, amount)
    end
    return true
end

exports("GetPlayer", function(id)
    return ALLGAMERS.GetPlayer(id)
end)

exports("GetAllPlayers", function()
    return ALLGAMERS.GetAllPlayers()
end)

exports("GetPlayerJob", function(id)
    return ALLGAMERS.GetPlayerJob(id)
end)

exports("GetPlayerJobGrade", function(id)
    return ALLGAMERS.GetPlayerJobGrade(id)
end)

exports("GetPlayerJobInfo", function(id)
    return ALLGAMERS.GetPlayerJobInfo(id)
end)

exports("GetPlayerGang", function(id)
    return ALLGAMERS.GetPlayerGang(id)
end)

exports("GetPlayerGangInfo", function(id)
    return ALLGAMERS.GetPlayerGangInfo(id)
end)

exports("HasPermission", function(playerId, permission)
    return ALLGAMERS.HasPermission(playerId, permission)
end)

exports("AddMoney", function(playerId, amount, reason)
    return ALLGAMERS.AddMoney(playerId, amount, reason)
end)

exports("RemoveMoney", function(playerId, amount, reason)
    return ALLGAMERS.RemoveMoney(playerId, amount, reason)
end)

exports("RemoveBankMoney", function(playerId, amount, reason)
    return ALLGAMERS.RemoveBankMoney(playerId, amount, reason)
end)

exports("AddBankMoney", function(playerId, amount, reason)
    return ALLGAMERS.AddBankMoney(playerId, amount, reason)
end)

exports("GetMoney", function(playerId)
    return ALLGAMERS.GetMoney(playerId)
end)

exports("GetBankMoney", function(playerId)
    return ALLGAMERS.GetBankMoney(playerId)
end)

exports("TransferMoney", function(from, to, amount)
    return ALLGAMERS.TransferMoney(from, to, amount)
end)

exports("AddItem", function(playerId, item_name, amount)
    return ALLGAMERS.AddItem(playerId, item_name, amount)
end)

exports("RemoveItem", function(playerId, item_name, amount)
    return ALLGAMERS.RemoveItem(playerId, item_name, amount)
end)

exports("GetItem", function(playerId, item_name)
    return ALLGAMERS.GetItem(playerId, item_name)
end)

exports("CanCarryItem", function(playerId, item_name, amount)
    return ALLGAMERS.CanCarryItem(playerId, item_name, amount)
end)

exports("SetJob", function(playerId, job_name, job_grade)
    return ALLGAMERS.SetJob(playerId, job_name, job_grade)
end)

exports("GetIdentifier", function(playerId)
    return ALLGAMERS.GetIdentifier(playerId)
end)

exports("GetPlayerByCitizenId", function(cid)
    return ALLGAMERS.GetPlayerByCitizenId(cid)
end)

exports("GetPlayerName", function(playerId)
    return ALLGAMERS.GetPlayerName(playerId)
end)

exports("GetPlayerCoords", function(playerId)
    return ALLGAMERS.GetPlayerCoords(playerId)
end)

exports("GetPlayerMetadata", function(playerId, metadata)
    return ALLGAMERS.GetPlayerMetadata(playerId, metadata)
end)

exports("SetPlayerMetadata", function(playerId, metadata, value)
    return ALLGAMERS.SetPlayerMetadata(playerId, metadata, value)
end)

exports("GetPlayerDuty", function(playerId)
    return ALLGAMERS.GetPlayerDuty(playerId)
end)

exports("GetIsPlayerDead", function(playerId)
    return ALLGAMERS.GetIsPlayerDead(playerId)
end)

exports("RevivePlayer", function(playerId)
    return ALLGAMERS.RevivePlayer(playerId)
end)

exports("RegisterUsableItem", function(itemName, cb)
    return ALLGAMERS.RegisterUsableItem(itemName, cb)
end)

exports("AddAccountMoney", function(accountName, amount, reason)
    return ALLGAMERS.AddAccountMoney(accountName, amount, reason)
end)

exports("RemoveAccountMoney", function(accountName, amount, reason)
    return ALLGAMERS.RemoveAccountMoney(accountName, amount, reason)
end)

exports("GetAccountMoney", function(accountName)
    return ALLGAMERS.GetAccountMoney(accountName)
end)

--- Inventory Exports
exports("GetInventoryResourceName", function()
    return ALLGAMERS.GetInventoryResourceName()
end)

exports("GetItemInfo", function(item)
    return ALLGAMERS.GetItemInfo(item)
end)

exports("GetAllItems", function()
    return ALLGAMERS.GetAllItems()
end)

exports("GetItemCount", function(playerId, item, metadata)
    return ALLGAMERS.GetItemCount(playerId, item, metadata)
end)

exports("GetPlayerInventory", function(playerId)
    return ALLGAMERS.GetPlayerInventory(playerId)
end)

exports("GetItemBySlot", function(playerId, slot)
    return ALLGAMERS.GetItemBySlot(playerId, slot)
end)

exports("SetItemMetadata", function(playerId, item, slot, metadata)
    return ALLGAMERS.SetItemMetadata(playerId, item, slot, metadata)
end)

exports("GetImagePath", function(item)
    return ALLGAMERS.GetImagePath(item)
end)

exports("OpenStash", function(playerId, stashType, stashId)
    return ALLGAMERS.OpenStash(playerId, stashType, stashId)
end)

exports("RegisterStash", function(stashId, label, slots, weight, owner, groups, coords)
    return ALLGAMERS.RegisterStash(stashId, label, slots, weight, owner, groups, coords)
end)

exports("AddStashItems", function(stashId, items)
    return ALLGAMERS.AddStashItems(stashId, items)
end)

exports("RemoveStashItems", function(stashId, items)
    return ALLGAMERS.RemoveStashItems(stashId, items)
end)

exports("ClearStash", function(stashId, stashType)
    return ALLGAMERS.ClearStash(stashId, stashType)
end)

exports("AddTrunkItems", function(vehiclePlate, items)
    return ALLGAMERS.AddTrunkItems(vehiclePlate, items)
end)

exports("OpenShop", function(playerId, shopId)
    return ALLGAMERS.OpenShop(playerId, shopId)
end)

exports("RegisterShop", function(shopId, inventory, coords, groups)
    return ALLGAMERS.RegisterShop(shopId, inventory, coords, groups)
end)

exports("UpdateVehiclePlate", function(oldPlate, newPlate)
    return ALLGAMERS.UpdateVehiclePlate(oldPlate, newPlate)
end)

exports("OpenPlayerInventory", function(src, targetSrc)
    return ALLGAMERS.OpenPlayerInventory(src, targetSrc)
end)

exports("GetALLGAMERS", function()
    return ALLGAMERS
end)

local function GetVersionFromFile(body, scriptName)
    local found, version = false, "0.0.0"

    for line in body:gmatch("[^\r\n]+") do
        if line:match("%["..scriptName.."%]") then
            found = true
        elseif found then
            version = line
            break
        end
    end

    return version
end

local function CheckResourceVersion()
    if IsDuplicityVersion() then 
        CreateThread(function()
            Wait(4000)

            local resourceName = GetCurrentResourceName()
            local currentVersion = GetResourceMetadata(resourceName, "version") or "0.0.0"

            PerformHttpRequest("https://raw.githubusercontent.com/svgAPOLLO/version-checker/main/version.txt", function(err, body)
                if not body then
                    print(("^1[VersionCheck]^7 Unable to check version for ^3%s^7 (local %s)"):format(resourceName, currentVersion))
                    return
                end

                local newestVersion = GetVersionFromFile(body, resourceName)
                if newestVersion == "0.0.0" then
                    print(("^3[VersionCheck]^7 No version info found for ^3%s^7 (local %s)"):format(resourceName, currentVersion))
                    return
                end

                if currentVersion == newestVersion then
                    print(("^2[VersionCheck]^7 %s is up to date (^3%s^7)"):format(resourceName, currentVersion))
                else
                    print(("^1[VersionCheck]^7 %s is outdated! (^3%s → %s^7)"):format(resourceName, currentVersion, newestVersion))
                    print(("^1[VersionCheck]^7 Check your Keymaster and download the latest file!"):format())
                end
            end)
        end)
    end
end

CheckResourceVersion()
