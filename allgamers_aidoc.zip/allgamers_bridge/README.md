## Using AllGamers Bridge in Your Resource

To use AllGamers Bridge functions (ALLGAMERS.ShowNotification, ALLGAMERS.GetPlayer, ALLGAMERS.AddItem, etc.) in any resource:

1. Add `allgamers_bridge` to your dependencies in `fxmanifest.lua`:
```lua
dependencies {
    'allgamers_bridge',
    -- your other deps
}
```

2. Add `@allgamers_bridge/shared/init.lua` to your `shared_scripts` (must load before scripts that use ALLGAMERS):
```lua
shared_scripts {
    '@allgamers_bridge/shared/init.lua',
    -- your other shared scripts
}
```

3. Use the ALLGAMERS table directly (no exports): `ALLGAMERS.ShowNotification('Hello')`, `ALLGAMERS.GetPlayer(id)`, etc.


---

## Available Exports

### Client Exports

#### GetPlayerData
`exports.allgamers_bridge:GetPlayerData()`
Returns the current player's data including character info, job, inventory, etc.

#### IsPlayerLoaded
`exports.allgamers_bridge:IsPlayerLoaded()`
Returns true if the player has chosen their character and is loaded.

#### SetPlayerData
`exports.allgamers_bridge:SetPlayerData(key, value)`
Modifies the current player's data with the specified key and value.

#### OpenInventory
`exports.allgamers_bridge:OpenInventory()`
Opens the player's inventory through the framework.

#### ShowNotification
`exports.allgamers_bridge:ShowNotification(text)`
Shows a notification to the player through the framework.

#### Dispatch
`exports.allgamers_bridge:Dispatch(code, title, message, blip, jobs, important)`
Sends a police dispatch notification.

#### GetJob
`exports.allgamers_bridge:GetJob()`
Returns the current player's job name.

#### GetJobGrade
`exports.allgamers_bridge:GetJobGrade()`
Returns the current player's job grade number.

#### GetJobInfo
`exports.allgamers_bridge:GetJobInfo()`
Returns comprehensive job information including job name, label, grade details, boss status, and duty status.

**Returns:**
```lua
{
    jobName = "police",
    jobLabel = "Police",
    gradeName = "officer",
    gradeLabel = "Officer",
    gradeRank = 1,
    boss = false,
    onDuty = true
}
```

#### HasItem
`exports.allgamers_bridge:HasItem(item_name)`
Returns boolean and item count - checks if player has the given item in inventory.

#### GetInventory
`exports.allgamers_bridge:GetInventory()`
Returns the player's inventory contents.

#### CloseMenu
`exports.allgamers_bridge:CloseMenu()`
Closes any open menu (like esx_menu_default).

#### GetPlayerMetaData
`exports.allgamers_bridge:GetPlayerMetaData(metadata)`
Returns the player's metadata for the specified metadata key.

#### GetIsPlayerDead
`exports.allgamers_bridge:GetIsPlayerDead()`
Returns true if the player is dead or in last stand.

#### GetPlayerName
`exports.allgamers_bridge:GetPlayerName()`
Returns the player's first and last name.

#### GetInventoryResourceName
`exports.allgamers_bridge:GetInventoryResourceName()`
Returns the name of the currently active inventory system.

#### GetItemInfo
`exports.allgamers_bridge:GetItemInfo(item)`
Returns item information including name, label, weight, stack, and description.

#### GetAllItems
`exports.allgamers_bridge:GetAllItems()`
Returns a table of all available items in the framework.

#### GetItemCount
`exports.allgamers_bridge:GetItemCount(item)`
Returns the count of the specified item in player's inventory.

#### GetPlayerInventory
`exports.allgamers_bridge:GetPlayerInventory()`
Returns the player's complete inventory contents.

#### GetImagePath
`exports.allgamers_bridge:GetImagePath(item)`
Returns the image path for the specified item.

#### CanCarryItem
`exports.allgamers_bridge:CanCarryItem(item, count)`
Returns boolean - checks if player can carry the specified item and count.

#### GetInventoryWeight
`exports.allgamers_bridge:GetInventoryWeight()`
Returns the current inventory weight.

#### GetInventoryMaxWeight
`exports.allgamers_bridge:GetInventoryMaxWeight()`
Returns the maximum inventory weight.

---

## Inventory System

**Supported Systems:** `qb-inventory`, `ox_inventory`, `codem-inventory`, `origen_inventory`, `qs-inventory`, `tgiann-inventory`, `jpr-inventory`, `ps-inventory`, `core_inventory`

### Configuration
```lua
config.Inventory = "auto"  -- auto | qb-inventory | ox_inventory | codem-inventory | origen_inventory | qs-inventory | tgiann-inventory | jpr-inventory | ps-inventory | core_inventory
```

### Usage
```lua
-- Via ALLGAMERS table (recommended)
ALLGAMERS.AddItem(playerId, item, amount)
ALLGAMERS.RemoveItem(playerId, item, amount)
ALLGAMERS.HasItem(playerId, item, count)
ALLGAMERS.GetItemCount(playerId, item)

-- Or direct exports
exports.allgamers_bridge:AddItem(playerId, item, amount)
exports.allgamers_bridge:RemoveItem(playerId, item, amount)
exports.allgamers_bridge:HasItem(playerId, item, count)
```

### Server Inventory Functions
- `ALLGAMERS.AddItem(playerId, item, amount, slot, metadata)` - Add item to player's inventory
- `ALLGAMERS.RemoveItem(playerId, item, amount, slot, metadata)` - Remove item from player's inventory
- `ALLGAMERS.HasItem(playerId, item, requiredCount)` - Check if player has item
- `ALLGAMERS.CanCarryItem(playerId, item, amount)` - Check if player can carry item
- `ALLGAMERS.GetItemCount(playerId, item, metadata)` - Get item count in inventory
- `ALLGAMERS.GetPlayerInventory(playerId)` - Get player's full inventory
- `ALLGAMERS.GetItemBySlot(playerId, slot)` - Get item by slot number
- `ALLGAMERS.SetItemMetadata(playerId, item, slot, metadata)` - Set item metadata
- `ALLGAMERS.GetImagePath(item)` - Get item image path
- `ALLGAMERS.OpenStash(playerId, type, stashId)` - Open stash/storage
- `ALLGAMERS.RegisterStash(id, label, slots, weight, owner, groups, coords)` - Register new stash
- `ALLGAMERS.AddStashItems(stashId, items)` - Add items to stash
- `ALLGAMERS.RemoveStashItems(stashId, items)` - Remove items from stash
- `ALLGAMERS.ClearStash(stashId, type)` - Clear stash contents
- `ALLGAMERS.AddTrunkItems(vehiclePlate, items)` - Add items to vehicle trunk
- `ALLGAMERS.OpenShop(playerId, shopId)` - Open shop
- `ALLGAMERS.RegisterShop(shopId, inventory, coords, groups)` - Register new shop
- `ALLGAMERS.UpdateVehiclePlate(oldPlate, newPlate)` - Update vehicle plate
- `ALLGAMERS.OpenPlayerInventory(src, targetSrc)` - Open another player's inventory
- `ALLGAMERS.GetInventoryResourceName()` - Get active inventory system name

### Client Inventory Functions
- `ALLGAMERS.HasItem(item, requiredCount)` - Check if local player has item
- `ALLGAMERS.GetItemCount(item)` - Get item count for local player
- `ALLGAMERS.GetPlayerInventory()` - Get local player's inventory
- `ALLGAMERS.GetInventory()` - Alias for GetPlayerInventory()
- `ALLGAMERS.GetItemInfo(item)` - Get item information
- `ALLGAMERS.GetAllItems()` - Get all available items
- `ALLGAMERS.GetImagePath(item)` - Get item image path
- `ALLGAMERS.CanCarryItem(item, count)` - Check if can carry item
- `ALLGAMERS.GetInventoryWeight()` - Get current inventory weight
- `ALLGAMERS.GetInventoryMaxWeight()` - Get max inventory weight

---

## Target System

**Supported Systems:** `ox_target`, `qb-target`

### Configuration
```lua
config.Target = "auto"  -- auto | ox_target | qb-target
```

### Usage
```lua
-- Via ALLGAMERS table (recommended)
ALLGAMERS.AddGlobalPlayer(options)
ALLGAMERS.AddBoxZone(name, coords, size, heading, options, debug)

-- Or direct exports
exports.allgamers_bridge:AddGlobalPlayer(options)
exports.allgamers_bridge:AddBoxZone(name, coords, size, heading, options, debug)
```

### Target Functions
- `ALLGAMERS.DisableTargeting(disable)` - Toggle targeting on/off
- `ALLGAMERS.AddGlobalPlayer(options)` - Add options to all players
- `ALLGAMERS.RemoveGlobalPlayer(optionNames)` - Remove player options
- `ALLGAMERS.AddGlobalPed(options)` - Add options to all peds
- `ALLGAMERS.RemoveGlobalPed(optionNames)` - Remove ped options
- `ALLGAMERS.AddGlobalVehicle(options)` - Add options to all vehicles
- `ALLGAMERS.RemoveGlobalVehicle(optionNames)` - Remove vehicle options
- `ALLGAMERS.AddLocalEntity(entities, options)` - Add to local entity
- `ALLGAMERS.RemoveLocalEntity(entities, labels)` - Remove from local entity
- `ALLGAMERS.AddNetworkedEntity(netids, options)` - Add to networked entity
- `ALLGAMERS.RemoveNetworkedEntity(netids, labels)` - Remove from networked entity
- `ALLGAMERS.AddModel(models, options)` - Add to specific model(s)
- `ALLGAMERS.RemoveModel(models, labels)` - Remove from model(s)
- `ALLGAMERS.AddBoxZone(name, coords, size, heading, options, debug)` - Add box zone
- `ALLGAMERS.AddSphereZone(name, coords, radius, options, debug)` - Add sphere zone
- `ALLGAMERS.RemoveZone(name)` - Remove zone
- `ALLGAMERS.GetTargetResourceName()` - Get active target system

---

## TextUI System

**Supported Systems:** `ox_lib`, `jg-textui`, `okokTextUI`, `cd_drawtextui`, `lation_ui`, framework native

### Configuration
```lua
config.TextUI = "auto"  -- auto | ox_lib | jg-textui | okokTextUI | cd_drawtextui | lation_ui
```

### Usage
```lua
-- Via ALLGAMERS table (recommended)
ALLGAMERS.ShowHelpText("Press [E] to interact", "left")
ALLGAMERS.ShowAdvancedText({text = "Vehicle Unlocked", icon = "car"})

-- Or direct exports
exports.allgamers_bridge:ShowHelpText("Press [E] to interact", "left")
exports.allgamers_bridge:ShowAdvancedText({text = "Vehicle Unlocked", icon = "car"})
```

### TextUI Functions
- `ALLGAMERS.ShowHelpText(message, position)` - Show help text
- `ALLGAMERS.HideHelpText()` - Hide help text
- `ALLGAMERS.ShowAdvancedText(options)` - Show advanced text with icon
- `ALLGAMERS.UpdateText(message)` - Update displayed text
- `ALLGAMERS.IsTextUIShowing()` - Check if TextUI is showing
- `ALLGAMERS.GetTextUIResourceName()` - Get active TextUI system
- `ALLGAMERS.ShowKeyHelp(key, message)` - Show key-based help
- `ALLGAMERS.Draw3DText(coords, text, scale)` - Draw 3D text
---

## Progress Bar System

**Supported Systems:** `ox_lib`, `lation_ui`, `progressbar`

### Configuration
```lua
config.ProgressBar = "auto"  -- auto | ox_lib | lation_ui | progressbar
```

### Usage
```lua
-- Via ALLGAMERS table (recommended)
ALLGAMERS.ShowProgress(options, callback, isQBFormat)

-- Or direct exports
exports.allgamers_bridge:ShowProgress(options, callback, isQBFormat)
```

### Progress Bar Functions
- `ALLGAMERS.ShowProgress(options, callback, isQBFormat)` - Show progress bar
- `ALLGAMERS.GetProgressBarResourceName()` - Get active progress bar system

---

## Fuel System

**Supported Systems:** `ox_fuel`, `qb-fuel`, `ps-fuel`, `qs-fuelstations`, `legacyfuel`, `renewed-fuel`, `ti_fuel`, `lc_fuel`, `x-fuel`, `cdn-fuel`, `esx-sna-fuel`, `bigdaddy-fuel`, `okokgasstation`

### Configuration
```lua
config.Fuel = "auto"  -- auto | ox_fuel | qb-fuel | ps-fuel | qs-fuelstations | legacyfuel | renewed-fuel | ti_fuel | lc_fuel | x-fuel | cdn-fuel | esx-sna-fuel | bigdaddy-fuel | okokgasstation
```

### Usage
```lua
-- Via ALLGAMERS table (recommended)
local fuel = ALLGAMERS.GetFuel(vehicle)
ALLGAMERS.SetFuel(vehicle, 75.0)
ALLGAMERS.Refuel(vehicle)

-- Or direct exports
local fuel = exports.allgamers_bridge:GetFuel(vehicle)
exports.allgamers_bridge:SetFuel(vehicle, 75.0)
exports.allgamers_bridge:Refuel(vehicle)
```

### Fuel Functions
- `ALLGAMERS.GetFuelResourceName()` - Get active fuel system name
- `ALLGAMERS.GetFuel(vehicle)` - Get vehicle fuel level (0-100)
- `ALLGAMERS.SetFuel(vehicle, fuel, fuelType?)` - Set vehicle fuel level
- `ALLGAMERS.IsFuelSystemAvailable()` - Check if fuel system is available
- `ALLGAMERS.GetFuelCapacity(vehicle)` - Get vehicle fuel capacity
- `ALLGAMERS.NeedsFuel(vehicle, threshold?)` - Check if vehicle needs fuel
- `ALLGAMERS.Refuel(vehicle, fuelType?)` - Refuel vehicle to full capacity

---

## Vehicle Keys System

**Supported Systems:** `qb-vehiclekeys`, `qbx_vehiclekeys`, `qs-vehiclekeys`, `Renewed-Vehiclekeys`, `wasabi_carlock`, `okokGarage`, `cd_garage`, `mk_vehiclekeys`, `mono_carkeys`, `MrNewbVehicleKeys`, `mVehicle`, `t1ger_keys`, `F_RealCarKeysSystem`, `jacksam`

### Configuration
```lua
config.VehicleKeys = "auto"  -- auto | qb-vehiclekeys | qbx_vehiclekeys | qs-vehiclekeys | Renewed-Vehiclekeys | wasabi_carlock | okokGarage | cd_garage | mk_vehiclekeys | mono_carkeys | MrNewbVehicleKeys | mVehicle | t1ger_keys | F_RealCarKeysSystem | jacksam
```

### Usage
```lua
-- Via ALLGAMERS table (recommended)
ALLGAMERS.GiveVehicleKeys(vehicle, plate)
ALLGAMERS.RemoveVehicleKeys(vehicle, plate)

-- Or direct exports
exports.allgamers_bridge:GiveVehicleKeys(vehicle, plate)
exports.allgamers_bridge:RemoveVehicleKeys(vehicle, plate)
```

### Vehicle Keys Functions
- `ALLGAMERS.GetVehicleKeysResourceName()` - Get active vehicle keys system name
- `ALLGAMERS.GiveVehicleKeys(vehicle, plate?)` - Give vehicle keys to player
- `ALLGAMERS.RemoveVehicleKeys(vehicle, plate?)` - Remove vehicle keys from player
- `ALLGAMERS.IsVehicleKeysSystemAvailable()` - Check if vehicle keys system is available

---

## Banking System

**Supported Systems:** `qb-banking`, `okokBanking`, `fd_banking`, `renewed-banking`, `tgg-banking`, `kartik-banking`, `tgiann-bank`, `wasabi_banking`, `qb-management`, `qbx_management`, `esx_society`

### Configuration
```lua
config.Banking = "auto"  -- auto | qb-banking | okokBanking | fd_banking | renewed-banking | tgg-banking | kartik-banking | tgiann-bank | wasabi_banking | qb-management | qbx_management | esx_society
```

### Usage
```lua
-- Via ALLGAMERS table (recommended)
ALLGAMERS.AddAccountMoney(accountName, amount, reason)
ALLGAMERS.RemoveAccountMoney(accountName, amount, reason)
ALLGAMERS.GetAccountMoney(accountName)

-- Or direct exports
exports.allgamers_bridge:AddAccountMoney(accountName, amount, reason)
exports.allgamers_bridge:RemoveAccountMoney(accountName, amount, reason)
exports.allgamers_bridge:GetAccountMoney(accountName)
```

### Banking Functions
- `ALLGAMERS.AddAccountMoney(accountName, amount, reason)` - Add money to a society/bank account
- `ALLGAMERS.RemoveAccountMoney(accountName, amount, reason)` - Remove money from a society/bank account
- `ALLGAMERS.GetAccountMoney(accountName)` - Get balance of a society/bank account

---

### Server Exports

#### GetPlayer
`exports.allgamers_bridge:GetPlayer(id)`
Returns player object (like xPlayer in ESX).

#### GetAllPlayers
`exports.allgamers_bridge:GetAllPlayers()`
Returns all online players.

#### GetPlayerJob
`exports.allgamers_bridge:GetPlayerJob(id)`
Returns the player's job name.

#### GetPlayerJobGrade
`exports.allgamers_bridge:GetPlayerJobGrade(id)`
Returns the player's job grade number.

#### GetPlayerJobInfo
`exports.allgamers_bridge:GetPlayerJobInfo(id)`
Returns comprehensive job information for a specific player including job name, label, grade details, boss status, and duty status.

**Returns:**
```lua
{
    jobName = "police",
    jobLabel = "Police",
    gradeName = "officer",
    gradeLabel = "Officer",
    gradeRank = 1,
    boss = false,
    onDuty = true
}
```

#### HasPermission
`exports.allgamers_bridge:HasPermission(playerId)`
Returns boolean - check if player has one of the configured admin groups.

#### AddMoney
`exports.allgamers_bridge:AddMoney(playerId, amount)`
Adds money to player (with most frameworks to their inventory).

#### RemoveMoney
`exports.allgamers_bridge:RemoveMoney(playerId, amount)`
Removes money from player (with most frameworks from their inventory).

#### RemoveBankMoney
`exports.allgamers_bridge:RemoveBankMoney(playerId, amount)`
Removes money from player's bank.

#### GetMoney
`exports.allgamers_bridge:GetMoney(playerId)`
Retrieves player's money (with most frameworks from their inventory).

#### GetBankMoney
`exports.allgamers_bridge:GetBankMoney(playerId)`
Retrieves player's money from bank.

#### TransferMoney
`exports.allgamers_bridge:TransferMoney(from, to, amount)`
Transfers bank money from one player to another.

#### GetItem
`exports.allgamers_bridge:GetItem(playerId, item_name)`
Retrieves info about an item from player's inventory.

#### CanCarryItem
`exports.allgamers_bridge:CanCarryItem(playerId, item_name, amount)`
Returns boolean - checks if player can carry the given item and count.

#### SetJob
`exports.allgamers_bridge:SetJob(playerId, job_name, job_grade)`
Set player's job.

#### GetIdentifier
`exports.allgamers_bridge:GetIdentifier(playerId)`
Returns player's rockstar identifier.

#### GetPlayerByCitizenId
`exports.allgamers_bridge:GetPlayerByCitizenId(cid)`
Returns player object by citizenid (QB/QBX) or identifier (ESX).

#### GetPlayerCoords
`exports.allgamers_bridge:GetPlayerCoords(playerId)`
Returns the coordinates of the given player ID.

#### GetPlayerMetadata
`exports.allgamers_bridge:GetPlayerMetadata(playerId, metadata)`
Gets the specified metadata key from the player's data.

#### SetPlayerMetadata
`exports.allgamers_bridge:SetPlayerMetadata(playerId, metadata, value)`
Sets the specified metadata key and value to the player's data.

#### GetPlayerDuty
`exports.allgamers_bridge:GetPlayerDuty(playerId)`
Returns the player's duty status.

#### GetIsPlayerDead
`exports.allgamers_bridge:GetIsPlayerDead(playerId)`
Returns true if the player is dead or in last stand.

#### GetPlayerName
`exports.allgamers_bridge:GetPlayerName(playerId)`
Returns the first and last name of the player.

#### RevivePlayer
`exports.allgamers_bridge:RevivePlayer(playerId)`
Revives a player if they are dead or in last stand.

#### RegisterUsableItem
`exports.allgamers_bridge:RegisterUsableItem(itemName, callback)`
Registers a usable item with a callback function for all frameworks.

#### GetInventoryResourceName
`exports.allgamers_bridge:GetInventoryResourceName()`
Returns the name of the currently active inventory system.

#### GetItemInfo
`exports.allgamers_bridge:GetItemInfo(item)`
Returns item information including name, label, weight, stack, and description.

#### GetAllItems
`exports.allgamers_bridge:GetAllItems()`
Returns a table of all available items in the framework.

#### GetItemCount
`exports.allgamers_bridge:GetItemCount(item)`
Returns the count of the specified item in player's inventory.

#### GetPlayerInventory
`exports.allgamers_bridge:GetPlayerInventory()`
Returns the player's complete inventory contents.

#### GetImagePath
`exports.allgamers_bridge:GetImagePath(item)`
Returns the image path for the specified item.

#### CanCarryItem
`exports.allgamers_bridge:CanCarryItem(item, count)`
Returns boolean - checks if player can carry the specified item and count.

#### GetInventoryWeight
`exports.allgamers_bridge:GetInventoryWeight()`
Returns the current inventory weight.

#### GetInventoryMaxWeight
`exports.allgamers_bridge:GetInventoryMaxWeight()`
Returns the maximum inventory weight.


### Usage in Other Resources

```lua
RegisterNetEvent('allgamers_bridge:Client:OnPlayerLoaded', function()
    -- Your code here - player is fully loaded
end)
```



## Complete Function List (ALLGAMERS.FunctionName)

### Client Functions
```lua
-- Framework
ALLGAMERS.GetFrameworkName()
ALLGAMERS.IsPlayerLoaded()
ALLGAMERS.GetPlayerData()
ALLGAMERS.SetPlayerData(key, value)
ALLGAMERS.OpenInventory()
ALLGAMERS.ShowNotification(text)
ALLGAMERS.Dispatch(code, title, message, blip, jobs, important)
ALLGAMERS.GetJob()
ALLGAMERS.GetJobGrade()
ALLGAMERS.GetJobInfo()
ALLGAMERS.HasItem(item_name)
ALLGAMERS.GetInventory()
ALLGAMERS.CloseMenu()
ALLGAMERS.GetPlayerMetaData(metadata)
ALLGAMERS.GetIsPlayerDead()
ALLGAMERS.GetPlayerName()

-- Inventory System
ALLGAMERS.GetInventoryResourceName()
ALLGAMERS.GetItemInfo(item)
ALLGAMERS.GetAllItems()
ALLGAMERS.GetItemCount(item)
ALLGAMERS.GetPlayerInventory()
ALLGAMERS.GetImagePath(item)
ALLGAMERS.CanCarryItem(item, count)
ALLGAMERS.GetInventoryWeight()
ALLGAMERS.GetInventoryMaxWeight()

-- Target System
ALLGAMERS.DisableTargeting(disable)
ALLGAMERS.AddGlobalPlayer(options)
ALLGAMERS.RemoveGlobalPlayer(optionNames)
ALLGAMERS.AddGlobalPed(options)
ALLGAMERS.RemoveGlobalPed(optionNames)
ALLGAMERS.AddGlobalVehicle(options)
ALLGAMERS.RemoveGlobalVehicle(optionNames)
ALLGAMERS.AddLocalEntity(entities, options)
ALLGAMERS.RemoveLocalEntity(entities, labels)
ALLGAMERS.AddNetworkedEntity(netids, options)
ALLGAMERS.RemoveNetworkedEntity(netids, labels)
ALLGAMERS.AddModel(models, options)
ALLGAMERS.RemoveModel(models, labels)
ALLGAMERS.AddBoxZone(name, coords, size, heading, options, debug)
ALLGAMERS.AddSphereZone(name, coords, radius, options, debug)
ALLGAMERS.RemoveZone(name)
ALLGAMERS.GetTargetResourceName()

-- TextUI System
ALLGAMERS.ShowHelpText(message, position)
ALLGAMERS.HideHelpText()
ALLGAMERS.ShowAdvancedText(options)
ALLGAMERS.UpdateText(message)
ALLGAMERS.IsTextUIShowing()
ALLGAMERS.GetTextUIResourceName()
ALLGAMERS.ShowKeyHelp(key, message)
ALLGAMERS.Draw3DText(coords, text, scale)

-- Progress Bar System
ALLGAMERS.ShowProgress(options, callback, isQBFormat)
ALLGAMERS.GetProgressBarResourceName()

-- Fuel System
ALLGAMERS.GetFuelResourceName()
ALLGAMERS.GetFuel(vehicle)
ALLGAMERS.SetFuel(vehicle, fuel, fuelType)
ALLGAMERS.IsFuelSystemAvailable()
ALLGAMERS.GetFuelCapacity(vehicle)
ALLGAMERS.NeedsFuel(vehicle, threshold)
ALLGAMERS.Refuel(vehicle, fuelType)

```

### Server Functions
```lua
ALLGAMERS.GetFrameworkName()
ALLGAMERS.GetPlayer(id)
ALLGAMERS.GetAllPlayers()
ALLGAMERS.GetPlayerJob(id)
ALLGAMERS.GetPlayerJobGrade(id)
ALLGAMERS.GetPlayerJobInfo(id)
ALLGAMERS.HasPermission(playerId)
ALLGAMERS.AddMoney(playerId, amount)
ALLGAMERS.RemoveMoney(playerId, amount)
ALLGAMERS.RemoveBankMoney(playerId, amount)
ALLGAMERS.GetMoney(playerId)
ALLGAMERS.GetBankMoney(playerId)
ALLGAMERS.TransferMoney(from, to, amount)
ALLGAMERS.AddItem(playerId, item_name, amount)
ALLGAMERS.RemoveItem(playerId, item_name, amount)
ALLGAMERS.GetItem(playerId, item_name)
ALLGAMERS.CanCarryItem(playerId, item_name, amount)
ALLGAMERS.SetJob(playerId, job_name, job_grade)
ALLGAMERS.GetIdentifier(playerId)
ALLGAMERS.GetPlayerByCitizenId(cid)
ALLGAMERS.GetPlayerName(playerId)
ALLGAMERS.GetPlayerCoords(playerId)
ALLGAMERS.GetPlayerMetadata(playerId, metadata)
ALLGAMERS.SetPlayerMetadata(playerId, metadata, value)
ALLGAMERS.GetPlayerDuty(playerId)
ALLGAMERS.GetIsPlayerDead(playerId)
ALLGAMERS.RevivePlayer(playerId)
ALLGAMERS.RegisterUsableItem(itemName, callback)
ALLGAMERS.AddAccountMoney(accountName, amount, reason)
ALLGAMERS.RemoveAccountMoney(accountName, amount, reason)
ALLGAMERS.GetAccountMoney(accountName)

-- Inventory System
ALLGAMERS.GetInventoryResourceName()
ALLGAMERS.GetItemInfo(item)
ALLGAMERS.GetAllItems()
ALLGAMERS.GetItemCount(playerId, item, metadata)
ALLGAMERS.GetPlayerInventory(playerId)
ALLGAMERS.GetItemBySlot(playerId, slot)
ALLGAMERS.SetItemMetadata(playerId, item, slot, metadata)
ALLGAMERS.GetImagePath(item)
ALLGAMERS.OpenStash(playerId, type, stashId)
ALLGAMERS.RegisterStash(id, label, slots, weight, owner, groups, coords)
ALLGAMERS.AddStashItems(stashId, items)
ALLGAMERS.RemoveStashItems(stashId, items)
ALLGAMERS.ClearStash(stashId, type)
ALLGAMERS.AddTrunkItems(vehiclePlate, items)
ALLGAMERS.OpenShop(playerId, shopId)
ALLGAMERS.RegisterShop(shopId, inventory, coords, groups)
ALLGAMERS.UpdateVehiclePlate(oldPlate, newPlate)
ALLGAMERS.OpenPlayerInventory(src, targetSrc)
```


