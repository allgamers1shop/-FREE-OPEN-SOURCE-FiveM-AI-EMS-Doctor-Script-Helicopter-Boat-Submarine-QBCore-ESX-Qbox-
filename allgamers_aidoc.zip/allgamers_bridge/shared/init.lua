_G.GetALLGAMERS = function()
    return exports['allgamers_bridge']:GetALLGAMERS()
end

if IsDuplicityVersion() then
    local attempts = 0
    while attempts < 2000 do
        local success, allgamers = pcall(function()
            return exports['allgamers_bridge']:GetALLGAMERS()
        end)
        if success and allgamers then
            _G.ALLGAMERS = allgamers
            break
        end
        Wait(0)
        attempts = attempts + 1
    end
else
    CreateThread(function()
        local attempts = 0
        while attempts < 100 do
            local success, allgamers = pcall(function()
                return exports['allgamers_bridge']:GetALLGAMERS()
            end)
            if success and allgamers then
                _G.ALLGAMERS = allgamers
                break
            end
            Wait(100)
            attempts = attempts + 1
        end
    end)
end
